#!/usr/bin/env python3
import hashlib
import json
import os
import pathlib
import resource
import selectors
import signal
import subprocess
import sys
import time

base = pathlib.Path('/workspace/scratch/fcf5fdf8376a')
repo = base / 't3-history-node-reuse'
plan_path = base / 't3-history-node-reuse-check-plan-02.json'
plan = json.loads(plan_path.read_text())
stage = int(sys.argv[1])
name = ['storage-tests', 'release-build'][stage]
attempt = '02' if stage == 0 else '01'
log_path = base / f't3-history-node-{name}-{attempt}.log'
receipt_path = base / f't3-history-node-{name}-{attempt}.json'
if log_path.exists() or receipt_path.exists():
    raise SystemExit('Refusing to overwrite an earlier attempt')

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def inputs():
    return {p: digest(repo / p) for p in plan['sources']}

def tree(label):
    index = base / f't3-history-node-{name}-{label}.index'
    environment = os.environ.copy()
    environment['GIT_INDEX_FILE'] = str(index)
    try:
        subprocess.run(['git', 'read-tree', 'HEAD'], cwd=repo, env=environment, check=True)
        subprocess.run(['git', 'add', '-A'], cwd=repo, env=environment, check=True)
        return subprocess.check_output(['git', 'write-tree'], cwd=repo, env=environment, text=True).strip()
    finally:
        index.unlink(missing_ok=True)
        pathlib.Path(str(index) + '.lock').unlink(missing_ok=True)

def memory():
    return {line.split(':')[0]: line.split(':', 1)[1].strip() for line in pathlib.Path('/proc/meminfo').read_text().splitlines() if line.startswith(('MemAvailable:', 'MemFree:', 'Shmem:'))}

assert inputs() == plan['sources']
assert tree('before') == plan['working_tree']
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip() == plan['base_commit']
toolchain = json.loads((base / 't3-count-lustr-debug-helper-build.json').read_text())['toolchain']
for path, expected in toolchain['files'].items():
    assert digest(pathlib.Path(path)) == expected
for name_of_tool in ['cargo', 'rustdoc']:
    path = base / 't3-toolchain/host-tools/bin' / name_of_tool
    toolchain['files'][str(path)] = digest(path)

env = os.environ.copy()
for key in ['RUSTC_WRAPPER', 'RUSTC_WORKSPACE_WRAPPER', 'RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS', 'LUST_CARGO', 'LUSTC']:
    env.pop(key, None)
tool_root = base / 't3-toolchain/host-tools'
env.update({
    'PATH': str(tool_root / 'bin') + ':' + str(base / 't3-runtime/node_modules/.bin') + ':' + env['PATH'],
    'CARGO': str(tool_root / 'bin/cargo'),
    'RUSTC': str(tool_root / 'bin/rustc'),
    'RUSTDOC': str(tool_root / 'bin/rustdoc'),
    'CARGO_HOME': plan['cargo_home'],
    'CARGO_TARGET_DIR': plan['target_dir'],
    'CARGO_BUILD_JOBS': '1',
    'CARGO_INCREMENTAL': '0',
    'CARGO_PROFILE_DEV_DEBUG': '0',
    'CARGO_PROFILE_TEST_DEBUG': '0',
    'T3_CODE_LS_TEST_TMPDIR': plan['test_fixture_root'],
    'TMPDIR': plan['test_fixture_root'],
})
pathlib.Path(plan['test_fixture_root']).mkdir(exist_ok=True)
os.sched_setaffinity(0, {min(os.sched_getaffinity(0))})
command = plan['planned_commands'][stage]
receipt = {
    'kind': 'supervised local ' + name,
    'plan_sha256': digest(plan_path),
    'supervisor_sha256': digest(pathlib.Path(__file__)),
    'scope': 'diagnostic; not hosted qualification or a performance claim',
    'compiler_route': 'bluefe-rustc-via-lustr',
    'base_commit': plan['base_commit'],
    'working_tree': plan['working_tree'],
    'source_digest': plan['source_digest'],
    'sources': plan['sources'],
    'command': command,
    'toolchain': toolchain,
    'cpu_affinity': sorted(os.sched_getaffinity(0)),
    'selected_build_environment': {k: env.get(k) for k in ['CARGO', 'RUSTC', 'RUSTDOC', 'RUSTC_WRAPPER', 'RUSTC_WORKSPACE_WRAPPER', 'RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS', 'LUST_CARGO', 'LUSTC', 'CARGO_HOME', 'CARGO_TARGET_DIR', 'CARGO_BUILD_JOBS', 'CARGO_INCREMENTAL', 'CARGO_PROFILE_DEV_DEBUG', 'CARGO_PROFILE_TEST_DEBUG', 'TMPDIR', 'T3_CODE_LS_TEST_TMPDIR']},
    'memory_before': memory(),
    'timeout_seconds': plan['timeout_seconds'],
    'maximum_log_bytes': plan['maximum_log_bytes'],
    'status': 'running',
}
receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
process = None
reason = None

def stop_group():
    if process is None:
        return
    try:
        os.killpg(process.pid, signal.SIGTERM)
    except ProcessLookupError:
        return
    try:
        process.wait(timeout=10)
    except subprocess.TimeoutExpired:
        os.killpg(process.pid, signal.SIGKILL)
        process.wait(timeout=10)

def interrupted(signum, frame):
    raise InterruptedError(f'supervisor received signal {signum}')

for signum in [signal.SIGTERM, signal.SIGINT]:
    signal.signal(signum, interrupted)

started = time.monotonic()
try:
    with log_path.open('wb') as log:
        process = subprocess.Popen(command, cwd=repo, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, start_new_session=True)
        receipt['owned_process_group'] = process.pid
        receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
        print(json.dumps({'stage': name, 'pid': process.pid, 'log': str(log_path)}), flush=True)
        selector = selectors.DefaultSelector()
        selector.register(process.stdout, selectors.EVENT_READ)
        written = 0
        while selector.get_map():
            if time.monotonic() - started > plan['timeout_seconds']:
                raise TimeoutError('supervised command exceeded timeout')
            for key, _ in selector.select(timeout=0.25):
                chunk = os.read(key.fileobj.fileno(), 32768)
                if not chunk:
                    selector.unregister(key.fileobj)
                    continue
                if written + len(chunk) > plan['maximum_log_bytes']:
                    log.write(chunk[:plan['maximum_log_bytes'] - written])
                    raise RuntimeError('supervised command exceeded log limit')
                log.write(chunk)
                log.flush()
                written += len(chunk)
        process.wait(timeout=max(1, plan['timeout_seconds'] - (time.monotonic() - started)))
except BaseException as error:
    reason = f'{type(error).__name__}: {error}'
    stop_group()
finally:
    elapsed = time.monotonic() - started
    usage = resource.getrusage(resource.RUSAGE_CHILDREN)
    receipt.update({
        'elapsed_seconds': round(elapsed, 3),
        'exit_code': process.returncode if process is not None else None,
        'supervisor_failure': reason,
        'children_max_rss_kib': usage.ru_maxrss,
        'children_user_seconds': usage.ru_utime,
        'children_system_seconds': usage.ru_stime,
        'memory_after': memory(),
        'source_unchanged': inputs() == plan['sources'],
        'working_tree_after': tree('after'),
        'toolchain_unchanged': all(digest(pathlib.Path(p)) == h for p, h in toolchain['files'].items()),
        'log_sha256': digest(log_path) if log_path.exists() else None,
        'log_bytes': log_path.stat().st_size if log_path.exists() else 0,
    })
    receipt['status'] = 'passed' if process is not None and process.returncode == 0 and reason is None and receipt['source_unchanged'] and receipt['working_tree_after'] == plan['working_tree'] and receipt['toolchain_unchanged'] else 'failed'
    receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({k: receipt[k] for k in ['status', 'exit_code', 'supervisor_failure', 'elapsed_seconds', 'children_max_rss_kib', 'source_unchanged', 'working_tree_after', 'log_sha256']}), flush=True)
sys.exit(0 if receipt['status'] == 'passed' else 1)
