#!/usr/bin/python3
import os
from pathlib import Path
import sys

with Path('/workspace/scratch/fcf5fdf8376a/t3-f751-checks/guest-share-invocations.log').open('a') as log:
    log.write('native-guest-share\n')
binary = '/workspace/scratch/fcf5fdf8376a/t3-target/debug/t3-code-ls-guest-share'
os.execv(binary, [binary, *sys.argv[1:]])
