#!/usr/bin/env python3
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import time

root = Path('/workspace/scratch/fcf5fdf8376a/t3-upstream-f751')
out = Path('/workspace/scratch/fcf5fdf8376a/t3-f751-checks')
name, duration, *command = sys.argv[1:]
assert re.fullmatch('[a-z0-9-]+', name) and command
timeout = float(duration)
child_cwd = (root / os.environ.get('T3_F751_CHECK_CWD', '.')).resolve()
assert child_cwd == root or root in child_cwd.parents
receipt_path = out / 'receipt.json'
receipt = json.loads(receipt_path.read_text())
assert not any(check['name'] == name for check in receipt['checks'])
assert subprocess.run(['git', 'diff', '--quiet'], cwd=root).returncode == 0
tree = subprocess.check_output(['git', 'write-tree'], cwd=root, text=True).strip()
assert tree == receipt['source_tree']
env = dict(os.environ)
env['PATH'] = '/workspace/scratch/fcf5fdf8376a/t3-runtime/node_modules/.bin:' + env['PATH']
env['T3_CODE_LS_TEST_RUNTIME'] = '/workspace/scratch/fcf5fdf8376a/t3-test-runtime'
env['TMPDIR'] = '/workspace/scratch/fcf5fdf8376a/t3-storage-test-tmp'
if 'T3_CODE_LS_IMPLEMENTATION' not in os.environ:
    env.pop('T3_CODE_LS_IMPLEMENTATION', None)
for variable in ['T3_CODE_LS_PROVIDER_EXECUTABLE', 'T3_CODE_LS_GUEST_SHARE_EXECUTABLE']:
    if variable not in os.environ:
        env.pop(variable, None)
stdout_path, stderr_path = out / (name + '.stdout.log'), out / (name + '.stderr.log')
assert not stdout_path.exists() and not stderr_path.exists()
started = time.monotonic()
timed_out = False
child = None
with stdout_path.open('xb') as stdout, stderr_path.open('xb') as stderr:
    try:
        child = subprocess.Popen(['taskset', '-c', '0', *command], cwd=child_cwd, env=env,
                                 stdout=stdout, stderr=stderr, start_new_session=True)
        try:
            code = child.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out = True
            os.killpg(child.pid, signal.SIGTERM)
            try:
                code = child.wait(timeout=2)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                code = child.wait()
    except BaseException:
        if child is not None and child.poll() is None:
            os.killpg(child.pid, signal.SIGKILL)
            child.wait()
        raise
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
entry = {
    'name': name, 'command': ['taskset', '-c', '0', *command], 'cwd': str(child_cwd),
    'exit_code': code, 'timed_out': timed_out,
    'elapsed_seconds': round(time.monotonic() - started, 3),
    'stdout': str(stdout_path), 'stdout_sha256': sha(stdout_path),
    'stderr': str(stderr_path), 'stderr_sha256': sha(stderr_path),
    'source_unchanged': subprocess.run(['git', 'diff', '--quiet'], cwd=root).returncode == 0,
    'source_tree': subprocess.check_output(['git', 'write-tree'], cwd=root, text=True).strip(),
    'selected_environment': {key: env[key] for key in ['T3_CODE_LS_TEST_RUNTIME', 'TMPDIR',
        'T3_CODE_LS_IMPLEMENTATION', 'T3_CODE_LS_PROVIDER_EXECUTABLE',
        'T3_CODE_LS_GUEST_SHARE_EXECUTABLE'] if key in env},
    'helper_hashes_unchanged': all(sha(Path(helper['path'])) == helper['sha256']
                                 for helper in receipt['helpers'].values()),
}
receipt['checks'].append(entry)
receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({key: entry[key] for key in ['name', 'exit_code', 'timed_out',
    'elapsed_seconds', 'source_unchanged', 'helper_hashes_unchanged']}), flush=True)
if code != 0:
    print(stderr_path.read_text(errors='replace')[-6000:])
sys.exit(0 if code == 0 and not timed_out and entry['source_unchanged']
         and entry['source_tree'] == tree and entry['helper_hashes_unchanged'] else 1)
