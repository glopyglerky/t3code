#!/usr/bin/env python3
"""Owned, serialized local validation. It never edits the candidate source."""
import hashlib
import json
import os
import pathlib
import resource
import selectors
import shutil
import signal
import subprocess
import sys
import time

BASE = pathlib.Path('/workspace/scratch/fcf5fdf8376a')
PLAN_PATH = BASE / 't3-project-event-clean-plan-01.json'
PLAN = json.loads(PLAN_PATH.read_text())
ROOT = pathlib.Path(PLAN['repo'])
OUT = pathlib.Path(PLAN['output'])


def digest(path):
    h = hashlib.sha256()
    with pathlib.Path(path).open('rb') as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def memory():
    return {line.split(':')[0]: line.split(':', 1)[1].strip()
            for line in pathlib.Path('/proc/meminfo').read_text().splitlines()
            if line.startswith(('MemAvailable:', 'MemFree:', 'Shmem:'))}


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()


def source_matches():
    return all(digest(ROOT / p) == expected for p, expected in PLAN['sources'].items())


def inside(path, parent):
    try:
        path.relative_to(parent)
        return True
    except ValueError:
        return False


def mirrored_links():
    receipt_path = pathlib.Path(PLAN['dependency_link_receipt'])
    correction_path = pathlib.Path(PLAN['runtime_correction_receipt'])
    assert digest(receipt_path) == PLAN['dependency_link_receipt_sha256']
    assert digest(correction_path) == PLAN['runtime_correction_receipt_sha256']
    receipt = json.loads(receipt_path.read_text())
    correction = json.loads(correction_path.read_text())
    assert correction['status'] == 'passed' and correction['donor_unchanged'] and correction['source_unchanged']
    assert correction['new_dependencies']['sha256'] == digest(receipt_path)
    original_path = pathlib.Path(receipt['original_receipt'])
    assert digest(original_path) == receipt['original_receipt_sha256']
    original = json.loads(original_path.read_text())
    donor = pathlib.Path(receipt['source'])
    assert pathlib.Path(receipt['destination']) == ROOT
    assert original['source'] == receipt['source'] and original['destination'] == receipt['destination']
    removed = set(receipt['removed'])
    overrides = receipt['overrides']
    assert removed == {'node_modules/@modelcontextprotocol/sdk', 'node_modules/@anthropic-ai/sdk'}
    assert len(overrides) == 22
    assert set(overrides) == {c['path'] for c in correction['changes'] if c['action'] == 'repoint'}
    assert receipt['links'] == [p for p in original['links'] if p not in removed]
    assert (donor / 'pnpm-lock.yaml').read_bytes() == (ROOT / 'pnpm-lock.yaml').read_bytes()
    assert (donor / 'pnpm-workspace.yaml').read_bytes() == (ROOT / 'pnpm-workspace.yaml').read_bytes()
    donor_states = {}
    for relative in original['links']:
        path = donor / relative
        kind = 'symlink' if path.is_symlink() else 'directory' if path.is_dir() else 'file'
        state = {'kind': kind, 'resolved': str(path.resolve(strict=True))}
        if path.is_symlink():
            state['link'] = os.readlink(path)
        elif path.is_file():
            state['sha256'] = digest(path)
        donor_states[relative] = state
    assert donor_states == correction['donor_links_after'], 'Donor dependency inventory changed'
    assert hashlib.sha256(json.dumps(donor_states, sort_keys=True, separators=(',', ':')).encode()).hexdigest() == receipt['donor_links_digest']
    for relative in removed:
        assert not os.path.lexists(ROOT / relative), f'Removed extra alias returned: {relative}'
    records = []
    for relative in receipt['links']:
        old = donor / relative
        new = ROOT / relative
        assert new.is_symlink(), f'Not an isolated link: {relative}'
        if relative in overrides:
            resolved = pathlib.Path(overrides[relative]['target'])
        else:
            resolved = old.resolve(strict=True)
            if inside(resolved, donor):
                source_relative = resolved.relative_to(donor)
                if 'node_modules' not in source_relative.parts:
                    resolved = ROOT / source_relative
        actual = new.resolve(strict=True)
        assert actual == resolved.resolve(strict=True), f'Changed dependency target: {relative}'
        approved = correction['isolated_links_after'][relative]
        assert approved == {'kind': 'symlink', 'resolved': str(actual), 'link': os.readlink(new)}, f'Changed approved dependency link: {relative}'
        owner = pathlib.Path(relative.split('/node_modules/', 1)[0]) if '/node_modules/' in relative else pathlib.Path('.')
        if (donor / owner / 'package.json').is_file():
            assert (donor / owner / 'package.json').read_bytes() == (ROOT / owner / 'package.json').read_bytes(), f'Manifest changed: {owner}'
        package = actual / 'package.json'
        record = {'path': relative, 'resolved': str(actual), 'workspace_source': inside(actual, ROOT) and 'node_modules' not in actual.relative_to(ROOT).parts}
        if package.is_file():
            metadata = json.loads(package.read_text())
            record.update({'package_name': metadata.get('name'), 'package_version': metadata.get('version'), 'package_manifest_sha256': digest(package)})
            in_store = inside(actual, donor / 'node_modules/.pnpm')
            harness = str(owner) == 'tools/server-test-runtime' or metadata.get('name') in ('@effect/tsgo', '@effect/tsgo-linux-x64')
            record.update({'frozen_application_store': in_store, 'harness_tooling': harness})
            assert record['workspace_source'] or in_store or harness, f'External application package outside frozen store: {relative} -> {actual}'
            if relative in overrides:
                assert in_store and digest(package) == overrides[relative]['manifest_sha256'], f'Changed approved package: {relative}'
        records.append(record)
    assert len(records) == 790
    return records


def toolchain():
    source = pathlib.Path(PLAN['toolchain_identity_receipt'])
    assert digest(source) == PLAN['toolchain_identity_receipt_sha256']
    result = json.loads(source.read_text())['toolchain']
    for path, expected in result['files'].items():
        assert digest(path) == expected, f'Changed toolchain file: {path}'
    for name in ('cargo', 'rustdoc'):
        path = pathlib.Path(PLAN['toolchain_root']) / 'bin' / name
        result['files'][str(path)] = digest(path)
    return result


def preflight():
    path = OUT / 'preflight.json'
    assert not path.exists(), 'Refusing to overwrite preflight evidence'
    result = {'kind': 'read-only source/runtime/toolchain preflight', 'plan_sha256': digest(PLAN_PATH), 'runner_sha256': digest(__file__), 'base_commit': PLAN['base_commit'], 'source_review_tree': PLAN['source_review_tree'], 'source_digest': PLAN['source_digest'], 'memory': memory(), 'status': 'running'}
    try:
        assert digest(BASE / PLAN['freeze_manifest']) == PLAN['freeze_manifest_sha256']
        assert git('rev-parse', 'HEAD') == PLAN['base_commit']
        assert git('write-tree') == PLAN['source_review_tree']
        assert source_matches(), 'Frozen source or compile input changed'
        result['toolchain'] = toolchain()
        result['dependency_links'] = mirrored_links()
        runtime_files = [pathlib.Path(PLAN['node']), pathlib.Path(PLAN['effect_tsgo']).resolve(), BASE / 't3-test-runtime/node_modules/@effect/tsgo/package.json', BASE / 't3-test-runtime/node_modules/@effect/tsgo-linux-x64/package.json']
        runtime_files.extend(sorted((BASE / 't3-test-runtime/node_modules/@effect/tsgo-linux-x64/artifacts/tsrs').rglob('*')))
        runtime_files = [p for p in runtime_files if p.is_file()]
        result['runtime_files'] = {str(p): digest(p) for p in runtime_files}
        version = subprocess.check_output([PLAN['node'], '--version'], text=True, timeout=10).strip()
        assert version == 'v26.12.1', version
        result['node_version'] = version
        installed_lock = BASE / 't3code-ls/node_modules/.pnpm/lock.yaml'
        modules = BASE / 't3code-ls/node_modules/.modules.yaml'
        result['installed_lock_sha256'] = digest(installed_lock)
        result['modules_metadata_sha256'] = digest(modules)
        usage = shutil.disk_usage(OUT)
        result['available_overlay_bytes'] = usage.free
        assert usage.free >= 2 * 1024**3, 'Insufficient owned overlay headroom'
        fixture = pathlib.Path(PLAN['fixture_root'])
        fixture.mkdir(exist_ok=False)
        result['status'] = 'passed'
    except BaseException as error:
        result['status'] = 'failed'
        result['failure'] = f'{type(error).__name__}: {error}'
    path.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'status': result['status'], 'failure': result.get('failure'), 'links': len(result.get('dependency_links', [])), 'runtime_files': len(result.get('runtime_files', {})), 'receipt': str(path), 'sha256': digest(path)}), flush=True)
    return result['status'] == 'passed'


def live_group(group):
    result = []
    for p in pathlib.Path('/proc').iterdir():
        if not p.name.isdigit():
            continue
        try:
            fields = (p / 'stat').read_text().rsplit(')', 1)[1].split()
            if int(fields[2]) == group and fields[0] != 'Z':
                result.append(int(p.name))
        except (OSError, ValueError, IndexError):
            pass
    return result


def run_stage(index):
    pre = json.loads((OUT / 'preflight.json').read_text())
    assert pre['status'] == 'passed', 'Preflight did not pass'
    for earlier in PLAN['stages'][:index]:
        assert json.loads((OUT / (earlier['name'] + '.json')).read_text())['status'] == 'passed', 'Predecessor did not pass'
    stage = PLAN['stages'][index]
    log_path = OUT / (stage['name'] + '.log')
    receipt_path = OUT / (stage['name'] + '.json')
    assert not log_path.exists() and not receipt_path.exists(), 'Refusing to overwrite an attempt'
    assert source_matches(), 'Frozen source changed before command'
    assert git('rev-parse', 'HEAD') == PLAN['base_commit']
    assert all(digest(p) == h for p, h in pre['toolchain']['files'].items()), 'Toolchain changed'
    assert all(digest(p) == h for p, h in pre['runtime_files'].items()), 'Runtime tool changed'
    assert mirrored_links() == pre['dependency_links'], 'Runtime links changed'
    environment = os.environ.copy()
    for key in ('RUSTC_WRAPPER', 'RUSTC_WORKSPACE_WRAPPER', 'RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS', 'LUST_CARGO', 'LUSTC'):
        environment.pop(key, None)
    tools = pathlib.Path(PLAN['toolchain_root'])
    environment.update({'PATH': str(tools / 'bin') + ':' + str(BASE / 't3-runtime/node_modules/.bin') + ':' + environment['PATH'], 'CARGO': str(tools / 'bin/cargo'), 'RUSTC': str(tools / 'bin/rustc'), 'RUSTDOC': str(tools / 'bin/rustdoc'), 'CARGO_HOME': PLAN['cargo_home'], 'CARGO_TARGET_DIR': PLAN['target_dir'], 'CARGO_BUILD_JOBS': '1', 'CARGO_INCREMENTAL': '0', 'CARGO_PROFILE_DEV_DEBUG': '0', 'CARGO_PROFILE_TEST_DEBUG': '0', 'T3_CODE_LS_TEST_TMPDIR': PLAN['fixture_root'], 'TMPDIR': PLAN['fixture_root'], 'T3_CODE_LS_TEST_RUNTIME': str(BASE / 't3-test-runtime'), 'T3_CODE_LS_TOOLCHAIN': PLAN['toolchain_root']})
    os.sched_setaffinity(0, {min(os.sched_getaffinity(0))})
    result = {'kind': 'serialized local project-reducer validation', 'scope': 'diagnostic functional evidence only; not performance or hosted qualification', 'stage': stage['name'], 'command': stage['command'], 'plan_sha256': digest(PLAN_PATH), 'runner_sha256': digest(__file__), 'preflight_sha256': digest(OUT / 'preflight.json'), 'source_review_tree': PLAN['source_review_tree'], 'source_digest': PLAN['source_digest'], 'compiled_inputs_digest': PLAN['compiled_inputs_digest'], 'cpu_affinity': sorted(os.sched_getaffinity(0)), 'timeout_seconds': stage['timeout_seconds'], 'maximum_log_bytes': PLAN['maximum_log_bytes'], 'log_streams': 'stdout and stderr merged without filtering', 'memory_before': memory(), 'selected_environment': {k: environment.get(k) for k in ('CARGO', 'RUSTC', 'RUSTDOC', 'RUSTC_WRAPPER', 'RUSTC_WORKSPACE_WRAPPER', 'RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS', 'LUST_CARGO', 'LUSTC', 'CARGO_HOME', 'CARGO_TARGET_DIR', 'CARGO_BUILD_JOBS', 'CARGO_INCREMENTAL', 'CARGO_PROFILE_DEV_DEBUG', 'CARGO_PROFILE_TEST_DEBUG', 'T3_CODE_LS_TEST_RUNTIME', 'T3_CODE_LS_TEST_TMPDIR', 'TMPDIR')}, 'status': 'running'}
    process = None
    failure = None

    def stop_owned_group():
        if process is None:
            return
        try:
            os.killpg(process.pid, signal.SIGTERM)
        except ProcessLookupError:
            return
        deadline = time.monotonic() + PLAN['termination_grace_seconds']
        while live_group(process.pid) and time.monotonic() < deadline:
            time.sleep(0.1)
        if live_group(process.pid):
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
        process.wait(timeout=10)

    def interrupted(signum, _frame):
        raise InterruptedError(f'supervisor received signal {signum}')

    for signum in (signal.SIGTERM, signal.SIGINT):
        signal.signal(signum, interrupted)
    started = time.monotonic()
    try:
        with log_path.open('wb') as log:
            process = subprocess.Popen(stage['command'], cwd=ROOT, env=environment, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, start_new_session=True)
            result['owned_process_group'] = process.pid
            receipt_path.write_text(json.dumps(result, indent=2) + '\n')
            print(json.dumps({'stage': stage['name'], 'pid': process.pid, 'log': str(log_path)}), flush=True)
            selector = selectors.DefaultSelector()
            selector.register(process.stdout, selectors.EVENT_READ)
            written = 0
            while selector.get_map():
                if time.monotonic() - started > stage['timeout_seconds']:
                    raise TimeoutError('owned command exceeded timeout')
                for key, _mask in selector.select(timeout=0.25):
                    data = os.read(key.fileobj.fileno(), 32768)
                    if not data:
                        selector.unregister(key.fileobj)
                        continue
                    if written + len(data) > PLAN['maximum_log_bytes']:
                        log.write(data[:PLAN['maximum_log_bytes'] - written])
                        raise RuntimeError('owned command exceeded output limit')
                    log.write(data)
                    log.flush()
                    written += len(data)
            process.wait(timeout=max(1, stage['timeout_seconds'] - (time.monotonic() - started)))
        if live_group(process.pid):
            raise RuntimeError('owned process group remained live after command exit')
        if process.returncode == 0 and 'preserve_helper' in stage:
            destination = pathlib.Path(stage['preserve_helper']['destination'])
            assert not destination.exists(), 'Refusing to overwrite preserved helper'
            shutil.copy2(stage['preserve_helper']['source'], destination)
            result['preserved_helper'] = {'path': str(destination), 'bytes': destination.stat().st_size, 'sha256': digest(destination)}
        if 'proof' in stage and pathlib.Path(stage['proof']).exists():
            result['proof'] = {'path': stage['proof'], 'sha256': digest(stage['proof']), 'bytes': pathlib.Path(stage['proof']).stat().st_size}
    except BaseException as error:
        failure = f'{type(error).__name__}: {error}'
        stop_owned_group()
    finally:
        usage = resource.getrusage(resource.RUSAGE_CHILDREN)
        result['verification_errors'] = {}

        def checked(name, check):
            try:
                return check()
            except BaseException as error:
                result['verification_errors'][name] = f'{type(error).__name__}: {error}'
                return False

        result.update({'exit_code': process.returncode if process is not None else None, 'supervisor_failure': failure, 'elapsed_seconds': round(time.monotonic() - started, 3), 'children_max_rss_kib': usage.ru_maxrss, 'children_user_seconds': usage.ru_utime, 'children_system_seconds': usage.ru_stime, 'memory_after': memory(), 'source_unchanged': checked('source', source_matches), 'toolchain_unchanged': checked('toolchain', lambda: all(digest(p) == h for p, h in pre['toolchain']['files'].items())), 'runtime_unchanged': checked('runtime', lambda: all(digest(p) == h for p, h in pre['runtime_files'].items()) and mirrored_links() == pre['dependency_links']), 'owned_live_processes_after': live_group(process.pid) if process is not None else [], 'log_sha256': digest(log_path) if log_path.exists() else None, 'log_bytes': log_path.stat().st_size if log_path.exists() else 0})
        result['status'] = 'passed' if result['exit_code'] == 0 and failure is None and result['source_unchanged'] and result['toolchain_unchanged'] and result['runtime_unchanged'] and not result['owned_live_processes_after'] else 'failed'
        receipt_path.write_text(json.dumps(result, indent=2) + '\n')
        print(json.dumps({k: result[k] for k in ('stage', 'status', 'exit_code', 'supervisor_failure', 'elapsed_seconds', 'children_max_rss_kib', 'source_unchanged', 'owned_live_processes_after', 'log_sha256')}), flush=True)
    return result['status'] == 'passed'


if __name__ == '__main__':
    try:
        successful = preflight() if sys.argv[1] == 'preflight' else run_stage(int(sys.argv[1]))
    except BaseException as error:
        failed = {'status': 'failed', 'stage': sys.argv[1], 'runner_failure': f'{type(error).__name__}: {error}', 'plan_sha256': digest(PLAN_PATH), 'runner_sha256': digest(__file__)}
        path = OUT / ('runner-failure-' + sys.argv[1] + '.json')
        if not path.exists():
            path.write_text(json.dumps(failed, indent=2) + '\n')
        print(json.dumps(failed), flush=True)
        successful = False
    sys.exit(0 if successful else 1)
