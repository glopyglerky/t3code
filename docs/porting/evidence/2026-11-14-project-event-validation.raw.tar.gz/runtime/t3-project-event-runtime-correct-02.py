import datetime
import hashlib
import json
import os
import pathlib
import subprocess

BASE = pathlib.Path('/workspace/scratch/fcf5fdf8376a')
ROOT = BASE / 't3-project-event-reducer'


def sha(path):
    return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()


def encoded(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':')).encode()


def state(path, require_link=False):
    if require_link:
        assert path.is_symlink(), str(path)
    kind = 'symlink' if path.is_symlink() else 'directory' if path.is_dir() else 'file'
    result = {'kind': kind, 'resolved': str(path.resolve(strict=True))}
    if path.is_symlink():
        result['link'] = os.readlink(path)
    elif path.is_file():
        result['sha256'] = sha(path)
    return result


audit_path = BASE / 't3-project-event-runtime-audit-01.json'
old_path = BASE / 't3-project-event-dependencies.json'
freeze_path = BASE / 't3-project-event-source-02.json'
receipt_path = BASE / 't3-project-event-runtime-correction-02.json'
new_path = BASE / 't3-project-event-dependencies-02.json'
assert sha(audit_path) == '9405d28c64f01243f0600cde98978de40cf2778fd872a63ca23d5dd98a94566a'
assert sha(freeze_path) == '3d64db7dfcbdbaf813d6d93798b5d50dc9ef18072a343ea68987c02eabb8b614'
audit = json.loads(audit_path.read_text())
old = json.loads(old_path.read_text())
source = json.loads(freeze_path.read_text())
donor = pathlib.Path(old['source'])
assert pathlib.Path(old['destination']) == ROOT
assert sha(old_path) == audit['dependency_receipt_sha256']
assert not receipt_path.exists() and not new_path.exists()
assert all(sha(ROOT / f['path']) == f['sha256'] for f in source['files'])
assert subprocess.check_output(['git', 'write-tree'], cwd=ROOT, text=True).strip() == source['review_tree']
source_before = {f['path']: sha(ROOT / f['path']) for f in source['files']}
links_before = {p: state(ROOT / p, True) for p in old['links']}
donor_before = {p: state(donor / p) for p in old['links']}
changes = []
overrides = {}
removed = []
for record in audit['records']:
    relative = record['path']
    assert links_before[relative]['resolved'] == record['target']
    if record['class'] != 'outside-store-package':
        continue
    assert record['owner'] == '.' and relative.startswith('node_modules/')
    candidates = record['locked_workspace_candidates']
    targets = {c['target'] for c in candidates}
    item = {'path': relative, 'package_name': record['name'], 'package_version': record['version'], 'before': links_before[relative], 'donor_before': donor_before[relative]}
    if targets:
        assert len(targets) == 1
        target = pathlib.Path(next(iter(targets)))
        target.relative_to(donor / 'node_modules/.pnpm')
        assert target.resolve(strict=True) == target
        assert sha(target / 'package.json') == record['manifest_sha256']
        meta = json.loads((target / 'package.json').read_text())
        assert meta['name'] == record['name'] and meta['version'] == record['version']
        for candidate in candidates:
            assert (ROOT / candidate['declared_link']).resolve(strict=True) == target
            assert sha(target / 'package.json') == candidate['manifest_sha256']
        item.update({'action': 'repoint', 'target': str(target), 'manifest_sha256': record['manifest_sha256'], 'locked_workspace_candidates': candidates})
        overrides[relative] = {'target': str(target), 'manifest_sha256': record['manifest_sha256']}
    else:
        assert relative in ('node_modules/@modelcontextprotocol/sdk', 'node_modules/@anthropic-ai/sdk')
        item.update({'action': 'remove-owned-extra-alias', 'reason': 'No direct production workspace dependency/import; production peer dependencies remain in their existing pnpm targets.'})
        removed.append(relative)
    changes.append(item)
assert len(changes) == 24 and len(overrides) == 22 and len(removed) == 2
receipt = {'version': 1, 'scope': 'Only approved isolated root aliases; donor links and package contents are unchanged. No source or installer operation.', 'status': 'running', 'created_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'script_sha256': sha(__file__), 'audit': {'file': str(audit_path), 'sha256': sha(audit_path)}, 'source_freeze': {'file': str(freeze_path), 'sha256': sha(freeze_path), 'tree': source['review_tree']}, 'original_dependencies': {'file': str(old_path), 'sha256': sha(old_path)}, 'source_before': source_before, 'isolated_links_before': links_before, 'donor_links_before': donor_before, 'changes': changes}
receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
try:
    for item in changes:
        path = ROOT / item['path']
        assert state(path, True) == item['before']
        if item['action'] == 'repoint':
            temporary = path.with_name(path.name + '.project-event-approved-relink')
            assert not os.path.lexists(temporary)
            temporary.symlink_to(item['target'])
            os.replace(temporary, path)
        else:
            path.unlink()
        item['after'] = state(path, True) if path.is_symlink() else None
        item['donor_after'] = state(donor / item['path'])
        assert item['donor_after'] == item['donor_before']
    new_links = [p for p in old['links'] if p not in removed]
    links_after = {p: state(ROOT / p, True) for p in new_links}
    donor_after = {p: state(donor / p) for p in old['links']}
    assert donor_after == donor_before
    for relative, before in links_before.items():
        if relative in removed:
            assert not os.path.lexists(ROOT / relative)
        elif relative in overrides:
            assert links_after[relative]['resolved'] == overrides[relative]['target']
        else:
            assert links_after[relative] == before
    assert len(new_links) == 790
    source_after = {f['path']: sha(ROOT / f['path']) for f in source['files']}
    assert source_after == source_before
    assert subprocess.check_output(['git', 'write-tree'], cwd=ROOT, text=True).strip() == source['review_tree']
    new = {'source': str(donor), 'destination': str(ROOT), 'links': new_links, 'original_receipt': str(old_path), 'original_receipt_sha256': sha(old_path), 'overrides': overrides, 'removed': removed, 'donor_links_digest': hashlib.sha256(encoded(donor_after)).hexdigest(), 'correction_receipt': str(receipt_path)}
    new_path.write_text(json.dumps(new, indent=2) + '\n')
    receipt.update({'status': 'passed', 'completed_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'isolated_links_after': links_after, 'donor_links_after': donor_after, 'donor_unchanged': True, 'source_after': source_after, 'source_unchanged': True, 'new_dependencies': {'file': str(new_path), 'sha256': sha(new_path)}, 'counts': {'repointed': 22, 'removed': 2, 'remaining': 790}})
except BaseException as error:
    receipt.update({'status': 'failed', 'failure': f'{type(error).__name__}: {error}'})
    receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
    raise
receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'status': receipt['status'], 'counts': receipt['counts'], 'correction_receipt': str(receipt_path), 'sha256': sha(receipt_path), 'dependencies_receipt': str(new_path), 'dependencies_sha256': sha(new_path), 'source_unchanged': True, 'donor_unchanged': True}))
