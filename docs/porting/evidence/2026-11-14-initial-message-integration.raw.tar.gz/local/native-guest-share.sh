#!/bin/sh
printf "call\n" >> /workspace/scratch/fcf5fdf8376a/t3-initial-message-checks/native-guest-share.calls
exec /workspace/scratch/fcf5fdf8376a/t3-target/debug/t3-code-ls-guest-share "$@"
