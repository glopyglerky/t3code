#!/usr/bin/env python3
"""Retain completed CI evidence and render every measured row; never qualify a commit."""
import gzip
import hashlib
import importlib.util
import io
import json
import math
from pathlib import Path, PurePosixPath
import re
import shutil
import tarfile
import zipfile

ROOT = Path('/workspace/scratch/fcf5fdf8376a')
REPO = ROOT / 't3-browser-diagnostic-lint'
EVIDENCE = ROOT / 't3-ci-evidence'
UPSTREAM = 'f751c8488f7ca1e659e44ef12b05861c1bcf9bfb'
HELPER = '1758f86962de09120a5b72005469809c5e6c7da3ada26585f4e0a41666c7351c'
CASES = [
    dict(label='digest-hex', title='Hosted digest hex experiment', short='a0eee4f2',
         commit='a0eee4f2a0e47bf080b0d1514dfb3cbcb51fefce', tree='86a8fe7990cc663fe226637b39b51ad1f07e45ed',
         parent='4b5719f34a8b76a23f3c77982940cea67234186c', run='43625465013',
         perf='a0eee4f2-performance.zip', perf_id=14126122080, perf_size=219423,
         perf_sha='26dbe0c3fae812ad4ada760ac8ebc9e3f7239437d8343682a3e704eb7ec521cc',
         app='a0eee4f2-application-proof.zip', app_id=14126053422, app_size=2706,
         app_sha='96f828be019c3afa5f52e3fd1bd9547cd8106d5c28413fcc1f4986c410f64442',
         jobs='digest-jobs.json', artifacts='digest-artifacts.json', hook_passed=False,
         archive='2026-11-14-digest-hook-failure.raw.tar.gz'),
    dict(label='browser-type', title='Hosted browser type successor', short='b240bdc1',
         commit='b240bdc11b11237dba2c0134401eac5e0e4a096f', tree='2211c123d4a5a255ce03948c448b5eea6a4c5581',
         parent='a0eee4f2a0e47bf080b0d1514dfb3cbcb51fefce', run='43626660476',
         perf='b240bdc-performance.zip', perf_id=14126779134, perf_size=219290,
         perf_sha='bdc793bf9fdbb4df16e047fe7713d6c9d4d433986820b37a8be3751c1454b931',
         app='b240bdc1-application-proof.zip', app_id=14126278678, app_size=661827,
         app_sha='ab86a7901487fd8059c1d67c375f0a31c1d1fc7300ec52698c7fbcf411189b48',
         jobs='browser-type-jobs.json', artifacts='browser-type-artifacts.json', hook_passed=True,
         archive='2026-11-14-browser-type-hosted.raw.tar.gz'),
]

def require(value, message):
    if not value:
        raise ValueError(message)

def sha(value):
    return hashlib.sha256(value).hexdigest()

def safe_zip(name, expected, size):
    raw = (EVIDENCE / name).read_bytes()
    require(len(raw) == size and sha(raw) == expected, 'ZIP identity: ' + name)
    z = zipfile.ZipFile(io.BytesIO(raw))
    require(len(z.namelist()) == len(set(z.namelist())), 'duplicate ZIP entry')
    require(sum(e.file_size for e in z.infolist()) < 25_000_000, 'unbounded ZIP')
    for e in z.infolist():
        path = PurePosixPath(e.filename)
        require(not path.is_absolute() and '..' not in path.parts and '\\' not in e.filename
                and not e.is_dir() and ((e.external_attr >> 16) & 0o170000) != 0o120000, 'unsafe ZIP path')
    return z

def close(a, b, label):
    require(math.isclose(a, b, rel_tol=1e-12, abs_tol=1e-12), label)

spec = importlib.util.spec_from_file_location('retained_performance', REPO / 'tools/ci_performance.py')
validator = importlib.util.module_from_spec(spec)
spec.loader.exec_module(validator)
contract = validator.CONTRACT

def verify(case):
    z = safe_zip(case['perf'], case['perf_sha'], case['perf_size'])
    r = json.loads(z.read('performance.json'))
    for key, value in dict(source_commit=case['commit'], source_tree=case['tree'], upstream_commit=UPSTREAM,
                           ci_run_id=case['run'], ci_run_attempt='1', native_build_run_attempt='1',
                           status='regressed', qualifies=False, mode='qualify', source_tree_dirty=False,
                           source_tree_dirty_after=False, executable_sha256=HELPER,
                           compiler_provenance='verified-ci-manifest', compiler_identity=None,
                           compiler_route='bluefe-rustc-via-lustr', build_profile='release').items():
        require(r.get(key) == value, key)
    for key in ('pairs', 'warmups', 'samples', 'seed', 'bootstrap_resamples', 'confidence', 'comparison_ratio', 'fixture'):
        require(r['configuration'][key] == contract[key], 'configuration ' + key)
    require(r['configuration']['phase'] == 'all' and r['correctness']['status'] == 'passed', 'complete correctness')
    validator.validate_baseline(r)
    orders = validator.expected_orders(contract['pairs'], contract['seed'])
    measurements = validator.validate_runs(r, orders)
    for run in r['runs']:
        name = (f"validation-{run['backend']}.json" if run['purpose'] == 'validation' else
                f"pair-{run['pair']:02d}-{run['backend']}.json")
        require(json.loads(z.read(name)) == run, 'raw worker binding ' + name)
    require([(x['id'], x['phase'], x['metric']) for x in r['scenarios']] ==
            [(x['id'], x['phase'], x['metric']) for x in contract['scenarios']], 'scenario order')
    tails = {}
    for index, row in enumerate(r['scenarios']):
        operation = row['id'].removesuffix('.p95')
        probability = .95 if row['metric'] == 'p95' else .5
        def values(pair, backend):
            result = measurements[(pair, backend)]
            return [result['cold_open_ms']] if row['phase'] == 'cold' else result['samples'][operation]
        require([x['pair'] for x in row['pairs']] == list(range(8)), 'pair IDs')
        require([x['order'] for x in row['pairs']] == orders, 'pair order')
        ratios = []
        for pair in row['pairs']:
            for backend in ('upstream', 'native'):
                close(pair[backend + '_ms'], validator.quantile(values(pair['pair'], backend), probability), 'pair raw timing')
            ratio = pair['native_ms'] / pair['upstream_ms']
            close(pair['ratio'], ratio, 'pair ratio')
            ratios.append(ratio)
        ratio, interval = validator.paired_comparison(ratios, contract['seed'] + index)
        close(row['ratio'], ratio, 'geometric ratio')
        for a, b in zip(row['confidence_interval'], interval):
            close(a, b, 'bootstrap interval')
        require(row['status'] == 'regressed' and interval[0] > 1, 'regression verdict')
        for backend in ('upstream', 'native'):
            pooled = [v for pair in range(8) for v in values(pair, backend)]
            require(row[backend]['samples'] == len(pooled), 'sample count')
            for key, value in [('median_ms', validator.quantile(pooled, .5)),
                               ('p95_ms', validator.quantile(pooled, .95)), ('max_ms', max(pooled)),
                               ('sequential_requests_per_second', 1000 * len(pooled) / sum(pooled))]:
                close(row[backend][key], value, 'pooled ' + key)
            if row['metric'] != 'p95':
                tails.setdefault(operation, {})[backend] = {
                    'samples': len(pooled), 'over_ms': {str(v): sum(x > v for x in pooled) for v in (5, 10, 50, 100)}}
    app = safe_zip(case['app'], case['app_sha'], case['app_size'])
    hook = json.loads(app.read('commit-hook-proof/proof.json'))
    require((hook['source_commit'], hook['source_tree'], hook['first_parent'], hook['ci_run_id'], hook['ci_run_attempt']) ==
            (case['commit'], case['tree'], case['parent'], case['run'], '1'), 'hook identity')
    require(hook['status'] == ('passed' if case['hook_passed'] else 'failed'), 'hook verdict')
    require(hook['hook_result'] == {'exit_code': 0 if case['hook_passed'] else 1, 'timed_out': False}, 'hook result')
    require(hook['restoration'] == dict(head=case['commit'], index_tree=case['tree'], detached=True, clean=True), 'restoration')
    for channel in ('stdout', 'stderr'):
        data = app.read(f'commit-hook-proof/proof.{channel}.log')
        require(len(data) == hook[channel]['bytes'] and sha(data) == hook[channel]['sha256'], 'bound hook log')
    functional = dict(hook=hook, hook_proof_sha256=sha(app.read('commit-hook-proof/proof.json')))
    if case['hook_passed']:
        require(hook['changed_paths'] == ['apps/web/scripts/hybrid-client-browser-diagnostics.ts',
                                         'docs/porting/2026-11-14-browser-diagnostic-type-fix.md'], 'narrow inherited hook scope')
        stderr = app.read('commit-hook-proof/proof.stderr.log').decode()
        require(all('✔ ' + cmd in stderr for cmd in ('vp fmt', 'vp lint', 'vp run knip:check')), 'actual hook tasks')
        application = json.loads(app.read('hybrid-proof/application.json'))
        browser = json.loads(app.read('hybrid-proof/client/native/proof.json'))
        summary = json.loads(app.read('hybrid-proof/client/summary.json'))
        require(application['status'] == browser['status'] == summary['status'] == 'passed', 'application result')
        require(application['source_commit'] == case['commit'] and not application['source_tree_dirty'], 'application source')
        require(application['native_manifest_sha256'] == r['native_manifest_sha256'], 'native manifest')
        require(len(application['checks']) == 3 and all(x['status'] == 'passed' and x['exit_code'] == 0
                                                       for x in application['checks']), 'application checks')
        require(summary['passed'] == ['native'] and browser['error'] is None and len(browser['completedSteps']) == 7, 'browser scope')
        for source in (browser['source'], summary['source']):
            require(source['commit'] == case['commit'] and not source['dirty'], 'browser source')
            manifest = source['nativeManifest']
            for field in ('source_commit', 'source_tree', 'source_tree_dirty', 'compiler_route', 'build_profile', 'toolchain_lock_sha256', 'ci_run_id', 'ci_run_attempt'):
                require(manifest[field] == r[field], 'manifest binding ' + field)
            require(manifest['files']['t3-code-ls-db'] == HELPER, 'same helper')
        snapshots = browser['completedSnapshots']
        require([x['checkpoint'] for x in snapshots] == ['initial', 'client-reload', 'server-restart'], 'checkpoints')
        for x in snapshots:
            require(all(x[k] == v for k, v in browser['turnIdentity'].items()), 'same completed identity')
            require(all(x[k] == 'completed' for k in ('runStatus', 'attemptStatus', 'providerTurnStatus')), 'completion')
            require(all(x[k] == snapshots[0][k] for k in ('runCompletedAt', 'attemptCompletedAt', 'providerTurnCompletedAt')), 'completion timestamps')
        require(all(x['engine'] == 'omdb' and x['inspector'] == 'read-only-local' for x in browser['persistence']), 'native inspection')
        require(any(x['closedDatabaseUnchanged'] is True for x in browser['persistence']), 'closed inspection')
        d = browser['browserDiagnostics']
        require(len(d['events']) == 12 and len(d['phases']) == 11 and not d['truncated']
                and d['droppedEvents'] == d['droppedPhases'] == d['truncatedValues'] == 0, 'bounded diagnostics')
        functional.update(browser_proof_sha256=sha(app.read('hybrid-proof/client/native/proof.json')),
                          completed_snapshots=snapshots, browser_errors=browser['browserErrors'], browser_diagnostics=d,
                          persistence=browser['persistence'], completed_steps=browser['completedSteps'])
    else:
        require(len(app.namelist()) == 3, 'no invented application execution')
    native_log = (EVIDENCE / (case['short'] + '-native-job.log')).read_bytes()
    results = re.findall(rb'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', native_log)
    require(len(results) == 37 and sum(int(x[0]) for x in results) == 421 and
            sum(int(x[1]) + int(x[2]) for x in results) == 0, 'Rust result counts')
    jobs = json.loads((EVIDENCE / case['jobs']).read_text())
    require(all(j['status'] == 'completed' for j in jobs), 'final jobs')
    result = dict(schema_version=1, scope='Retained evidence verification, not qualification or a new workload',
                  source=case, performance_report_sha256=sha(z.read('performance.json')), raw_workers=18,
                  bootstrap_resamples=10000, all_rows_regressed=True, tails=tails, functional=functional,
                  rust_tests_passed=421, rust_result_groups=37, jobs=jobs)
    return r, result

def archive(case, result):
    summary_name = case['short'] + '-retained-evidence.json'
    (EVIDENCE / summary_name).write_text(json.dumps(result, indent=2, ensure_ascii=False) + '\n')
    names = [case['app'], case['jobs'], case['artifacts'], summary_name,
             case['short'] + '-application-job.log', case['short'] + '-native-job.log',
             case['short'] + '-qualification-job.log']
    if case['short'] == 'a0eee4f2':
        names.append(case['short'] + '-performance-job.log')
    payloads = {n: (EVIDENCE / n).read_bytes() for n in names}
    payloads['retained-evidence-verifier.py'] = Path(__file__).read_bytes()
    manifest = dict(schema_version=1, source_commit=case['commit'], run_id=case['run'], run_attempt=1,
                    scope='Original synthetic CI artifacts and decoded job logs; no database or executable payloads',
                    files=[dict(path=n, bytes=len(b), sha256=sha(b)) for n, b in sorted(payloads.items())])
    payloads['manifest.json'] = (json.dumps(manifest, indent=2) + '\n').encode()
    target = REPO / 'docs/porting/evidence' / case['archive']
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open('wb') as out, gzip.GzipFile(fileobj=out, mode='wb', filename='', mtime=0) as gz, tarfile.open(fileobj=gz, mode='w') as tar:
        for name, raw in sorted(payloads.items()):
            info = tarfile.TarInfo(name); info.size = len(raw); info.mode = 0o644; info.mtime = 0
            tar.addfile(info, io.BytesIO(raw))
    return dict(bytes=target.stat().st_size, sha256=sha(target.read_bytes()), entries=len(payloads))

def render(case, r, result, bundle):
    f = lambda v: f'{v:.6f}'
    rows = ['| Workload / statistic | Stock ms | Native ms | Paired ratio | 95% interval | Verdict |',
            '| --- | ---: | ---: | ---: | --- | --- |']
    for row in r['scenarios']:
        metric = 'p95_ms' if row['metric'] == 'p95' else 'median_ms'
        rows.append(f"| {row['id']} | {f(row['upstream'][metric])} | {f(row['native'][metric])} | {f(row['ratio'])} | [{f(row['confidence_interval'][0])}, {f(row['confidence_interval'][1])}] | regressed |")
    distributions = ['| Workload | Stock median / p95 / max ms | Native median / p95 / max ms |', '| --- | --- | --- |']
    tails = ['| Workload | >5 ms | >10 ms | >50 ms | >100 ms |', '| --- | ---: | ---: | ---: | ---: |']
    for row in r['scenarios']:
        if row['metric'] == 'p95':
            continue
        cells = [' / '.join(f(row[b][k]) for k in ('median_ms', 'p95_ms', 'max_ms')) for b in ('upstream', 'native')]
        distributions.append(f"| {row['id']} | {cells[0]} | {cells[1]} |")
        t = result['tails'][row['id']]
        cells = [f"{t['upstream']['over_ms'][str(v)]} / {t['native']['over_ms'][str(v)]}" for v in (5, 10, 50, 100)]
        tails.append('| ' + row['id'] + ' | ' + ' | '.join(cells) + ' |')
    measured = {b: [x for x in r['runs'] if x['purpose'] == 'measurement' and x['backend'] == b] for b in ('upstream', 'native')}
    cold = ['| Component | Stock median ms | Native median ms |', '| --- | ---: | ---: |']
    for name in ('service_open_ms', 'sidebar-shell', 'history-window', 'message-search', 'accent-search', 'visit-commit'):
        cells = []
        for backend in ('upstream', 'native'):
            v = [x['result']['service_open_ms'] if name == 'service_open_ms' else x['result']['cold_first_operations_ms'][name] for x in measured[backend]]
            cells.append(f(validator.quantile(v, .5)))
        cold.append('| ' + name + ' | ' + ' | '.join(cells) + ' |')
    memory = ['| Advisory observation over eight workers | Stock | Native |', '| --- | --- | --- |']
    for field, label in [('process_tree_peak_rss_kib', 'Sampled process-tree peak RSS range (KiB)'), ('node_peak_rss_kib', 'Node peak RSS range (KiB)')]:
        cells = []
        for b in ('upstream', 'native'):
            v = [x[field] for x in measured[b]]
            cells.append(f'{min(v):,}–{max(v):,}' if all(x is not None for x in v) else 'unavailable in at least one worker; see raw evidence')
        memory.append('| ' + label + ' | ' + ' | '.join(cells) + ' |')
    memory.append('| Observed GC total (ms) | ' + ' | '.join(f(sum(x['gc']['duration_ms'] for x in measured[b])) for b in ('upstream', 'native')) + ' |')
    warnings = [f"`{x['id']}` ({x['relative_interval_width']*100:.3f}% relative width)" for x in r['scenarios'] if x['precision_warning']]
    warning = ('Precision warnings remain on ' + ', '.join(warnings) + '. They do not waive a row; every interval is wholly above 1.0.') if warnings else 'No row has a precision warning in this attempt; every interval is wholly above 1.0.'
    host = r['host']; fs = host['fixture_filesystem']
    jobs = ['| Job | ID | Result |', '| --- | --- | --- |']
    for j in result['jobs']:
        jobs.append(f"| {j['name']} | [{j['id']}](https://github.com/glopyglerky/t3code-ls/actions/runs/{case['run']}/job/{j['id']}) | {j['conclusion']} |")
    hook = result['functional']['hook']
    if case['hook_passed']:
        intro = '''The only change from a0 is the browser diagnostic optional-property type and its note.
The release database helper is byte-for-byte identical to a0. The two jobs ran
on different CPU models, so their differences do not establish a speed effect
from that type change or a causal gain from the earlier digest optimization.'''
        functional = f'''The native/source/component and adapter jobs passed. The native log contains
421 passed Rust tests across 37 result groups, including 203 storage unit tests,
with zero failures and zero ignored tests. The normal pre-commit hook passed in
{hook['elapsed_seconds']:.3f} seconds and its stderr explicitly completed fmt,
lint and Knip. Hook proof SHA-256:
`{result['functional']['hook_proof_sha256']}`.

That hook staged only two first-parent paths: the diagnostic helper and the
type-fix note. It did not stage the inherited diagnostic test or acceptance
runner containing a0's eight lint findings. Successful Knip and the application
flow do not establish lint cleanliness for those omitted files. The
[inherited-hook correction](../../porting/2026-11-14-inherited-hook-coverage.md)
records this coverage gap and the required broader source selection.

The application typecheck, bundle/native selection and original Linux browser
flow passed. Setup, local project creation, controlled ACP approval/completed
turn, client reload and same-state server restart completed through the normal
client. All three snapshots retain identical completed run/attempt/provider-turn
identities and completion timestamps. Read-only native inspection checked omdb
rows/event heads and the absence of application SQLite files; the closed-state
inspection reported unchanged database bytes. Browser proof SHA-256:
`{result['functional']['browser_proof_sha256']}`.

The persisted browser evidence contains six legacy error entries, twelve bounded
structured events and eleven phases. No cap was reached or entry dropped. Initial
setup includes a WebSocket HTTP-authentication failure and a shell GET abort.
The server-restart-starting phase records three connection-refused errors and
two HTTP 502 entries, with environment GET and traces POST events between
18:46:14.975Z and the ready marker at 18:46:21.738Z. These are phase associations,
not established causes or deduplicated incident counts. No error event is
recorded after ready within the persisted window. Cleanup remains outside that
window. This is neither an error-free claim nor Windows/macOS/mobile or
every-provider acceptance.
'''
    else:
        intro = '''The sole Rust production change from the sidebar-correctness parent is the
final lowercase hex encoding in `request_digest`. Canonical hash inputs, stored
keys, request receipts, schema, durability and limits remain unchanged. The
[decision and local compatibility evidence](../../porting/2026-11-14-request-digest-hex.md)
remain separate from this hosted result. Browser diagnostics were also added
for later failure investigation; they do not change the timed API workload.

This is a comparison against stock, not a controlled before/after digest test.
The parent was measured on another host. A smaller stock/native ratio across
different runs cannot prove a causal improvement from the hex change.'''
        functional = f'''The native/source/component and production adapter jobs passed. The native log
contains 421 passed Rust tests across 37 result groups, including 203 storage
unit tests, with zero failures and zero ignored tests.

The application job stopped at its mandatory normal hook. Formatting passed;
lint reported eight findings in Node namespace imports and platform/architecture
access. Knip was started but did not complete successfully. The hook exited 1
after {hook['elapsed_seconds']:.3f} seconds without timeout, then restored the
exact clean detached candidate HEAD/index/tree. Hook proof SHA-256:
`{result['functional']['hook_proof_sha256']}`.

No client typecheck, bundle or browser flow ran for this source. The separately
noticed optional-property type issue was a source-review finding, not the
observed failure. The [hook failure and correction record](../../porting/2026-11-14-inherited-hook-coverage.md)
preserves the eight actual findings and explains why a small successor's
first-parent hook is insufficient to cover inherited failures.
'''
    doc = f'''# {case['title']}

**All eleven latency rows regressed against stock T3 Code.** Correctness,
rollback/readback and reopen checks passed. Final qualification failed; main
remained unchanged. An inconclusive result would also block qualification.

Measured source: `{case['commit']}`, tree
`{case['tree']}`, sole parent
`{case['parent']}`. The frozen oracle is upstream
`{UPSTREAM}`, tree `{r['upstream_tree']}`.
Run: [{case['run']}, attempt 1](https://github.com/glopyglerky/t3code-ls/actions/runs/{case['run']}).

{intro}

## Exact retained evidence

- [Original performance ZIP](2026-11-14-{case['label']}.raw.zip): artifact
  `{case['perf_id']}`, {case['perf_size']:,} bytes, SHA-256
  `{case['perf_sha']}`. All 74 original entries are unchanged.
- Report SHA-256: `{result['performance_report_sha256']}`.
- [Functional evidence and decoded job logs](../../porting/evidence/{case['archive']}):
  {bundle['bytes']:,} bytes, {bundle['entries']} regular entries, SHA-256
  `{bundle['sha256']}`. Its manifest binds every payload.
- Original application artifact `{case['app_id']}`: {case['app_size']:,} bytes,
  SHA-256 `{case['app_sha']}`.

Verification matched all eighteen raw worker files to the embedded records,
derived retained correctness/cardinality witnesses, recomputed every pooled
statistic and paired ratio, and reproduced every 10,000-resample interval. The
verification script and result are retained with the functional evidence.
This verifies the failed evidence; it does not create a qualification receipt.

## Fixed method and production identity

Eight balanced pairs use seed `1949524847`, three excluded warmups and twelve
measured calls per warm workload. All eleven rows gate independently at native
/ stock ratio 1.0 with paired 95% confidence. Warm distributions each contain
96 calls; cold service acquisition plus the first API cycle contains eight.
The fixed fixture has 256 normal threads plus one archived write thread, 3,000
search messages plus one input, 1,500 turn items and 1,024-byte reasoning payloads.
The pristine stock export and native adapters use the same frozen production
pnpm graph; {len(r['baseline']['external_dependencies'])} external dependency descriptors and per-workspace resolutions
were verified. Source was clean before and after every complete attempt.

The actual `Omdb.make` / native projection and search services include IPC and
serialization. Native commits retain Immediate acknowledgement; stock retains
its normal SQLite WAL/NORMAL settings. Result verification, rollback and reopen
run unchanged. Warm fingerprint checks remain outside each API timer. Cold
means a fresh process/service, not a flushed OS page cache.

Compiler provenance is `verified-ci-manifest`; producer and measurement attempts
are both 1. That status binds the actual source/run/helper/lock/manifest fields,
not a compiler origin inferred from arbitrary executable bytes. Observed
`compiler_identity` remains null and expected pinned identity remains separate.

- Helper SHA-256: `{r['executable_sha256']}`.
- Native release manifest SHA-256: `{r['native_manifest_sha256']}`.
- Toolchain lock SHA-256: `{r['toolchain_lock_sha256']}`.
- Qualification policy digest: `{r['policy_digest']}`.

## Every qualification row

Values are pooled median or p95 milliseconds as labeled. Ratios are geometric
means of paired per-worker ratios and need not equal the ratio of pooled values.

{chr(10).join(rows)}

{warning}

## Complete pooled distributions and tails

{chr(10).join(distributions)}

Each count below is stock / native calls strictly above the threshold. Cold has
eight samples per side; every warm workload has 96. No outlier is removed.

{chr(10).join(tails)}

## Cold service components

Component medians do not sum exactly to the median cold cycle.

{chr(10).join(cold)}

## Host and advisory observations

The runner reported {host['cpu_model']}, {host['cpus']} CPUs,
Linux {host['release']}, {host['total_memory_bytes']:,} bytes of memory and
Node {host['node']}. Load observations were `{host['load_before']}` before and
`{host['load_after']}` after. Filesystem type was `{fs['before_setup']['type_id_hex']}`
with no reported friendly name and {int(fs['before_setup']['block_size_bytes']):,}-byte blocks.
Available blocks were {int(fs['before_setup']['available_blocks']):,} before setup,
{int(fs['after_workers']['available_blocks']):,} after workers and
{int(fs['after_cleanup']['available_blocks']):,} after cleanup. These observations
do not establish an otherwise idle host, physical device or power-loss guarantee.

{chr(10).join(memory)}

The 25 ms process-tree samples may miss peaks and double-count shared pages.
Some samples observe processes during exit and report unavailable reads; those
reasons remain in the raw evidence. Node peak RSS uses a separate method and
excludes helper memory. Do not subtract the two series to infer exact helper
usage. Memory/GC values are advisory, not memory or safety qualification.

## Functional gates and remaining scope

{functional}
{chr(10).join(jobs)}

The final receipt rejected the failed planned {'application' if not case['hook_passed'] else 'performance'} job. No qualified
receipt or main promotion followed. Every prior slowdown and failed attempt
remains retained. The fixed workload, threshold, durability settings and sample
count were not changed to obtain acceptance. A separate same-host before/after
design is required to decide whether the digest experiment merits retention;
this report makes no such causal speed claim.
'''
    target = REPO / f"docs/performance/measurements/2026-11-14-{case['label']}.md"
    target.write_text(doc)
    shutil.copyfile(EVIDENCE / case['perf'], target.with_suffix('.raw.zip'))
    return dict(path=str(target.relative_to(REPO)), bytes=target.stat().st_size, sha256=sha(target.read_bytes()))

for case in CASES:
    report, result = verify(case)
    bundle = archive(case, result)
    print(json.dumps(dict(report=render(case, report, result, bundle), archive=bundle)))
