import ctypes
import hashlib
import json
import os
from pathlib import Path
import resource
import signal
import subprocess
import sys
import time

ROOT = Path('/workspace/scratch/fcf5fdf8376a')
REPO = ROOT / 't3-browser-diagnostic-lint'
OUT = ROOT / 't3-hook-policy-check-02'
MANIFEST = ROOT / 't3-inherited-hook-coverage-source-02.json'
LIMIT = 16 * 1024 * 1024
TIMEOUT = 180
manifest = json.loads(MANIFEST.read_text())
OUT.mkdir(exist_ok=False)
affinity = min(os.sched_getaffinity(0))
os.sched_setaffinity(0, {affinity})
libc = ctypes.CDLL(None, use_errno=True)
subreaper = libc.prctl(36, 1, 0, 0, 0) == 0

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def source():
    values = {item['path']: sha(REPO / item['path']) for item in manifest['files']}
    assert all(values[x['path']] == x['sha256'] for x in manifest['files'])
    return values

def process_table():
    values = {}
    for entry in Path('/proc').iterdir():
        if not entry.name.isdigit():
            continue
        try:
            text = (entry / 'stat').read_text().rsplit(')', 1)[1].split()
            values[int(entry.name)] = (int(text[1]), int(text[19]))
        except (FileNotFoundError, ProcessLookupError, PermissionError, ValueError, IndexError):
            pass
    return values

before = source()
command = [sys.executable, '-B', '-m', 'unittest', '-f', '-v',
           'test_ci_commit_hooks', 'test_ci_history', 'test_ci_workflow',
           'test_ci_plan', 'test_ci_receipt', 'test_ci_promotion']
env = dict(os.environ, PYTHONPATH=str(REPO / 'tools'), PYTHONDONTWRITEBYTECODE='1')
stdout_path, stderr_path = OUT / 'stdout.log', OUT / 'stderr.log'
record = dict(schema_version=1, scope='Six dependency-free hook/history/plan/receipt/promotion policy suites; not application or speed acceptance',
              source_manifest=str(MANIFEST), source_manifest_sha256=sha(MANIFEST), source_tree=manifest['tree'],
              source_before=before, command=command, cwd=str(REPO), affinity=[affinity],
              timeout_seconds=TIMEOUT, output_limit_bytes=LIMIT, subreaper=subreaper,
              python=sys.executable, python_sha256=sha(Path(sys.executable).resolve()))
start = time.monotonic()
owned = {}
failure = None
with stdout_path.open('xb') as out, stderr_path.open('xb') as err:
    child = subprocess.Popen(command, cwd=REPO, env=env, stdout=out, stderr=err, start_new_session=True)
    try:
        while child.poll() is None:
            table = process_table()
            parents = {os.getpid(), child.pid, *owned}
            while True:
                found = {pid: value[1] for pid, value in table.items() if value[0] in parents and pid != os.getpid()}
                new = set(found) - parents
                owned.update(found)
                if not new:
                    break
                parents.update(new)
            if time.monotonic() - start > TIMEOUT:
                failure = 'owned timeout'; break
            if stdout_path.stat().st_size + stderr_path.stat().st_size > LIMIT:
                failure = 'owned output bound'; break
            time.sleep(.1)
    except BaseException as error:
        failure = repr(error)
    finally:
        if failure or child.poll() is None:
            try: os.killpg(child.pid, signal.SIGTERM)
            except ProcessLookupError: pass
            try: child.wait(timeout=3)
            except subprocess.TimeoutExpired: pass
        table = process_table()
        remaining = []
        for pid, born in owned.items():
            if pid in table and table[pid][1] == born:
                remaining.append(pid)
                try: os.kill(pid, signal.SIGKILL)
                except ProcessLookupError: pass
        if child.poll() is None:
            try: os.killpg(child.pid, signal.SIGKILL)
            except ProcessLookupError: pass
        child.wait(timeout=5)
        while True:
            try:
                pid, _ = os.waitpid(-1, os.WNOHANG)
                if not pid: break
            except ChildProcessError:
                break
record.update(exit_code=child.returncode, elapsed_seconds=round(time.monotonic()-start, 3),
              supervisor_failure=failure, tracked_descendants=len(owned), cleanup_pids=remaining,
              max_child_rss_kib=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss,
              source_after=source())
record['source_unchanged'] = record['source_before'] == record['source_after']
record['status'] = 'passed' if child.returncode == 0 and failure is None and record['source_unchanged'] else 'failed'
record['logs'] = {name: dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path))
                  for name, path in [('stdout',stdout_path),('stderr',stderr_path)]}
(OUT / 'receipt.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({key:record[key] for key in ('status','exit_code','elapsed_seconds','supervisor_failure','source_unchanged','max_child_rss_kib')}),flush=True)
sys.exit(0 if record['status']=='passed' else 1)
