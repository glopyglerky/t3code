#!/usr/bin/env python3
"""Verify retained borrowing experiment evidence; never create a qualification receipt."""
import hashlib
import importlib.util
import json
import math
from pathlib import Path, PurePosixPath
import re
import subprocess
import sys
import zipfile

repo, evidence, output = map(Path, sys.argv[1:])
commit = "311ba836d74308b3ab89493c0b745e5296c0d5e6"
tree = "f36c074e3306ca2906137aa51e6f4e17d341982a"
parent = "02296614b7d5989475fed25e86ebb5116766645f"
upstream = "5fe2f7e4567d9e530ded0dabc9d706db27d77b84"
run_id = "43621254851"

def require(condition, message):
    if not condition:
        raise ValueError(message)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def git_bytes(path):
    return subprocess.check_output(["git", "show", f"{commit}:{path}"], cwd=repo)

def close(actual, expected, label):
    require(math.isclose(actual, expected, rel_tol=1e-12), label)

def safe_zip(name, digest, size):
    path = evidence / name
    raw = path.read_bytes()
    require(len(raw) == size and sha(raw) == digest, f"artifact identity: {name}")
    z = zipfile.ZipFile(path)
    names = z.namelist()
    require(len(names) == len(set(names)), f"duplicate ZIP entry: {name}")
    for entry in z.infolist():
        parts = PurePosixPath(entry.filename)
        require(not parts.is_absolute() and ".." not in parts.parts and "\\" not in entry.filename
                and not entry.is_dir() and ((entry.external_attr >> 16) & 0o170000) != 0o120000,
                f"unsafe ZIP entry: {entry.filename}")
    return z, {"path": name, "bytes": len(raw), "sha256": digest,
               "entries": len(names), "uncompressed_bytes": sum(e.file_size for e in z.infolist())}

validator_path = repo / "tools/ci_performance.py"
require(validator_path.read_bytes() == git_bytes("tools/ci_performance.py"), "validator changed")
require((repo / "tools/performance-contract.json").read_bytes()
        == git_bytes("tools/performance-contract.json"), "contract changed")
spec = importlib.util.spec_from_file_location("retained_validator", validator_path)
validator = importlib.util.module_from_spec(spec)
spec.loader.exec_module(validator)
contract = validator.CONTRACT

performance, performance_artifact = safe_zip("311ba836-performance.zip",
    "bbd1463211a2a8891e2a3491d5d4cb11c328993fe0ebc7b2a4a0352f80b07107", 218970)
raw_report = performance.read("performance.json")
report = json.loads(raw_report)
expected = {"source_commit": commit, "source_tree": tree, "upstream_commit": upstream,
    "upstream_tree": "5d1b0d638e32a15f4ea85924c1e751b7da12a92a", "ci_run_id": run_id,
    "ci_run_attempt": "1", "native_build_run_attempt": "1", "status": "regressed",
    "qualifies": False, "mode": "qualify", "compiler_provenance": "verified-ci-manifest",
    "compiler_route": "bluefe-rustc-via-lustr", "build_profile": "release",
    "source_tree_dirty": False, "source_tree_dirty_after": False}
for field, value in expected.items():
    require(report.get(field) == value, f"report {field}")
require(report["compiler_identity"] is None, "invented observed compiler identity")
for field in ("pairs", "warmups", "samples", "seed", "bootstrap_resamples", "confidence", "comparison_ratio", "fixture"):
    require(report["configuration"][field] == contract[field], f"fixed configuration {field}")
require(report["configuration"]["phase"] == "all", "not a complete measurement")
require(report["correctness"]["status"] == "passed", "correctness failed")
validator.validate_baseline(report)
orders = validator.expected_orders(contract["pairs"], contract["seed"])
measurements = validator.validate_runs(report, orders)
for run in report["runs"]:
    name = (f"validation-{run['backend']}.json" if run["purpose"] == "validation" else
            f"pair-{run['pair']:02d}-{run['backend']}.json")
    require(json.loads(performance.read(name)) == run, f"raw worker mismatch: {name}")
for path, digest in report["sources"].items():
    require(sha(git_bytes(path)) == digest, f"measured source hash: {path}")

require([(r["id"], r["phase"], r["metric"]) for r in report["scenarios"]]
        == [(r["id"], r["phase"], r["metric"]) for r in contract["scenarios"]], "scenario set")
rows = []
tails = {}
for index, row in enumerate(report["scenarios"]):
    operation = row["id"].removesuffix(".p95")
    probability = .95 if row["metric"] == "p95" else .5
    def values(pair, backend):
        result = measurements[(pair, backend)]
        return [result["cold_open_ms"]] if row["phase"] == "cold" else result["samples"][operation]
    require([p["pair"] for p in row["pairs"]] == list(range(contract["pairs"])), "pair IDs")
    require([p["order"] for p in row["pairs"]] == orders, "pair order")
    ratios = []
    for pair in row["pairs"]:
        for backend in ("upstream", "native"):
            close(pair[f"{backend}_ms"], validator.quantile(values(pair["pair"], backend), probability), "pair raw binding")
        ratio = pair["native_ms"] / pair["upstream_ms"]
        close(pair["ratio"], ratio, "pair ratio")
        ratios.append(ratio)
    ratio, interval = validator.paired_comparison(ratios, contract["seed"] + index)
    close(row["ratio"], ratio, "paired geometric ratio")
    for actual, expected_value in zip(row["confidence_interval"], interval):
        close(actual, expected_value, "10,000-resample interval")
    require(row["status"] == "regressed" and interval[0] > 1, "regression verdict")
    for backend in ("upstream", "native"):
        pooled = [v for pair in range(contract["pairs"]) for v in values(pair, backend)]
        require(row[backend]["samples"] == len(pooled), "sample count")
        for key, value in (("median_ms", validator.quantile(pooled, .5)),
                           ("p95_ms", validator.quantile(pooled, .95)), ("max_ms", max(pooled)),
                           ("sequential_requests_per_second", 1000 * len(pooled) / sum(pooled))):
            close(row[backend][key], value, f"pooled {key}")
        if row["metric"] != "p95":
            tails.setdefault(row["id"], {})[backend] = {
                "samples": len(pooled), "median_ms": validator.quantile(pooled, .5),
                "p95_ms": validator.quantile(pooled, .95), "max_ms": max(pooled),
                "over_ms": {str(threshold): sum(v > threshold for v in pooled) for threshold in (5, 10, 50, 100)}}
    rows.append({k: row[k] for k in ("id", "phase", "metric", "status", "ratio", "confidence_interval", "precision_warning", "upstream", "native")})

application, application_artifact = safe_zip("311ba836-application-proof.zip",
    "6386adfc3d2b9d5b3fd9100b3e4bc661aeae441ded1465b2ed8c54df20167cd3", 660612)
hook = json.loads(application.read("commit-hook-proof/proof.json"))
require((hook["status"], hook["source_commit"], hook["source_tree"], hook["first_parent"],
         hook["ci_run_id"], hook["ci_run_attempt"]) == ("passed", commit, tree, parent, run_id, "1"), "hook identity")
require(hook["command"] == ["git", "hook", "run", "pre-commit"]
        and hook["hook_result"] == {"exit_code": 0, "timed_out": False}
        and hook["source_clean_before"] and hook["observed_head"] == parent
        and hook["observed_index_tree"] == tree and hook["unstaged_changes"] == []
        and hook["new_source_files"] == []
        and hook["restoration"] == {"head": commit, "index_tree": tree, "detached": True, "clean": True}, "normal hook/source restoration")
for channel in ("stdout", "stderr"):
    value = application.read(f"commit-hook-proof/proof.{channel}.log")
    require(len(value) == hook[channel]["bytes"] and sha(value) == hook[channel]["sha256"], "hook log binding")
hook_stderr = application.read("commit-hook-proof/proof.stderr.log").decode()
require("vp fmt" in hook_stderr and "vp lint" in hook_stderr and "knip" not in hook_stderr.lower(), "actual conditional hook scope")
app = json.loads(application.read("hybrid-proof/application.json"))
require(app["status"] == "passed" and app["source_commit"] == commit
        and app["source_tree_dirty"] is False and app["upstream_commit"] == upstream
        and len(app["checks"]) == 3 and all(c["status"] == "passed" and c["exit_code"] == 0 for c in app["checks"]), "application builds")
summary = json.loads(application.read("hybrid-proof/client/summary.json"))
browser = json.loads(application.read("hybrid-proof/client/native/proof.json"))
require(summary["status"] == browser["status"] == "passed" and summary["passed"] == ["native"]
        and browser["error"] is None and len(browser["completedSteps"]) == 7, "browser flow")
for item in (summary, browser):
    require(item["source"]["commit"] == commit and item["source"]["dirty"] is False
            and item["source"]["upstream"]["upstream"]["commit"] == upstream, "browser source")
    manifest = item["source"]["nativeManifest"]
    for field in ("source_commit", "source_tree", "source_tree_dirty", "compiler_route", "build_profile", "toolchain_lock_sha256", "ci_run_id", "ci_run_attempt"):
        require(manifest[field] == report[field], f"manifest cross-binding {field}")
    require(manifest["files"]["t3-code-ls-db"] == report["executable_sha256"], "manifest helper cross-binding")
require(app["native_manifest_sha256"] == report["native_manifest_sha256"], "manifest digest cross-binding")
snapshots = browser["completedSnapshots"]
require([s["checkpoint"] for s in snapshots] == ["initial", "client-reload", "server-restart"], "snapshot checkpoints")
for snapshot in snapshots:
    require(all(snapshot[k] == value for k, value in browser["turnIdentity"].items()), "turn identity")
    require(snapshot["threadId"] == browser["threadId"] and all(snapshot[k] == "completed"
            for k in ("runStatus", "attemptStatus", "providerTurnStatus")), "completed statuses")
require(all(p["engine"] == "omdb" and p["inspector"] == "read-only-local" for p in browser["persistence"])
        and any(p["checkpoint"] == "closed-before-restart" and p["closedDatabaseUnchanged"] is True for p in browser["persistence"]), "read-only native reopen")

component, component_artifact = safe_zip("311ba836-component-proof.zip",
    "068ec5d653ee95835d888b5faf91bb1165f6cf34524a56ab03c9cd5040f3e543", 58995)
acceptance = json.loads(component.read("acceptance.json"))
require(acceptance["status"] == "passed" and acceptance["source_commit"] == commit
        and len(acceptance["typechecks"]) == 29 and len(acceptance["checks"]) == 49
        and all(c["status"] == "passed" and c["exit_code"] == 0 for c in acceptance["typechecks"] + acceptance["checks"]), "mapped components")
native_log = (evidence / "311ba836-native-job.log").read_bytes()
require(sha(native_log) == "def4f69cd49ea72abef10664134bba29ccea858cb9830e19e0988b05431f2a51", "native log identity")
groups = [tuple(map(int, m)) for m in re.findall(rb"test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;", native_log)]
require(len(groups) == 37 and sum(g[0] for g in groups) == 425 and all(g[1:] == (0, 0) for g in groups), "Rust totals")
node_tests = re.findall(rb"test (application_projections::records::window::node_root_reuse_tests::[^\r\n]+) \.\.\. ok", native_log)
require(len(node_tests) == 6, "node-root regressions")
jobs = json.loads((evidence / "311ba836-jobs.json").read_bytes())
expected_jobs = {132527235534: "success", 132527471208: "success", 132532570006: "failure",
                 132532570012: "success", 132532570028: "success", 132533425691: "failure"}
require({j["id"]: j["conclusion"] for j in jobs["jobs"]} == expected_jobs
        and all(j["status"] == "completed" for j in jobs["jobs"]), "completed workflow outcomes")
qualification_log = (evidence / "311ba836-qualification-job.log").read_bytes()
require(b"Qualification receipt rejected: Job performance did not succeed or skip ('failure')" in qualification_log, "qualification failure reason")

memory, cold_components = {}, {}
for backend in ("upstream", "native"):
    runs = [r for r in report["runs"] if r["purpose"] == "measurement" and r["backend"] == backend]
    require(all(r["process_tree_rss_status"] == "sampled" for r in runs), "RSS observation status")
    memory[backend] = {"process_tree_peak_rss_kib_min": min(r["process_tree_peak_rss_kib"] for r in runs),
                       "process_tree_peak_rss_kib_max": max(r["process_tree_peak_rss_kib"] for r in runs),
                       "node_peak_rss_kib_min": min(r["node_peak_rss_kib"] for r in runs),
                       "node_peak_rss_kib_max": max(r["node_peak_rss_kib"] for r in runs),
                       "gc_duration_ms_total": sum(r["gc"]["duration_ms"] for r in runs)}
    cold_components[backend] = {"service_open_ms": validator.quantile([r["result"]["service_open_ms"] for r in runs], .5)}
    cold_components[backend].update({name: validator.quantile([r["result"]["cold_first_operations_ms"][name] for r in runs], .5)
                                    for name in report["correctness"]["result_digests"]})

result = {"schema_version": 1, "verification_status": "passed", "qualifies": False,
    "meaning": "Artifact integrity, raw-data/statistical reconstruction and scoped functional evidence; all eleven latency rows regressed and qualification failed.",
    "source_commit": commit, "source_tree": tree, "upstream_commit": upstream, "run_id": run_id,
    "attempt": "1", "performance_artifact": performance_artifact,
    "report_sha256": sha(raw_report), "application_artifact": application_artifact,
    "component_artifact": component_artifact, "verifier_sha256": sha(Path(__file__).read_bytes()),
    "validator_sha256": sha(validator_path.read_bytes()), "contract_sha256": sha(git_bytes("tools/performance-contract.json")),
    "rows": rows, "tails": tails, "memory_advisory": memory, "cold_component_medians_ms": cold_components,
    "cardinality": report["runs"][0]["result"]["cardinality"], "worker_runs": len(report["runs"]),
    "external_dependency_descriptors": len(report["baseline"]["external_dependencies"]),
    "rust": {"passed": 425, "failed": 0, "ignored": 0, "result_groups": 37, "storage_library_passed": 208,
             "inherited_node_regressions": [n.decode() for n in node_tests]}, "typechecks": 29, "mapped_scripts": 49,
    "hook": {"elapsed_seconds": hook["elapsed_seconds"], "status": hook["status"], "stderr": hook_stderr,
             "knip_reran": False, "scope": "Actual normal conditional hook for Rust/docs-only diff; fmt/lint reported; exact clean tree restored.",
             "proof_sha256": sha(application.read("commit-hook-proof/proof.json"))},
    "application": {"builds_and_selection": app["status"], "browser": browser["status"],
        "steps": browser["completedSteps"], "completed_snapshots": len(snapshots),
        "scope": browser["scope"], "retained_browser_errors": browser["browserErrors"],
        "proof_sha256": sha(application.read("hybrid-proof/client/native/proof.json")),
        "application_json_sha256": sha(application.read("hybrid-proof/application.json")),
        "summary_sha256": sha(application.read("hybrid-proof/client/summary.json"))},
    "jobs": [{k:j[k] for k in ("id", "name", "status", "conclusion")} for j in jobs["jobs"]],
    "qualification_log_sha256": sha(qualification_log),
    "source_hashes_verified": report["sources"]}
output.write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({"verification": str(output), "sha256": sha(output.read_bytes()), "rows": len(rows),
                  "all_regressed": True, "rust_passed": 425, "worker_runs": 18, "qualifies": False}))
