# Node-root experiment evidence

This archive retains scoped functional results and an independent reconstruction
of the rejected performance report for source 02296614. It is not a qualification
receipt. Main was not advanced.

The original performance artifact is retained separately as
docs/performance/measurements/2026-11-14-history-node-reuse.raw.zip, SHA256
5da9de275d87a2c0e19a70df53710b2a7df86b46e2b7f71dd85e834f6813447e.
Place a copy named 02296614-performance.zip beside the files from this archive.
With a checkout whose tools/ci_performance.py and performance-contract.json match
02296614 and whose Git objects contain that revision, recompute using:

    python3 verify.py /path/to/checkout /path/to/evidence /path/to/new-verification.json

The verifier checks all 18 raw workers, exact fixed configuration, source and
runtime evidence, pooled statistics, paired bootstrap intervals, scoped normal
hook/restoration, application flow, Rust/component totals and final failed gate.
The retained validator inputs are included under validator/ for inspection.
Every original ZIP and job log remains byte-for-byte unchanged. The actual
normal hook reported fmt/lint for this Rust/docs-only diff; it did not rerun
Knip. All eleven latency rows regressed, and qualification failed.
