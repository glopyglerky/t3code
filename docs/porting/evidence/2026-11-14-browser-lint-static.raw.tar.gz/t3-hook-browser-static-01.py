import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

ROOT = Path('/workspace/scratch/fcf5fdf8376a')
REPO = ROOT / 't3-browser-diagnostic-lint'
OUT = ROOT / 't3-hook-browser-static-01'
RUNTIME = ROOT / 't3-hook-browser-static-runtime-01.json'
OUT.mkdir(exist_ok=False)
runtime = json.loads(RUNTIME.read_text())
affinity = min(os.sched_getaffinity(0)); os.sched_setaffinity(0, {affinity})
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
def git(*args):
    return subprocess.check_output(['git','-C',str(REPO),*args]).decode().splitlines()
paths = sorted(set(git('diff','--name-only','HEAD')) | set(git('ls-files','--others','--exclude-standard')))
paths += ['apps/web/scripts/hybrid-client-browser-diagnostics.ts']
def sources(): return {name:sha(REPO/name) for name in paths}
def tools():
    result = {}
    for name in ['node','cli']:
        item=runtime[name]; assert sha(Path(item['path']))==item['sha256']; result[name]=item
    for item in runtime['links']:
        path=Path(item['path']); assert path.resolve()==Path(item['target']); assert sha(path/'package.json')==item['package_json_sha256'];
        assert os.readlink(item['source_link'])==item['source_link_value']
    return result
before=sources(); tool_before=tools()
format_paths=[name for name in paths if name.endswith(('.ts','.md','.yml'))]
format_paths=sorted(set(format_paths))
node=runtime['node']['path']; cli=runtime['cli']['path']
steps=[('format-check',[node,cli,'fmt','--check',*format_paths]),
       ('lint',[node,cli,'lint','--no-error-on-unmatched-pattern','apps/web/scripts/hybrid-client-browser-diagnostics.ts','apps/web/scripts/hybrid-client-browser-diagnostics.test.ts','apps/web/scripts/verify-hybrid-client.ts']),
       ('pure-browser-tests',[node,'--test','apps/web/scripts/hybrid-client-browser-diagnostics.test.ts'])]
env=dict(os.environ,PATH=str(ROOT/'t3-runtime/node_modules/.bin')+os.pathsep+os.environ['PATH'])
results=[]
for name,command in steps:
    start=time.monotonic();failure=None;out=OUT/(name+'.stdout.log');err=OUT/(name+'.stderr.log')
    with out.open('xb') as stdout,err.open('xb') as stderr:
        child=subprocess.Popen(command,cwd=REPO,env=env,stdout=stdout,stderr=stderr,start_new_session=True)
        try:
            while child.poll() is None:
                if time.monotonic()-start>120:failure='owned timeout';break
                if out.stat().st_size+err.stat().st_size>16*1024*1024:failure='owned output bound';break
                time.sleep(.1)
        finally:
            if failure or child.poll() is None:
                try:os.killpg(child.pid,signal.SIGTERM)
                except ProcessLookupError:pass
                try:child.wait(timeout=3)
                except subprocess.TimeoutExpired:pass
            try:os.killpg(child.pid,signal.SIGKILL)
            except ProcessLookupError:pass
            child.wait(timeout=5)
    result=dict(name=name,command=command,exit_code=child.returncode,elapsed_seconds=round(time.monotonic()-start,3),failure=failure,
                stdout=dict(path=str(out),bytes=out.stat().st_size,sha256=sha(out)),stderr=dict(path=str(err),bytes=err.stat().st_size,sha256=sha(err)))
    results.append(result)
    if child.returncode or failure:break
after=sources();tool_after=tools()
record=dict(schema_version=1,scope='Formatter check, targeted lint and built-in browser diagnostic logic only; not normal hook, app typecheck or browser execution',
            affinity=[affinity],timeout_seconds_per_step=120,output_limit_bytes_per_step=16*1024*1024,
            runtime_receipt_sha256=sha(RUNTIME),source_before=before,source_after=after,source_unchanged=before==after,
            tool_before=tool_before,tool_after=tool_after,tools_unchanged=tool_before==tool_after,steps=results,
            planned_steps=[x[0] for x in steps])
record['status']='passed' if len(results)==3 and all(x['exit_code']==0 and not x['failure'] for x in results) and before==after and tool_before==tool_after else 'failed'
(OUT/'receipt.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(dict(status=record['status'],source_unchanged=record['source_unchanged'],steps=[{k:x[k] for k in ('name','exit_code','elapsed_seconds','failure')} for x in results])),flush=True)
sys.exit(0 if record['status']=='passed' else 1)
