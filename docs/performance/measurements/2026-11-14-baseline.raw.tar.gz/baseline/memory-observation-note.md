# Memory observation correction

The original baseline files are unchanged. This note applies to attempt `2026-11-14T12-26-19.207Z-b8758a36`.

`process_tree_peak_rss_kib: 0` in the raw baseline is **unavailable data**, not measured zero memory. This sandbox exposes `/proc/PID/status` but does not expose `/proc/PID/task/PID/children`. The first sampler converted that enumeration failure to zero. The whole-process memory comparison is therefore invalid and no memory advantage or equivalence may be claimed.

The separately labeled `node_peak_rss_kib` values describe only each Node worker; they exclude the native helper and are not a whole-application memory comparison. No memory field gates the latency verdict.

After the complete eight-pair run finished, the sampler was changed to report null, an explicit unavailable status, and a reason whenever the whole descendant tree cannot be observed. Three focused regressions verify complete-tree summation and the unavailable cases. This correction changes advisory memory reporting only. Workloads, pair order, warmups, sample counts, latency measurements, confidence procedure, and the strict 1.0 comparison remain unchanged.
