# Persistence performance comparison

Status: **failed**. Mode: diagnostic. Attempt: 2026-11-14T12-18-24.402Z-c9804d0f.

Fork commit: `2e66b12788529b774b45b15e3e106419677dc690`. Tree: `4eafcb0bb002599dc7c99ea9a21989b3941be94b`. Dirty: true.
Pinned upstream: `913d7fc45ec5814fff25c819cfe4de193ea42d63`. Tree: `95faedbd2644d046dac476ef9dcab2eb38a7eb97`.
Compiler route: bluefe-rustc-via-lustr. Build profile: unverified-diagnostic.
Compiler revision: `1b74388e196ee8813f38ba9eeb6d4ab43b6b1071`. Coordinator: `07470b20464bf097c3c88983124aff56c5e44f9a`.
Executable SHA-256: `aac6fb65a255954d6ab0d5836bc8a5eb8a53c4911974ce7c6f32fc1833221c4b`. Toolchain lock: `2cddf6970e38ab122d6d62e4543cfb3d1fd23876d4a813a4b4421babc033d1bf`.
Manifest SHA-256: `not supplied`. Policy: `not supplied`.

## Results

| Scenario | Phase | Upstream median / p95 / worst ms | Native median / p95 / worst ms | Paired native/upstream ratio | Latency change | 95% interval | Decision |
|---|---|---:|---:|---:|---:|---|---|

No performance verdict is available until all correctness and source checks pass.

Negative latency change means faster; positive means slower for the named workload and statistic only.

## Reasons and divergences

- Failure: YAMLParseError: Source contains multiple documents; please use YAML.parseAllDocuments() at line 158, column 1:


---
^

    at parseDocument (/workspace/scratch/fcf5fdf8376a/t3code-ls/node_modules/.pnpm/yaml@2.9.0/node_modules/yaml/dist/public-api.js:50:29)
    at Module.parse (/workspace/scratch/fcf5fdf8376a/t3code-ls/node_modules/.pnpm/yaml@2.9.0/node_modules/yaml/dist/public-api.js:68:17)
    at createPinnedBaseline (file:///workspace/scratch/fcf5fdf8376a/t3code-ls/tools/performance-baseline.mjs:87:30)
    at async file:///workspace/scratch/fcf5fdf8376a/t3code-ls/tools/performance-persistence.mjs:611:21

Correctness: failed.


## Protocol and decisions

- The workloads are fixed before measurements: sidebar-shell, history-window, message-search, accent-search, and visit-commit transaction/readback.
- Every scenario gates independently; a faster scenario cannot offset a slower one.
- Eight balanced, seeded process pairs and all requests are retained. No slow sample is dropped or retried.
- Confidence intervals compare native/upstream latency against exactly 1.0. A 10% interval width is only a noise diagnostic, never a regression allowance.
- Migration, fixture seeding and native index preparation occur before timed workers; process-cold service acquisition and warm API calls are reported separately.
- The write comparison uses actual production settings: stock SQLite WAL/NORMAL and native Immediate. Native commits retain stronger power-loss durability; any associated slowdown remains visible and gates qualification.
- Rollback and committed reopen are required correctness checks; they do not prove power-failure durability.

## Measurement limits

- This measures the production persistence/API boundary, including native IPC and serialization, not complete UI, network, provider or whole-application performance.
- Cold means a fresh Node process and service open. The shared OS page cache is not flushed or claimed cold; backend order is balanced.
- Warm request timings exclude result fingerprinting; native IPC/serialization and upstream worker messaging remain inside the timed operation.
- RSS is a 25 ms sample of the Node process plus its native descendants. It includes shared pages more than once and can miss short peaks; it is advisory and never a heap or memory-safety claim.
- V8 GC is observed without forced collections. Node peak RSS excludes child helpers and is separately labeled; the process-tree sample includes them.
- Shared CI load, filesystem caching, CPU frequency and small-sample tail uncertainty remain. Inconclusive evidence cannot establish equivalence or qualify this commit.

## Reproduction

```json
{
  "command": [
    "/workspace/scratch/fcf5fdf8376a/t3-runtime/node_modules/node/bin/node",
    "/workspace/scratch/fcf5fdf8376a/t3code-ls/tools/performance-persistence.mjs",
    "--database",
    "/workspace/scratch/fcf5fdf8376a/t3-target/release/t3-code-ls-db",
    "--output",
    "/workspace/scratch/fcf5fdf8376a/t3-performance-validation-03",
    "--mode",
    "diagnostic",
    "--phase",
    "validation"
  ],
  "configuration": {
    "pairs": 8,
    "warmups": 3,
    "samples": 12,
    "seed": 1949524847,
    "bootstrap_resamples": 10000,
    "confidence": 0.95,
    "comparison_ratio": 1,
    "fixture": {
      "threads": 256,
      "write_threads": 1,
      "messages": 3000,
      "history_items": 1500,
      "payload_bytes": 1024
    },
    "phase": "validation",
    "worker_timeout_ms": 900000,
    "worker_output_limit_bytes": 16777216,
    "worker_shutdown_grace_ms": 2000,
    "rss_sampling_interval_ms": 25
  },
  "host": {
    "platform": "linux",
    "architecture": "x64",
    "release": "6.18.57",
    "cpu_model": "INTEL(R) XEON(R) PLATINUM 8573C",
    "cpus": 9,
    "total_memory_bytes": 10451423232,
    "load_before": [
      0.74,
      1.15,
      1.01
    ],
    "node": "v26.12.1"
  },
  "durability": {
    "upstream": {
      "journal_mode": "wal",
      "synchronous": "NORMAL",
      "synchronous_numeric": 1,
      "reader_worker": true,
      "writer_worker": true
    },
    "native": {
      "engine": "omdb",
      "durability": "Immediate"
    },
    "comparison": "Actual selected production defaults; stronger native commit durability is preserved and any cost is included in visit-commit."
  },
  "sources": {
    "tools/performance-persistence.mjs": "1bb7e8a2335e5dc29ec801f83513106669cd82c07116b0ea74985b023681d6ad",
    "tools/performance-worker.mjs": "79b1a30c2c59345364907cda1410bed9c1322858d1d18ec6f28567d4a2cbea56",
    "tools/performance-statistics.mjs": "47ed48c3d848ac3681b4e425912e26205e4eeb96beaa14ae0cc84806b8bd8bbb",
    "tools/performance-contract.json": "c5c48c1ede643bb80c10f786bb82898a3dec71eb89a652d81135b2ed3dbdcb36",
    "tools/performance-baseline.mjs": "1f00bb4039565cfe3235e5cf3d12087fdaaf77d4cf13f641a8b62fcc79fe3066",
    "apps/server/src/persistence/Omdb.ts": "d419cee6b7141d349c9e62501734cac29fa002a16e746a40f02a6af114f51bc1",
    "apps/server/src/orchestration-v2/NativeProjectionStore.ts": "eb22ff076bbd889ce9eaa72ecb3d7bcca313496bb31058fab4bf92ff958c6fa7",
    "apps/server/src/orchestration-v2/NativeThreadSearch.ts": "ebdea6dfe28aebfbd02eeee8afbabce8be64ccdb277de2f646d2d181429deddd",
    "apps/server/src/persistence/omdb-schema.json": "395b45dba23c8c59851ff0af055023d7536b0e76059fc613f1b96b6e5244a502",
    "crates/storage/src/backend.rs": "8940da0a19967c12aec65fbd555d4938648e395027e7efcbbd6c3dfc48e190e5"
  }
}
```

Raw process order, every request duration, GC observations and sampled process-tree RSS are in performance.json and the worker JSON files. No result row is omitted.
