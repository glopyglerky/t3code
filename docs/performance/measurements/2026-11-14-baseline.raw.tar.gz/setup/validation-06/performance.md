# Persistence performance comparison

Status: **failed**. Mode: diagnostic. Attempt: 2026-11-14T12-24-20.289Z-8555f9b1.

Fork commit: `2e66b12788529b774b45b15e3e106419677dc690`. Tree: `4eafcb0bb002599dc7c99ea9a21989b3941be94b`. Dirty: true.
Pinned upstream: `913d7fc45ec5814fff25c819cfe4de193ea42d63`. Tree: `95faedbd2644d046dac476ef9dcab2eb38a7eb97`.
Compiler route: bluefe-rustc-via-lustr. Build profile: unverified-diagnostic.
Compiler revision: `1b74388e196ee8813f38ba9eeb6d4ab43b6b1071`. Coordinator: `07470b20464bf097c3c88983124aff56c5e44f9a`.
Executable SHA-256: `aac6fb65a255954d6ab0d5836bc8a5eb8a53c4911974ce7c6f32fc1833221c4b`. Toolchain lock: `2cddf6970e38ab122d6d62e4543cfb3d1fd23876d4a813a4b4421babc033d1bf`.
Manifest SHA-256: `not supplied`. Policy: `not supplied`.

## Results

| Scenario | Phase | Upstream median / p95 / worst ms | Native median / p95 / worst ms | Paired native/upstream ratio | Latency change | 95% interval | Decision |
|---|---|---:|---:|---:|---:|---|---|

No performance verdict is available until all correctness and source checks pass.

Negative latency change means faster; positive means slower for the named workload and statistic only.

## Reasons and divergences

- Failure: {
  _tag: 'OmdbStartupError',
  path: '/tmp/t3-redb-gate-nnADKo/state.redb',
  cause: {
    _tag: 'OmdbStartupError',
    path: '/tmp/t3-redb-gate-nnADKo/state.redb',
    cause: Error: SQLite no longer matches the unactivated native candidate; both stores were retained without activation. Pending historical migrations can also generate new timestamps and require explicit recovery
        at file:///workspace/scratch/fcf5fdf8376a/t3code-ls/apps/server/src/persistence/Omdb.ts:189:22
        at Generator.next (<anonymous>)
        at ~effect/Effect/successCont (file:///workspace/scratch/fcf5fdf8376a/t3code-ls/node_modules/.pnpm/effect@4.1.3/node_modules/effect/dist/internal/effect.js:1039:28)
        at ~effect/Effect/evaluate (file:///workspace/scratch/fcf5fdf8376a/t3code-ls/node_modules/.pnpm/effect@4.1.3/node_modules/effect/dist/internal/core.js:343:30)
        at FiberImpl.runLoop (file:///workspace/scratch/fcf5fdf8376a/t3code-ls/node_modules/.pnpm/effect@4.1.3/node_modules/effect/dist/internal/effect.js:493:99)
        at FiberImpl.evaluate (file:///workspace/scratch/fcf5fdf8376a/t3code-ls/node_modules/.pnpm/effect@4.1.3/node_modules/effect/dist/internal/effect.js:426:23)
        at AsyncResource.runInAsyncScope (node:async_hooks:226:14)
        at FiberImpl.evaluate (file:///workspace/scratch/fcf5fdf8376a/t3code-ls/node_modules/.pnpm/effect@4.1.3/node_modules/effect/dist/internal/effect.js:415:29)
        at file:///workspace/scratch/fcf5fdf8376a/t3code-ls/node_modules/.pnpm/effect@4.1.3/node_modules/effect/dist/internal/effect.js:858:17
        at file:///workspace/scratch/fcf5fdf8376a/t3code-ls/node_modules/.pnpm/effect@4.1.3/node_modules/effect/dist/Effect.js:8571:9
  }
}

Correctness: failed.


## Protocol and decisions

- The workloads are fixed before measurements: sidebar-shell, history-window, message-search, accent-search, and visit-commit transaction/readback.
- Every scenario gates independently; a faster scenario cannot offset a slower one.
- Eight balanced, seeded process pairs and all requests are retained. No slow sample is dropped or retried.
- Confidence intervals compare native/upstream latency against exactly 1.0. A 10% interval width is only a noise diagnostic, never a regression allowance.
- Migration, fixture seeding and native index preparation occur before timed workers; process-cold service acquisition and warm API calls are reported separately.
- The write comparison uses actual production settings: stock SQLite WAL/NORMAL and native Immediate. Native commits retain stronger power-loss durability; any associated slowdown remains visible and gates qualification.
- Rollback and committed reopen are required correctness checks; they do not prove power-failure durability.

## Measurement limits

- This measures the production persistence/API boundary, including native IPC and serialization, not complete UI, network, provider or whole-application performance.
- Cold means a fresh Node process and service open. The shared OS page cache is not flushed or claimed cold; backend order is balanced.
- Warm request timings exclude result fingerprinting; native IPC/serialization and upstream worker messaging remain inside the timed operation.
- RSS is a 25 ms sample of the Node process plus its native descendants. It includes shared pages more than once and can miss short peaks; it is advisory and never a heap or memory-safety claim.
- V8 GC is observed without forced collections. Node peak RSS excludes child helpers and is separately labeled; the process-tree sample includes them.
- Shared CI load, filesystem caching, CPU frequency and small-sample tail uncertainty remain. Inconclusive evidence cannot establish equivalence or qualify this commit.

## Reproduction

```json
{
  "command": [
    "/workspace/scratch/fcf5fdf8376a/t3-runtime/node_modules/node/bin/node",
    "/workspace/scratch/fcf5fdf8376a/t3code-ls/tools/performance-persistence.mjs",
    "--database",
    "/workspace/scratch/fcf5fdf8376a/t3-target/release/t3-code-ls-db",
    "--output",
    "/workspace/scratch/fcf5fdf8376a/t3-performance-validation-06",
    "--mode",
    "diagnostic",
    "--phase",
    "validation"
  ],
  "configuration": {
    "pairs": 8,
    "warmups": 3,
    "samples": 12,
    "seed": 1949524847,
    "bootstrap_resamples": 10000,
    "confidence": 0.95,
    "comparison_ratio": 1,
    "fixture": {
      "threads": 256,
      "write_threads": 1,
      "messages": 3000,
      "history_items": 1500,
      "payload_bytes": 1024
    },
    "phase": "validation",
    "worker_timeout_ms": 900000,
    "worker_output_limit_bytes": 16777216,
    "worker_shutdown_grace_ms": 2000,
    "rss_sampling_interval_ms": 25
  },
  "host": {
    "platform": "linux",
    "architecture": "x64",
    "release": "6.18.57",
    "cpu_model": "INTEL(R) XEON(R) PLATINUM 8573C",
    "cpus": 9,
    "total_memory_bytes": 10451423232,
    "load_before": [
      0.68,
      0.61,
      0.78
    ],
    "node": "v26.12.1"
  },
  "baseline": {
    "root": "/tmp/t3-redb-gate-nnADKo/upstream",
    "commit": "913d7fc45ec5814fff25c819cfe4de193ea42d63",
    "tree": "95faedbd2644d046dac476ef9dcab2eb38a7eb97",
    "archive_sha256": "dd61ceca8c7aaf1f8d8dd5319a3f45a61835ec5a43391a40919ed71d3684f562",
    "dependency_lock_sha256": "89d1c22024aebd302d81c597dc268ec22309f28214cb70071f88b742ceff4660",
    "fork_dependency_lock_sha256": "a17f5c2cdb04c1a8240a9ad5ca275d4318c262ef596e20a8f67c5d25e3d2a6c4",
    "dependency_comparison": "All settings, patches, package/snapshot resolutions and shared importers match. Only the exact existing tools/oracles importer with workspace links and Effect 4.1.3 is additional.",
    "workspace_packages": [
      "@t3tools/client-runtime",
      "@t3tools/contracts",
      "@t3tools/desktop",
      "@t3tools/marketing",
      "@t3tools/mobile",
      "@t3tools/provider-acp",
      "@t3tools/provider-acp-registry",
      "@t3tools/provider-core",
      "@t3tools/provider-cursor",
      "@t3tools/provider-fx",
      "@t3tools/provider-grok",
      "@t3tools/provider-kiro",
      "@t3tools/provider-muse",
      "@t3tools/provider-opencode",
      "@t3tools/provider-pi",
      "@t3tools/provider-testing",
      "@t3tools/secret-provider-core",
      "@t3tools/secret-provider-definitions",
      "@t3tools/secret-provider-onepassword",
      "@t3tools/shared",
      "@t3tools/source-control-azure-devops",
      "@t3tools/source-control-bitbucket",
      "@t3tools/source-control-core",
      "@t3tools/source-control-cursor-origin",
      "@t3tools/source-control-definitions",
      "@t3tools/source-control-forgejo",
      "@t3tools/source-control-gitcafe",
      "@t3tools/source-control-github",
      "@t3tools/source-control-gitlab",
      "@t3tools/source-control-testing",
      "@t3tools/ssh",
      "@t3tools/tailscale",
      "@t3tools/web",
      "effect-acp",
      "effect-codex-app-server",
      "t3"
    ],
    "external_dependencies": [
      {
        "name": "@anthropic-ai/claude-agent-sdk",
        "version": "0.3.321",
        "package_json_sha256": "b2e2de05b39aad8a090c5b11c51ccf021e98ac7e781e696c7062001bf383f7e4"
      },
      {
        "name": "@anthropic-ai/sdk",
        "version": "0.93.0",
        "package_json_sha256": "5970d7ae800e23d677c7a10c94711c072db929664b12fde67a20bc3163c65928"
      },
      {
        "name": "@coderabbitai/config",
        "version": "1.2.0",
        "package_json_sha256": "54b274a22723034230cc034b7997da2e6b56aa34a7458a6175c2c83acb0b1758"
      },
      {
        "name": "@cursor/sdk",
        "version": "1.2.0",
        "package_json_sha256": "55a97a0dbb3adb899c4b8ec07b306d5d0e226d03ea4f42f8a1dfc30b9db98dcd"
      },
      {
        "name": "@cursor/sdk-linux-x64",
        "version": "1.2.0",
        "package_json_sha256": "6e5f33caf3e737d95c381ab926ce3e8580aeeecca483b14dfdbd8d94445b15b6"
      },
      {
        "name": "@effect/platform-node",
        "version": "4.1.2",
        "package_json_sha256": "2901f7c08e6011794c624e346b19f85a6b455338c3991578407c3028bd64800e"
      },
      {
        "name": "@effect/tsgo",
        "version": "0.67.1",
        "package_json_sha256": "59e9fc21d767c96f8cdf7aaa91d0ec886584458c14e4b6700c506dbdc27a83e4"
      },
      {
        "name": "@ff-labs/fff-node",
        "version": "0.11.0",
        "package_json_sha256": "ba3162477649ba95e1c4efcb38344c3fb43dba889fc96c406bec5889cca37ae6"
      },
      {
        "name": "@modelcontextprotocol/sdk",
        "version": "1.29.0",
        "package_json_sha256": "7ab20eba8fee70f316516b5b3fc45837294caee7e4dd36f2a1593210b0f003ac"
      },
      {
        "name": "@muse-code/sdk",
        "version": "1.4.6",
        "package_json_sha256": "44d2806ed5a24e8ee6aaacaa6259f2a7660ee5b34d53875fd97960d3e5a8b4ef"
      },
      {
        "name": "@noble/curves",
        "version": "1.9.1",
        "package_json_sha256": "d496cbba8f48a7407657170c84542e337e2fdfdc71bb7f5fd9e350daab119f31"
      },
      {
        "name": "@noble/hashes",
        "version": "1.8.0",
        "package_json_sha256": "7c4657c5e616c22cefa2691cc30670824a639dc71d97bf83925be2d239dc60e3"
      },
      {
        "name": "@opencode-ai/sdk",
        "version": "1.15.13",
        "package_json_sha256": "389f3fe4b859309ff51efbe8253c1968fecc4e9d148dfd555b4d6bcfd3e20fb5"
      },
      {
        "name": "@opencode/client",
        "version": "2.0.28",
        "package_json_sha256": "ff43ff5e26e6bc2188a5d20478e96e8715c01c5514f030ca496c716db9c9a856"
      },
      {
        "name": "@opencode/protocol",
        "version": "2.0.28",
        "package_json_sha256": "f47856974ae1913bf3bf60d4b25fed10189532551f9f5fd93c077e7bdd1533b0"
      },
      {
        "name": "@opencode/schema",
        "version": "2.0.28",
        "package_json_sha256": "2c9a769cc21321d0b12f63129b01b0645f208e37bcddd50d86dc025da5491976"
      },
      {
        "name": "@shadcn/lint",
        "version": "0.1.5",
        "package_json_sha256": "1f31e9c28a593866ae372ab2c7e41deea5b4bc5ec4b36ca6125895d279c7046c"
      },
      {
        "name": "@types/mdast",
        "version": "4.0.4",
        "package_json_sha256": "5a41865d64d4cedba58313fad775cf56bd0474d724343172bcea9f8ad24db563"
      },
      {
        "name": "@types/node",
        "version": "24.12.4",
        "package_json_sha256": "456b1366f1966515c4dfec48446c82275502a2d5ea7cfbc74874323b39e3776f"
      },
      {
        "name": "@types/proper-lockfile",
        "version": "4.1.4",
        "package_json_sha256": "892bde4e440d1536c07410155f8f7c4776d6d825c931fa34d5d04b8f0a9c02f5"
      },
      {
        "name": "@types/yauzl",
        "version": "3.4.0",
        "package_json_sha256": "3ccc141e21141f3fc2a7e562c39950cad70cb11aeb3f16e8065912c1f38bcc82"
      },
      {
        "name": "diff",
        "version": "8.0.3",
        "package_json_sha256": "35b083dc3430465fbe066129e12debeb5416474e1db71abf7a8db9997789aeed"
      },
      {
        "name": "effect",
        "version": "4.1.3",
        "package_json_sha256": "8ae4c5cf40f75346e2ab4dcacb692a98a6ddd814ecc5ffad27db087d6cfa3a9f"
      },
      {
        "name": "ffi-rs",
        "version": "1.3.2",
        "package_json_sha256": "a3f76613fbce43e44ba371ef743a72c6f3242f28a533f909140b402dd24a261f"
      },
      {
        "name": "jsonc-parser",
        "version": "3.3.1",
        "package_json_sha256": "a7a9192caaac00d9330592f4fd572908bee037518128a0fc3db96d2cd652e2b5"
      },
      {
        "name": "knip",
        "version": "6.34.0",
        "package_json_sha256": "08577f50907982196befbe1bf60a0c33718034b654e5d437ffae3cbd608f5380"
      },
      {
        "name": "mdast-util-directive",
        "version": "3.1.0",
        "package_json_sha256": "b4d5d332da2b09ba98af49baa65bbe1d953f3db4f2da3b115493e54584cc9009"
      },
      {
        "name": "mdast-util-to-hast",
        "version": "13.2.1",
        "package_json_sha256": "aa1e17fedf46914534ba0c67016734edc6d0fc919057556eb1034160f795b596"
      },
      {
        "name": "micromark-extension-directive",
        "version": "4.0.0",
        "package_json_sha256": "eeab5d27227d5f97df653e0d08c8bea945681f4b41255b49cfa125ac7cf5a5a8"
      },
      {
        "name": "micromark-util-character",
        "version": "2.1.1",
        "package_json_sha256": "bf43c5df782cf1cf985d89a8f01fd1a7b7b4bae9bf2b9c07e633c2379b1dbd7f"
      },
      {
        "name": "micromark-util-types",
        "version": "2.0.2",
        "package_json_sha256": "4bf761498edc00e674903db57fc6a8cf478677363adc776b8ac115771e791cd3"
      },
      {
        "name": "node-pty",
        "version": "1.2.0-beta.15",
        "package_json_sha256": "f4a19bbc7cf4c2e35c081e6a18a3d11d21c54c2f3cc25bfe48142742a781b71d"
      },
      {
        "name": "playwright",
        "version": "1.64.1",
        "package_json_sha256": "313d23ce667d93962d3a1ab4be80908cefe840e4d9e48f1cd5863b91f65e8e39"
      },
      {
        "name": "playwright-core",
        "version": "1.64.1",
        "package_json_sha256": "8aa1c9863fa8dea324e674254158cdc79440f4124ef2d84d38053013541cb7d6"
      },
      {
        "name": "proper-lockfile",
        "version": "4.1.2",
        "package_json_sha256": "23888ecc7abd83a8e98e132da556eda2172792cc04c4e6d157b590667802bd2a"
      },
      {
        "name": "property-information",
        "version": "7.2.0",
        "package_json_sha256": "6cacc66c65e31d11d9d4e5677c1375667faf334e585b69a9d319a0ca25676530"
      },
      {
        "name": "rehype-raw",
        "version": "7.0.0",
        "package_json_sha256": "b3313f6329e5b99fd26107f15d4a06bbd2644d1ee93f10fea5ee898be3248c05"
      },
      {
        "name": "rehype-sanitize",
        "version": "6.0.0",
        "package_json_sha256": "b8c794050d76ff903a42c31e8f7a18e85e966cf231b67d9363a81c0dd5157465"
      },
      {
        "name": "remark-breaks",
        "version": "4.0.0",
        "package_json_sha256": "df633e5c230d648c90bbfdfe5e75d28a2492af508a38b8751d9faf28af0443c6"
      },
      {
        "name": "remark-gfm",
        "version": "4.0.1",
        "package_json_sha256": "c199482a69355b610bd1ff225b097776d4a990445b11e5f4c618930dacc8c79d"
      },
      {
        "name": "remark-math",
        "version": "6.0.0",
        "package_json_sha256": "936d400d2c2a3f121c4d2b6b84b8a891af02852032b0dcb31f0407d2d6a4364f"
      },
      {
        "name": "remark-parse",
        "version": "11.0.0",
        "package_json_sha256": "47be70916ff853a6c35d8d858844c7b104d100f70999d579884859cf8d88a50c"
      },
      {
        "name": "remark-rehype",
        "version": "11.1.2",
        "package_json_sha256": "f9886f99f9f38652d56ca256aa713e359e085ed42f7d89fd66671b49f4b83b64"
      },
      {
        "name": "stream-chain",
        "version": "4.2.5",
        "package_json_sha256": "cd1b7376663c88e3dbb321be142253529b9d41f32c1e980ea92c535b934c6941"
      },
      {
        "name": "stream-json",
        "version": "3.7.0",
        "package_json_sha256": "9176f5b9015cc834212dc64b5d4e0698c6e309037b622b3bdd5b17aa5d321059"
      },
      {
        "name": "unified",
        "version": "11.0.5",
        "package_json_sha256": "f91a44220f8b7c4a4de6ebaab6fc23b92d29a95cb7e5e6a7f0f24d199779fbad"
      },
      {
        "name": "vite-plus",
        "version": "1.4.0",
        "package_json_sha256": "a2901e42e05a5f1c162b994ba85bfbad074a2f8921d129995b019e0bd48c9c09"
      },
      {
        "name": "yaml",
        "version": "2.9.0",
        "package_json_sha256": "20b8b197cbd10dad245d45e463dfe58e4c8c25a47e24bc4256ad9ab58bf35683"
      },
      {
        "name": "yauzl",
        "version": "3.4.0",
        "package_json_sha256": "d7d5418b74b185df4ad276b73cf1e36040dd417d22520354e609e2748a29fcbd"
      },
      {
        "name": "zod",
        "version": "4.6.7",
        "package_json_sha256": "c2d190d9ee4e0bdb60332aaa2130a6a98d65ddb903fe1d29248b15de57832c45"
      }
    ],
    "resolved_runtime": [
      {
        "importer": "apps/server",
        "name": "@anthropic-ai/claude-agent-sdk",
        "expected_version": "0.3.321",
        "actual_version": "0.3.321",
        "package_json_sha256": "b2e2de05b39aad8a090c5b11c51ccf021e98ac7e781e696c7062001bf383f7e4"
      },
      {
        "importer": "apps/server",
        "name": "@cursor/sdk",
        "expected_version": "1.2.0",
        "actual_version": "1.2.0",
        "package_json_sha256": "55a97a0dbb3adb899c4b8ec07b306d5d0e226d03ea4f42f8a1dfc30b9db98dcd"
      },
      {
        "importer": "apps/server",
        "name": "@effect/platform-node",
        "expected_version": "4.1.2",
        "actual_version": "4.1.2",
        "package_json_sha256": "2901f7c08e6011794c624e346b19f85a6b455338c3991578407c3028bd64800e"
      },
      {
        "importer": "apps/server",
        "name": "@ff-labs/fff-node",
        "expected_version": "0.11.0",
        "actual_version": "0.11.0",
        "package_json_sha256": "ba3162477649ba95e1c4efcb38344c3fb43dba889fc96c406bec5889cca37ae6"
      },
      {
        "importer": "apps/server",
        "name": "@muse-code/sdk",
        "expected_version": "1.4.6",
        "actual_version": "1.4.6",
        "package_json_sha256": "44d2806ed5a24e8ee6aaacaa6259f2a7660ee5b34d53875fd97960d3e5a8b4ef"
      },
      {
        "importer": "apps/server",
        "name": "diff",
        "expected_version": "8.0.3",
        "actual_version": "8.0.3",
        "package_json_sha256": "35b083dc3430465fbe066129e12debeb5416474e1db71abf7a8db9997789aeed"
      },
      {
        "importer": "apps/server",
        "name": "effect",
        "expected_version": "4.1.3",
        "actual_version": "4.1.3",
        "package_json_sha256": "8ae4c5cf40f75346e2ab4dcacb692a98a6ddd814ecc5ffad27db087d6cfa3a9f"
      },
      {
        "importer": "apps/server",
        "name": "ffi-rs",
        "expected_version": "1.3.2",
        "actual_version": "1.3.2",
        "package_json_sha256": "a3f76613fbce43e44ba371ef743a72c6f3242f28a533f909140b402dd24a261f"
      },
      {
        "importer": "apps/server",
        "name": "node-pty",
        "expected_version": "1.2.0-beta.15",
        "actual_version": "1.2.0-beta.15",
        "package_json_sha256": "f4a19bbc7cf4c2e35c081e6a18a3d11d21c54c2f3cc25bfe48142742a781b71d"
      },
      {
        "importer": "apps/server",
        "name": "playwright-core",
        "expected_version": "1.64.1",
        "actual_version": "1.64.1",
        "package_json_sha256": "8aa1c9863fa8dea324e674254158cdc79440f4124ef2d84d38053013541cb7d6"
      },
      {
        "importer": "apps/server",
        "name": "proper-lockfile",
        "expected_version": "4.1.2",
        "actual_version": "4.1.2",
        "package_json_sha256": "23888ecc7abd83a8e98e132da556eda2172792cc04c4e6d157b590667802bd2a"
      },
      {
        "importer": "apps/server",
        "name": "stream-chain",
        "expected_version": "4.2.5",
        "actual_version": "4.2.5",
        "package_json_sha256": "cd1b7376663c88e3dbb321be142253529b9d41f32c1e980ea92c535b934c6941"
      },
      {
        "importer": "apps/server",
        "name": "stream-json",
        "expected_version": "3.7.0",
        "actual_version": "3.7.0",
        "package_json_sha256": "9176f5b9015cc834212dc64b5d4e0698c6e309037b622b3bdd5b17aa5d321059"
      },
      {
        "importer": "apps/server",
        "name": "yaml",
        "expected_version": "2.9.0",
        "actual_version": "2.9.0",
        "package_json_sha256": "20b8b197cbd10dad245d45e463dfe58e4c8c25a47e24bc4256ad9ab58bf35683"
      },
      {
        "importer": "apps/server",
        "name": "yauzl",
        "expected_version": "3.4.0",
        "actual_version": "3.4.0",
        "package_json_sha256": "d7d5418b74b185df4ad276b73cf1e36040dd417d22520354e609e2748a29fcbd"
      },
      {
        "importer": "apps/server",
        "name": "zod",
        "expected_version": "4.6.7",
        "actual_version": "4.6.7",
        "package_json_sha256": "c2d190d9ee4e0bdb60332aaa2130a6a98d65ddb903fe1d29248b15de57832c45"
      },
      {
        "importer": "packages/shared",
        "name": "@noble/curves",
        "expected_version": "1.9.1",
        "actual_version": "1.9.1",
        "package_json_sha256": "d496cbba8f48a7407657170c84542e337e2fdfdc71bb7f5fd9e350daab119f31"
      },
      {
        "importer": "packages/shared",
        "name": "@noble/hashes",
        "expected_version": "1.8.0",
        "actual_version": "1.8.0",
        "package_json_sha256": "7c4657c5e616c22cefa2691cc30670824a639dc71d97bf83925be2d239dc60e3"
      },
      {
        "importer": "packages/shared",
        "name": "effect",
        "expected_version": "4.1.3",
        "actual_version": "4.1.3",
        "package_json_sha256": "8ae4c5cf40f75346e2ab4dcacb692a98a6ddd814ecc5ffad27db087d6cfa3a9f"
      },
      {
        "importer": "packages/shared",
        "name": "ffi-rs",
        "expected_version": "1.3.2",
        "actual_version": "1.3.2",
        "package_json_sha256": "a3f76613fbce43e44ba371ef743a72c6f3242f28a533f909140b402dd24a261f"
      },
      {
        "importer": "packages/shared",
        "name": "mdast-util-directive",
        "expected_version": "3.1.0",
        "actual_version": "3.1.0",
        "package_json_sha256": "b4d5d332da2b09ba98af49baa65bbe1d953f3db4f2da3b115493e54584cc9009"
      },
      {
        "importer": "packages/shared",
        "name": "mdast-util-to-hast",
        "expected_version": "13.2.1",
        "actual_version": "13.2.1",
        "package_json_sha256": "aa1e17fedf46914534ba0c67016734edc6d0fc919057556eb1034160f795b596"
      },
      {
        "importer": "packages/shared",
        "name": "micromark-extension-directive",
        "expected_version": "4.0.0",
        "actual_version": "4.0.0",
        "package_json_sha256": "eeab5d27227d5f97df653e0d08c8bea945681f4b41255b49cfa125ac7cf5a5a8"
      },
      {
        "importer": "packages/shared",
        "name": "micromark-util-character",
        "expected_version": "2.1.1",
        "actual_version": "2.1.1",
        "package_json_sha256": "bf43c5df782cf1cf985d89a8f01fd1a7b7b4bae9bf2b9c07e633c2379b1dbd7f"
      },
      {
        "importer": "packages/shared",
        "name": "property-information",
        "expected_version": "7.2.0",
        "actual_version": "7.2.0",
        "package_json_sha256": "6cacc66c65e31d11d9d4e5677c1375667faf334e585b69a9d319a0ca25676530"
      },
      {
        "importer": "packages/shared",
        "name": "rehype-raw",
        "expected_version": "7.0.0",
        "actual_version": "7.0.0",
        "package_json_sha256": "b3313f6329e5b99fd26107f15d4a06bbd2644d1ee93f10fea5ee898be3248c05"
      },
      {
        "importer": "packages/shared",
        "name": "rehype-sanitize",
        "expected_version": "6.0.0",
        "actual_version": "6.0.0",
        "package_json_sha256": "b8c794050d76ff903a42c31e8f7a18e85e966cf231b67d9363a81c0dd5157465"
      },
      {
        "importer": "packages/shared",
        "name": "remark-breaks",
        "expected_version": "4.0.0",
        "actual_version": "4.0.0",
        "package_json_sha256": "df633e5c230d648c90bbfdfe5e75d28a2492af508a38b8751d9faf28af0443c6"
      },
      {
        "importer": "packages/shared",
        "name": "remark-gfm",
        "expected_version": "4.0.1",
        "actual_version": "4.0.1",
        "package_json_sha256": "c199482a69355b610bd1ff225b097776d4a990445b11e5f4c618930dacc8c79d"
      },
      {
        "importer": "packages/shared",
        "name": "remark-math",
        "expected_version": "6.0.0",
        "actual_version": "6.0.0",
        "package_json_sha256": "936d400d2c2a3f121c4d2b6b84b8a891af02852032b0dcb31f0407d2d6a4364f"
      },
      {
        "importer": "packages/shared",
        "name": "remark-parse",
        "expected_version": "11.0.0",
        "actual_version": "11.0.0",
        "package_json_sha256": "47be70916ff853a6c35d8d858844c7b104d100f70999d579884859cf8d88a50c"
      },
      {
        "importer": "packages/shared",
        "name": "remark-rehype",
        "expected_version": "11.1.2",
        "actual_version": "11.1.2",
        "package_json_sha256": "f9886f99f9f38652d56ca256aa713e359e085ed42f7d89fd66671b49f4b83b64"
      },
      {
        "importer": "packages/shared",
        "name": "unified",
        "expected_version": "11.0.5",
        "actual_version": "11.0.5",
        "package_json_sha256": "f91a44220f8b7c4a4de6ebaab6fc23b92d29a95cb7e5e6a7f0f24d199779fbad"
      },
      {
        "importer": "packages/shared",
        "name": "yaml",
        "expected_version": "2.9.0",
        "actual_version": "2.9.0",
        "package_json_sha256": "20b8b197cbd10dad245d45e463dfe58e4c8c25a47e24bc4256ad9ab58bf35683"
      }
    ],
    "sqlite_wrapper_sha256": "4c758731477f83a648dcc33fe0a79a18b5ae4b56fb53f7f6c97a80a32468e180",
    "resolution": "Every relative and workspace import resolves inside the exported pinned upstream tree. Only identical locked external dependencies are shared with the fork."
  },
  "durability": {
    "upstream": {
      "journal_mode": "wal",
      "synchronous": "NORMAL",
      "synchronous_numeric": 1,
      "reader_worker": true,
      "writer_worker": true
    },
    "native": {
      "engine": "omdb",
      "durability": "Immediate"
    },
    "comparison": "Actual selected production defaults; stronger native commit durability is preserved and any cost is included in visit-commit."
  },
  "sources": {
    "tools/performance-persistence.mjs": "d9f1193f873a91ac838ce0ac6ecbcc8e92ecf797f8684c2c4cf7fe85f1481c20",
    "tools/performance-worker.mjs": "8678ada514f86bfc83e82871d4e067cfd982342d8eefb3a3e45e09a52baa36ce",
    "tools/performance-statistics.mjs": "47ed48c3d848ac3681b4e425912e26205e4eeb96beaa14ae0cc84806b8bd8bbb",
    "tools/performance-contract.json": "c5c48c1ede643bb80c10f786bb82898a3dec71eb89a652d81135b2ed3dbdcb36",
    "tools/performance-baseline.mjs": "78a923cc3ccd3fdf737cdbfcb54c4c04ef2e418ee51ef169c349ebfd60dd2938",
    "apps/server/src/persistence/Omdb.ts": "d419cee6b7141d349c9e62501734cac29fa002a16e746a40f02a6af114f51bc1",
    "apps/server/src/orchestration-v2/NativeProjectionStore.ts": "eb22ff076bbd889ce9eaa72ecb3d7bcca313496bb31058fab4bf92ff958c6fa7",
    "apps/server/src/orchestration-v2/NativeThreadSearch.ts": "ebdea6dfe28aebfbd02eeee8afbabce8be64ccdb277de2f646d2d181429deddd",
    "apps/server/src/persistence/omdb-schema.json": "395b45dba23c8c59851ff0af055023d7536b0e76059fc613f1b96b6e5244a502",
    "crates/storage/src/backend.rs": "8940da0a19967c12aec65fbd555d4938648e395027e7efcbbd6c3dfc48e190e5"
  }
}
```

Raw process order, every request duration, GC observations and sampled process-tree RSS are in performance.json and the worker JSON files. No result row is omitted.
