from pathlib import Path
import hashlib
import json
import os
import resource
import shutil
import signal
import subprocess
import time

scratch = Path('/workspace/scratch/fcf5fdf8376a')
root = scratch / 't3-persistence-profile-a2fb16d'
output = scratch / 't3-persistence-profile-v3-01'
fixture_root = scratch / 't3-profile-fixtures-a2fb16d-v3-01'
build = scratch / 't3-profile-helper-a2fb16d-v3-build-01'
runtime_path = scratch / 't3-profile-runtime-static-a2fb16d-v3-02/runtime.json'
source_path = scratch / 't3-persistence-profile-a2fb16d-source-v3.json'
receipt_path = scratch / 't3-persistence-profile-v3-01.supervisor.json'
stdout_path = scratch / 't3-persistence-profile-v3-01.stdout.log'
stderr_path = scratch / 't3-persistence-profile-v3-01.stderr.log'
digest = lambda value: hashlib.sha256(value).hexdigest()
assert digest(runtime_path.read_bytes()) == 'b6a06608f5d4697ea8bbec2f91289c755005dacaed4f278be993997fb6e756d8'
assert digest(source_path.read_bytes()) == '0129a0b06c9458557c85ddd66cdf079fdf933202b2dd2d74da5cb84c6a91511b'
assert digest((build / 'build-receipt.json').read_bytes()) == '1eb5d3da00e634f8bd579cca9d0d4a11f66c56561af7cfeca92b57b2054187f7'
assert digest((build / 't3-code-ls-db').read_bytes()) == '9d985f08e3c883428031810a8ec8d315e66347c9b8d849ee443130cfa4fab446'
source = json.loads(source_path.read_text())
for name, item in source['files'].items():
    assert digest((root / name).read_bytes()) == item['sha256'], name
assert not any(p.exists() for p in [output, fixture_root, receipt_path, stdout_path, stderr_path])
runtime = json.loads(runtime_path.read_text())
assert runtime['status'] == 'passed' and runtime['baseline']['runtime_provenance']['status'] == 'verified'
assert not runtime['baseline']['runtime_provenance']['issues']
assert len(runtime['workspace_aliases']) == 170 and len(runtime['normalized_absent_root_aliases']) == 69
processes = []
for line in subprocess.check_output(['ps', '-eo', 'pid,ppid,comm'], text=True).splitlines()[1:]:
    columns = line.split()
    if len(columns) == 3 and columns[2] in {'cargo', 'rustc', 'lustr', 't3-code-ls-db'}:
        processes.append(line)
assert not processes, 'An existing compiler/helper process is active'
os.sched_setaffinity(0, {min(os.sched_getaffinity(0))})
fixture_root.mkdir(mode=0o700)
environment = os.environ.copy()
environment['PATH'] = str(scratch / 't3-runtime/node_modules/.bin') + ':' + environment['PATH']
environment['TMPDIR'] = str(fixture_root)
environment['T3_CODE_LS_TEST_TMPDIR'] = str(fixture_root)
assert not environment.get('NODE_OPTIONS') and not environment.get('T3_CODE_LS_TEST_RUNTIME')
node = scratch / 't3-runtime/node_modules/.bin/node'
assert subprocess.check_output([str(node), '--version'], env=environment, text=True).strip() == 'v26.12.1'
command = [str(node), str(root / 'tools/performance-profile.mjs'),
           '--database', str(build / 't3-code-ls-db'), '--output', str(output),
           '--build-receipt', str(build / 'build-receipt.json')]

def memory():
    return {k: v.strip() for k, v in (line.split(':', 1) for line in Path('/proc/meminfo').read_text().splitlines())
            if k in {'MemTotal', 'MemAvailable', 'Shmem', 'SwapTotal', 'SwapFree'}}

def process_state(pid):
    try:
        fields = Path(f'/proc/{pid}/stat').read_text().split(') ', 1)[1].split()
        return {'pid': pid, 'ppid': int(fields[1]), 'pgid': int(fields[2]), 'started': fields[19]}
    except (FileNotFoundError, ProcessLookupError):
        return None

def owned_descendants(pid):
    states = [s for p in Path('/proc').iterdir() if p.name.isdigit() and (s := process_state(int(p.name))) is not None]
    owned = {pid}
    while True:
        expanded = owned | {s['pid'] for s in states if s['ppid'] in owned}
        if expanded == owned:
            return [s for s in states if s['pid'] in owned]
        owned = expanded

receipt = {
    'schema': 1, 'qualifies': False, 'purpose': 'single finer attribution diagnostic',
    'command': command, 'fixture_root': str(fixture_root), 'cpu_affinity': sorted(os.sched_getaffinity(0)),
    'affinity_scope': 'This authorized v3 attempt uses one CPU for both conditions; the earlier v2 diagnostic used nine. Cross-version timings do not isolate observer overhead.',
    'runtime_attestation_sha256': digest(runtime_path.read_bytes()),
    'source_manifest_sha256': digest(source_path.read_bytes()),
    'supervisor_sha256': digest(Path(__file__).read_bytes()),
    'selected_environment': {k: environment.get(k) for k in ['TMPDIR', 'T3_CODE_LS_TEST_TMPDIR', 'T3_CODE_LS_TEST_RUNTIME', 'NODE_OPTIONS']},
    'timeout_seconds': 1800, 'driver_log_limit_bytes': 4 * 1024 * 1024,
    'conflicting_processes_before': processes, 'memory_before': memory(),
    'filesystem_free_bytes_before': shutil.disk_usage(fixture_root).free,
    'started_at_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()), 'status': 'running',
}
def save():
    receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
save()
start = time.monotonic()
child = None
try:
    with stdout_path.open('xb') as out, stderr_path.open('xb') as err:
        child = subprocess.Popen(command, cwd=root, env=environment, stdout=out, stderr=err, start_new_session=True)
        receipt['owned_driver_pid'] = child.pid
        save()
        while child.poll() is None:
            assert time.monotonic() - start < receipt['timeout_seconds'], 'Profile supervisor timeout'
            assert stdout_path.stat().st_size <= receipt['driver_log_limit_bytes'], 'Driver stdout exceeded its limit'
            assert stderr_path.stat().st_size <= receipt['driver_log_limit_bytes'], 'Driver stderr exceeded its limit'
            try:
                child.wait(timeout=2)
            except subprocess.TimeoutExpired:
                pass
        receipt['exit_code'] = child.returncode
    receipt['source_unchanged'] = all(digest((root / name).read_bytes()) == item['sha256'] for name, item in source['files'].items())
    receipt['helper_unchanged'] = digest((build / 't3-code-ls-db').read_bytes()) == '9d985f08e3c883428031810a8ec8d315e66347c9b8d849ee443130cfa4fab446'
    assert receipt['exit_code'] == 0 and receipt['source_unchanged'] and receipt['helper_unchanged']
    receipt['status'] = 'completed'
except BaseException as error:
    receipt['status'] = 'failed'
    receipt['failure_type'] = type(error).__name__
    if child is not None and child.poll() is None:
        owned = owned_descendants(child.pid)
        groups = {s['pgid'] for s in owned if any(t['pid'] == s['pgid'] for t in owned)}
        receipt['cleanup_owned_processes'] = owned
        for group in groups:
            try: os.killpg(group, signal.SIGTERM)
            except ProcessLookupError: pass
        try: child.wait(timeout=5)
        except subprocess.TimeoutExpired: pass
        for s in owned:
            current = process_state(s['pid'])
            if current is not None and current['started'] == s['started']:
                try: os.kill(s['pid'], signal.SIGKILL)
                except ProcessLookupError: pass
        child.wait(timeout=10)
    raise
finally:
    receipt['elapsed_seconds'] = time.monotonic() - start
    receipt['finished_at_utc'] = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
    receipt['children_max_rss_kib'] = resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss
    receipt['memory_after'] = memory()
    receipt['filesystem_free_bytes_after'] = shutil.disk_usage(fixture_root).free
    receipt['fixture_children_after'] = sorted(p.name for p in fixture_root.iterdir())
    receipt['stdout_sha256'] = digest(stdout_path.read_bytes())
    receipt['stderr_sha256'] = digest(stderr_path.read_bytes())
    if (output / 'profile.json').exists():
        receipt['profile_sha256'] = digest((output / 'profile.json').read_bytes())
    save()
print(json.dumps({k: receipt.get(k) for k in ['status', 'exit_code', 'elapsed_seconds', 'profile_sha256', 'source_unchanged', 'helper_unchanged', 'fixture_children_after']}, indent=2))
