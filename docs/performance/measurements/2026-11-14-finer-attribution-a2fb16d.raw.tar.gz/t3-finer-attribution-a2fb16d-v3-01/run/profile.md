# Persistence request attribution diagnostic

Status: completed-diagnostic. Qualifies: false. Attempt: 2026-11-14T17-43-54.271Z-cea5f26a.

Base commit: a2fb16d84f089e2a7ca681e431e6acff083695bf. Tree: 9aca39040e56c362ed1edba9e69d49602b5feee8.
Observer patch SHA-256: b26cf8c7e0ac9bbecc6e2f4cd0cb9704597f42034d64ce1f2707b791c5918898.
Helper SHA-256: 9d985f08e3c883428031810a8ec8d315e66347c9b8d849ee443130cfa4fab446.
Build receipt SHA-256: 1eb5d3da00e634f8bd579cca9d0d4a11f66c56561af7cfeca92b57b2054187f7.
Pinned stock oracle: 5fe2f7e4567d9e530ded0dabc9d706db27d77b84.

Compiler provenance: **manifest-reported**. Manifest-reported route: bluefe-rustc-via-lustr. Build profile: release.
Expected route: bluefe-rustc-via-lustr. Expected compiler revision: `1b74388e196ee8813f38ba9eeb6d4ab43b6b1071`. Expected coordinator: `07470b20464bf097c3c88983124aff56c5e44f9a`.
Manifest-reported compiler identity: not supplied. The expected lock identity does not establish which drivers built this executable.
Diagnostic mode binds only the supplied manifest's executable hash; its source, compiler route and build identity are reported claims, not qualification.

## Same instrumented build, probes disabled and enabled

| Workload | Disabled median / p95 / worst ms | Enabled median / p95 / worst ms |
|---|---:|---:|
| service-open-and-first-operations | 1052.021 / 1052.021 / 1052.021 | 1013.593 / 1013.593 / 1013.593 |
| sidebar-shell | 148.998 / 177.625 / 191.107 | 153.969 / 301.370 / 355.419 |
| history-window | 127.428 / 216.028 / 296.369 | 134.309 / 161.022 / 162.505 |
| message-search | 48.739 / 99.042 / 137.442 | 48.229 / 101.911 / 162.159 |
| accent-search | 39.793 / 47.191 / 48.301 | 42.379 / 71.655 / 77.367 |
| visit-commit | 6.729 / 13.287 / 15.744 | 7.036 / 10.969 / 12.321 |

One worker per condition. These descriptive distributions do not establish a causal overhead or production speed ratio.

Correctness: passed.

## Native metric scopes

Fields marked unobserved have no measurement; their numeric zero is not zero bytes or allocations. Times are inclusive and nested; these rows must not be summed as independent costs.

| Static metric | Input / output units | Input / output byte scope |
|---|---|---|
| backend_open | unobserved / unobserved | unobserved / unobserved |
| backend_open_read_only | unobserved / unobserved | unobserved / unobserved |
| backend_open_exclusive | unobserved / unobserved | unobserved / unobserved |
| checked_open | unobserved / unobserved | unobserved / unobserved |
| begin_snapshot | unobserved / unobserved | unobserved / unobserved |
| begin_reserved | unobserved / unobserved | unobserved / unobserved |
| get | keys / present_values | key_lengths / value_lengths |
| get_many | keys / value_slots | key_lengths / present_value_lengths |
| scan | ranges / rows | range_boundary_lengths / row_key_and_value_lengths |
| observe_mutation | keys / unobserved | key_lengths / unobserved |
| commit_staged | writes / unobserved | write_key_and_value_lengths / unobserved |
| commit_actual | unobserved / unobserved | unobserved / unobserved |
| store_open | unobserved / unobserved | unobserved / unobserved |
| decode_frame | unobserved / unobserved | unobserved / unobserved |
| evaluate | unobserved / unobserved | unobserved / unobserved |
| encode_frame | unobserved / unobserved | unobserved / unobserved |
| flush_frame | unobserved / unobserved | unobserved / unobserved |
| index_witness_decode | encoded_witnesses / decoded_witnesses | encoded_witness_lengths / unobserved |
| compact_metadata_decode | encoded_metadata / decoded_metadata | encoded_metadata_lengths / unobserved |
| canonical_row_decode_validate | encoded_rows / validated_rows | encoded_row_lengths / unobserved |
| lookup_key_build | locations / keys | unobserved / encoded_key_lengths |
| canonical_digest | values / digests | unobserved / utf8_hex_string_lengths |
| digest_hex | digests / hex_strings | digest_byte_lengths / utf8_hex_string_lengths |
| payload_json_parse | json_strings / parsed_values | utf8_json_lengths / unobserved |
| owned_text_copy | strings / strings | utf8_string_lengths / utf8_string_lengths |
| indexed_row_clone | row_fields / row_fields | unobserved / unobserved |
| sort_key_build | rows / keyed_or_validated_rows | unobserved / unobserved |
| sort_compare | rows / rows | unobserved / unobserved |
| window_eligibility | items / eligible_items | unobserved / unobserved |
| window_selection | eligible_items / retained_items | unobserved / unobserved |
| shell_thread_assembly | threads / rows | unobserved / unobserved |

## Decisions and limits

- This isolated diagnostic runs the existing stock/native correctness and reopen checks with observers unconfigured, then one native probes-disabled worker and one native probes-enabled worker.
- Correctness validation retains its deliberate rollback and discarded-helper lifecycle. It has no attribution profile; its original data/order, exact rollback sentinel and committed reopen checks remain required.
- Both native measurement workers use the same instrumented optimized helper, the same fixture, three excluded warmups and twelve retained samples per API.
- The fixed qualification contract and thresholds are unchanged. This attempt does not run its eight paired stock/native comparisons and cannot qualify any source.
- The disabled/enabled comparison indicates probe overhead only, with one process per condition and a fixed order. It is not an uninstrumented production comparison or a causal speed estimate.
- Fixture creation, migration and index preparation remain outside worker API timing, using the unchanged original runner logic.
- Fourteen finer static metrics separate witnessed/compact/row decoding, key/digest construction, unchanged digest finalization/hex formatting, payload parsing, selected copies, sorts and selection/assembly phases. No production algorithm is optimized by the probes.
- All native metrics name instrumented application-wrapper calls. Get includes cached writer observations; begin_snapshot covers its named entry point, not every engine snapshot.
- Times are inclusive wall times. Request/evaluate, store/backend/checked open, get_many/get, and commit_staged/commit_actual overlap; their totals must not be added or subtracted as disjoint costs. A residual is not proof of JSON, CPU or pure IPC cost.
- Selection and assembly phases contain read, decode, copy and sort children. Canonical row validation contains key construction; key construction contains canonical_digest, which contains digest_hex. digest_hex includes SHA-256 finalization and the existing formatting expression, not only allocator cost.
- A static metric field marked unobserved has no byte/unit measurement: its numeric zero is a placeholder. Copy counts cover named operations only; key/row/Value contents are never walked to estimate allocation volume.
- Fine timers add Instant reads, atomics and mutex aggregation to high-frequency paths. Their overhead is not assumed small. The same instrumented helper is used with probes disabled and enabled; the disabled control is not an uninstrumented production build.
- The client wait includes write, helper work, transport, scheduling and UTF-8 framing. Client decode includes envelope and result validation.
- Only static labels, ordinals, counts, lengths and timings are added by observers. No database keys, identifiers or payload values are recorded by probes.
- Successful helper output requires proven backend handle closure, complete request rows, zero active spans, and no recorded late span. Missing output rejects the profile.
- The observer has fixed row and byte caps. Overflow, incomplete shutdown or mismatched request ordinals rejects the diagnostic.
- RSS and GC retain the original advisory scope. The OS page cache is not flushed; filesystem metadata does not prove physical-device or power-loss behavior.
- The raw correctness worker results use only the existing controlled synthetic fixture. They are separate from the metadata-only probe files.

Raw native/client probe files, all worker samples, source hashes, exact command, host/filesystem facts and the build receipt are retained with profile.json.
