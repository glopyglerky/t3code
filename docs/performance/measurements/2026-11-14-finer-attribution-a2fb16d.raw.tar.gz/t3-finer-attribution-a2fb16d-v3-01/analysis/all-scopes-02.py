from pathlib import Path
import collections
import hashlib
import json
import math
import statistics

scratch = Path('/workspace/scratch/fcf5fdf8376a')
root = scratch / 't3-persistence-profile-v3-01'
target = scratch / 't3-profile-finer-attribution-v3-01.json'
assert not target.exists()
digest = lambda data: hashlib.sha256(data).hexdigest()
read = lambda p: json.loads(p.read_text())
report = read(root / 'profile.json')
source = read(scratch / 't3-persistence-profile-a2fb16d-source-v3.json')
base = read(scratch / 't3-profile-attribution-v3-01.json')
assert digest((root / 'profile.json').read_bytes()) == base['report_sha256'] == 'fb27430b6aa656419ba4c6cde25ce3831779762923c41a6b6f83fc8bd76a334e'
scopes = {s['kind']: s for s in source['metric_scopes']}
assert len(scopes) == 31 and report['native_metric_scopes'] == source['metric_scopes']
fields = ['calls', 'elapsed_ns', 'input_units', 'input_bytes', 'output_units', 'output_bytes']
raw_checks = []
for profile in report['profiles']:
    observer = root / (profile['worker'] + '.observer')
    for descriptor in profile['files']:
        p = observer / descriptor['file']
        assert p.stat().st_size == descriptor['bytes'] and digest(p.read_bytes()) == descriptor['sha256']
    client = read(observer / 'client.json')
    assert client['incomplete'] is False and client['qualifies'] is False
    assert client['max_connections'] == 32 and client['max_requests_per_connection'] == 2048
    assert client['max_markers'] == 256 and client['max_output_bytes'] == 8388608
    assert len(client['connections']) <= 32
    if client['enabled']:
        assert isinstance(client['markers'], list) and len(client['markers']) <= 256
        assert all(m['finished'] is True for m in client['markers'])
    else:
        assert client['markers'] is None
    for connection in client['connections']:
        if connection['helper_file'] is None:
            assert connection['mode'] == 'owner-lock'
            continue
        helper = read(observer / connection['helper_file'])
        assert helper['process_completed'] and helper['store_close_confirmed']
        assert helper['active_spans_at_flush'] == 0 and helper['incomplete'] is False
        assert helper['enabled'] == client['enabled'] and helper['qualifies'] is False
        assert helper['max_request_rows'] == 2048 and helper['max_output_bytes'] == 8388608
        assert helper['metric_scopes'] == source['metric_scopes']
        if not client['enabled']:
            assert helper['requests'] is None
            raw_checks.append({'worker': profile['worker'], 'helper': connection['helper_file'], 'closed': True, 'requests': None})
            continue
        assert len(helper['requests']) == len(connection['requests']) + 1 <= 2048
        assert helper['requests'][0]['ordinal'] == 0 and helper['requests'][0]['kind'] == 'outside_request'
        for ordinal, (expected, actual) in enumerate(zip(connection['requests'], helper['requests'][1:]), 1):
            assert expected['helper_ordinal'] == actual['ordinal'] == ordinal
            assert expected['kind'] == actual['kind'] and expected['input_bytes'] == actual['frame_bytes']
            assert expected['finished'] and expected['success'] and actual['finished'] and actual['response_ok']
        for row in helper['requests']:
            metrics = {m['kind']: m['counts'] for m in row['metrics']}
            assert len(metrics) == len(row['metrics']) and set(metrics) <= set(scopes)
            for name, counts in metrics.items():
                assert set(counts) == set(fields) and counts['calls'] > 0
                assert all(type(v) is int and 0 <= v <= 9007199254740991 for v in counts.values())
                for field in fields[2:]:
                    if scopes[name][field] == 'unobserved':
                        assert counts[field] == 0
            assert metrics.get('canonical_digest', {}).get('calls', 0) == metrics.get('digest_hex', {}).get('calls', 0)
        raw_checks.append({'worker': profile['worker'], 'helper': connection['helper_file'], 'closed': True, 'requests': len(connection['requests'])})

def stats(values):
    ordered = sorted(values)
    def quantile(q):
        pos = (len(ordered) - 1) * q
        lower = math.floor(pos)
        return ordered[lower] + (pos - lower) * (ordered[min(lower + 1, len(ordered) - 1)] - ordered[lower])
    return {'samples': len(values), 'sum': sum(values), 'mean': statistics.mean(values),
            'median': quantile(.5), 'p95': quantile(.95), 'worst': max(values), 'raw': values}

by_marker = collections.defaultdict(list)
for request in base['requests']:
    by_marker[request['marker_ordinal']].append(request)
enabled = next(run for run in report['runs'] if run['purpose'] == 'measurement' and run['native_probes_enabled'])
workloads = []
for api in ['sidebar-shell', 'history-window', 'message-search', 'accent-search', 'visit-commit']:
    markers = sorted((m for m in base['api_markers'] if m['phase'] == 'sample' and m['api'] == api), key=lambda m: m['sample'])
    assert [m['sample'] for m in markers] == list(range(12))
    sample_rows = []
    for marker in markers:
        requests = by_marker[marker['ordinal']]
        assert requests and all(r['phase_api'] == 'sample:' + api and r['sample_index'] == marker['sample'] for r in requests)
        counters = {name: dict.fromkeys(fields, 0) for name in scopes}
        for request in requests:
            for metric in request['helper']['metrics']:
                for field in fields:
                    counters[metric['kind']][field] += metric['counts'][field]
        sample_rows.append({'sample': marker['sample'], 'marker': marker['ordinal'],
            'api_ms': enabled['result']['samples'][api][marker['sample']],
            'marker_ms': marker['elapsed_ms'],
            'request_count': len(requests), 'request_kinds': dict(collections.Counter(r['helper']['kind'] for r in requests)),
            'helper_wall_ms': sum(r['helper']['elapsed_ns'] for r in requests) / 1e6,
            'client_ms': {key: sum(r['client'][key] for r in requests) for key in ['encode_ms', 'wait_ms', 'decode_ms', 'total_ms']},
            'counters': counters})
    metrics = []
    for name, scope in scopes.items():
        counters = {}
        for field in fields:
            measured = field in ['calls', 'elapsed_ns'] or scope[field] != 'unobserved'
            values = [row['counters'][name][field] for row in sample_rows]
            counters[field] = {'observed': measured, 'scope': ('inclusive_wall_ns' if field == 'elapsed_ns' else 'instrumented_calls') if field in ['calls', 'elapsed_ns'] else scope[field],
                               'distribution': stats(values) if measured else None}
        metrics.append({'kind': name, 'scope': scope, 'instrumented_calls_observed': sum(row['counters'][name]['calls'] for row in sample_rows) > 0,
            'elapsed_ms': stats([row['counters'][name]['elapsed_ns'] / 1e6 for row in sample_rows]), 'counters': counters})
    workloads.append({'id': api, 'api_ms': stats([row['api_ms'] for row in sample_rows]),
        'helper_wall_ms': stats([row['helper_wall_ms'] for row in sample_rows]),
        'client_ms': {key: stats([row['client_ms'][key] for row in sample_rows]) for key in ['encode_ms', 'wait_ms', 'decode_ms', 'total_ms']},
        'metrics': metrics, 'samples': sample_rows})

output = {'schema': 1, 'purpose': 'all-scope finer attribution from retained raw metadata', 'qualifies': False,
    'source_commit': report['source_commit'], 'source_tree': report['source_tree'],
    'report_sha256': base['report_sha256'], 'base_analysis_sha256': digest((scratch / 't3-profile-attribution-v3-01.json').read_bytes()),
    'analysis_source_sha256': digest(Path(__file__).read_bytes()), 'helper_sha256': report['executable_sha256'],
    'observer_patch_sha256': report['observer_patch_sha256'], 'cpu_affinity': [0],
    'raw_checks': raw_checks, 'workloads': workloads, 'metric_scopes': list(scopes.values()),
    'limits': [
        'Every distribution contains twelve whole API observations, each aggregating its complete helper request set for one metric. Parent/child metric spans remain overlapping.',
        'Unobserved unit/byte distributions are null, not measured zero. A row with no instrumented calls means that probe did not execute on this fixture; it says nothing about other uninstrumented source paths.',
        'Same-build off/on workers have fixed order and one process per condition. Results are descriptive; no causal overhead, CPU or storage verdict.',
        'V3 uses one CPU while v2 used nine. No cross-version algorithm or instrumentation speed conclusion follows.',
    ]}
target.write_text(json.dumps(output, indent=2) + '\n')
print(json.dumps({'path': str(target), 'sha256': digest(target.read_bytes()), 'bytes': target.stat().st_size,
                  'workloads': len(workloads), 'metric_rows': sum(len(w['metrics']) for w in workloads), 'raw_helper_checks': raw_checks}, indent=2))
