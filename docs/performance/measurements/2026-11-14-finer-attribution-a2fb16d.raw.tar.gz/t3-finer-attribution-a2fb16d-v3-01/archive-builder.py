from pathlib import Path
import gzip
import hashlib
import io
import json
import subprocess
import tarfile

scratch = Path('/workspace/scratch/fcf5fdf8376a')
documentation = scratch/'t3-finer-profile-docs'
destination = documentation/'docs/performance/measurements/2026-11-14-finer-attribution-a2fb16d.raw.tar.gz'
assert not destination.exists(), 'Retained evidence must not be overwritten'
base = 'a2fb16d84f089e2a7ca681e431e6acff083695bf'
prefix = 't3-finer-attribution-a2fb16d-v3-01'
entries = {}

def add(name, data):
    assert name not in entries and not name.startswith('/') and '..' not in Path(name).parts
    assert len(data) <= 16 * 1024 * 1024, name
    entries[name] = data

def retain(name, source):
    path = scratch/source
    assert path.is_file() and not path.is_symlink(), path
    add(name, path.read_bytes())

files = {
    "source/v2-observer.patch": "t3-persistence-profile-a2fb16d-observer-v2.patch",
    "source/v2-source-review.json": "t3-persistence-profile-a2fb16d-source-v2.json",
    "source/v3-observer.patch": "t3-persistence-profile-a2fb16d-observer-v3.patch",
    "source/v2-to-v3.patch": "t3-persistence-profile-a2fb16d-v2-to-v3.patch",
    "source/v3-source-review.json": "t3-persistence-profile-a2fb16d-source-v3.json",
    "source/finer-proposal.md": "t3-finer-attribution-proposal-a2fb16d.md",
    "source/parser-checks.json": "t3-profile-v3-parser-checks.json",
    "source/allowed-static-operations.json": "t3-profile-static-operations.json",
    "build/supervisor.py": "t3-profile-build-a2fb16d-v3.py",
    "build/preflight.json": "t3-profile-v3-build-preflight-01.json",
    "build/build-receipt.json": "t3-profile-helper-a2fb16d-v3-build-01/build-receipt.json",
    "build/build.log": "t3-profile-helper-a2fb16d-v3-build-01/build.log",
    "runtime/original-preparation.py": "t3-profile-runtime-prepare-a2fb16d.py",
    "runtime/original-preparation-and-source-aliases.json": "t3-profile-runtime-a2fb16d.json",
    "runtime/original-root-alias-normalization.json": "t3-profile-runtime-root-normalization-a2fb16d.json",
    "runtime/v3-preflight-01.mjs": "t3-profile-runtime-static-a2fb16d-v3.mjs",
    "runtime/v3-preflight-01-failed.json": "t3-profile-runtime-static-a2fb16d-v3-01/runtime.json",
    "runtime/v3-preflight-01.supervisor.json": "t3-profile-runtime-static-a2fb16d-v3-01.supervisor.json",
    "runtime/v3-preflight-01.stdout.log": "t3-profile-runtime-static-a2fb16d-v3-01.stdout.log",
    "runtime/v3-preflight-01.stderr.log": "t3-profile-runtime-static-a2fb16d-v3-01.stderr.log",
    "runtime/v3-preflight-02.mjs": "t3-profile-runtime-static-a2fb16d-v3-02.mjs",
    "runtime/v3-preflight-correction.patch": "t3-profile-runtime-static-a2fb16d-v3-02.patch",
    "runtime/v3-preflight-02-passed.json": "t3-profile-runtime-static-a2fb16d-v3-02/runtime.json",
    "runtime/v3-preflight-02.supervisor.json": "t3-profile-runtime-static-a2fb16d-v3-02.supervisor.json",
    "runtime/v3-preflight-02.stdout.log": "t3-profile-runtime-static-a2fb16d-v3-02.stdout.log",
    "runtime/v3-preflight-02.stderr.log": "t3-profile-runtime-static-a2fb16d-v3-02.stderr.log",
    "run/supervisor.py": "t3-profile-run-v3-01.py",
    "run/supervisor.json": "t3-persistence-profile-v3-01.supervisor.json",
    "run/supervisor.stdout.log": "t3-persistence-profile-v3-01.stdout.log",
    "run/supervisor.stderr.log": "t3-persistence-profile-v3-01.stderr.log",
    "analysis/aggregate.py": "t3-profile-analyze-v3-01.py",
    "analysis/attribution.json": "t3-profile-attribution-v3-01.json",
    "analysis/all-scopes-01-draft.py": "t3-profile-finer-analyze-v3-01.py",
    "analysis/all-scopes-01-error.txt": "t3-profile-finer-analysis-attempt01.txt",
    "analysis/all-scopes-02.py": "t3-profile-finer-analyze-v3-02.py",
    "analysis/all-scopes.json": "t3-profile-finer-attribution-v3-01.json",
    "archive-builder.py": "t3-profile-package-v3-01.py",
    "report-builder.py": "t3-profile-write-report-v3-01.py"
}
for name, source in files.items():
    retain(name, source)
for path in sorted((scratch/'t3-persistence-profile-v3-01').rglob('*')):
    if path.is_file():
        retain('run/'+str(path.relative_to(scratch/'t3-persistence-profile-v3-01')), str(path.relative_to(scratch)))
report = json.loads(entries['run/profile.json'])
for path in ['tools/performance-persistence.mjs', 'tools/performance-worker.mjs']:
    contents = subprocess.check_output(['git', '-C', str(documentation), 'show', base+':'+path])
    add('source/original/'+path, contents)
add('source/unchanged-source-section-proof.json', (json.dumps({
    'base_commit': base,
    'base_tree': report['source_tree'],
    'observer_patch_sha256': report['observer_patch_sha256'],
    'proof': report['extraction'],
    'scope': 'The private driver asserts these copied sections equal the original runner and worker before executing any application worker. Originals and complete private-file deltas are retained in source/.',
}, indent=2)+'\n').encode())
add('README.md', b"# Finer persistence attribution evidence, v3\n\nThis archive is one completed diagnostic, never a qualification or stock-speed\nresult. run/profile.json is retained byte-for-byte. Both unconfigured correctness\nworkers and one native probes-disabled then one probes-enabled worker passed.\nEach measured worker used three excluded warmups and twelve cycles. V3 uses one\nCPU, whereas the prior v2 diagnostic used nine. Separate attempts cannot isolate\nobserver or algorithm speed effects; the fixed-order off/on pair is descriptive.\n\nsource/ contains the reviewed v2 baseline patch and v3 full/incremental patches,\nsource identities, parser checks, proposal and unchanged six-section proof.\nAll 31 labels and unit/byte scopes are static. The exact digest finalization and\nformat!(hex) algorithm remains unchanged. No production optimization is included.\n\nbuild/ records the actual pinned Lustr coordinator invocation, selected environment,\nsix tool hashes, 161 source inputs, full log, separate optimized helper hash and\nsource stability. The executable is not embedded. Its local build receipt is\nmanifest-reported diagnostic provenance, not an independent CI qualification.\n\nruntime/ retains both static v3 attempts, including the first failed alias check.\nThe full frozen 440-descriptor graph passed, but an added historical-alias loop\nexpected a root link removed by the already-approved normalization. The second\nscript binds both historical receipts, requires all 69 removed root links absent\nusing lstat, and checks the remaining 170 workspace aliases exactly. No aliases,\npackages, workload or fixed source changed; no application worker ran in either\nstatic attempt. Both stock exports were removed after verification.\n\nrun/ retains all four raw workers, every config/output, both complete client/helper\nprofile sets, supervisor source/receipt/logs, byte scopes, host/filesystem facts,\nhelper/source hashes and cleanup witnesses. Correctness uses only the controlled\nsynthetic fixture. The observer itself records no keys, identifiers or payloads.\n\nanalysis/ independently validates every raw file hash, closure, cap, request\nordinal/kind/frame/success and metric scope. It retains all 574 joined requests,\n81 markers, 17 phase groups and 155 workload-by-metric rows. Every measured row\nhas twelve whole-API observations with raw values, means, medians, p95 and worst.\nUnobserved unit/byte distributions are null, never measured zero. The first\nmetadata-only analyzer's null-marker mistake and corrected source are retained.\n\nEvery duration is an inclusive wall observation. Parent/child spans overlap;\nno sum or residual is a CPU, allocator, JSON or physical-I/O total. In particular\ncanonical_digest includes digest_hex, which includes SHA-256 finalization and\nunchanged hex rendering. Unit and byte counters cover named wrapper boundaries,\nnot memory allocations or storage traffic. All historical failures are retained.\n\nThis archive contains regular files only: no database, helper executable, target,\nnode_modules, user state, credentials or real-provider outputs. SHA256SUMS.json\nindexes every other entry. Paths bind the original owned environment; reproduction\nelsewhere needs path remapping while preserving source and workload semantics.\n")
manifest = {
    'schema': 1,
    'qualifies': False,
    'base_commit': base,
    'base_tree': report['source_tree'],
    'observer_patch_sha256': report['observer_patch_sha256'],
    'helper_sha256': report['executable_sha256'],
    'original_report_sha256': hashlib.sha256(entries['run/profile.json']).hexdigest(),
    'files': [{
        'path': name,
        'bytes': len(contents),
        'sha256': hashlib.sha256(contents).hexdigest(),
    } for name, contents in sorted(entries.items())],
}
add('SHA256SUMS.json', (json.dumps(manifest, indent=2)+'\n').encode())
assert sum(map(len, entries.values())) < 16 * 1024 * 1024
with destination.open('xb') as output:
    with gzip.GzipFile(filename='', mode='wb', compresslevel=9, fileobj=output, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for name, contents in sorted(entries.items()):
                info = tarfile.TarInfo(prefix+'/'+name)
                info.size = len(contents)
                info.mode = 0o644
                info.uid = info.gid = 0
                info.mtime = 0
                archive.addfile(info, io.BytesIO(contents))
print(json.dumps({
    'archive': str(destination),
    'sha256': hashlib.sha256(destination.read_bytes()).hexdigest(),
    'compressed_bytes': destination.stat().st_size,
    'entries': len(entries),
    'uncompressed_bytes': sum(map(len, entries.values())),
    'original_report_sha256': manifest['original_report_sha256'],
}, indent=2))
