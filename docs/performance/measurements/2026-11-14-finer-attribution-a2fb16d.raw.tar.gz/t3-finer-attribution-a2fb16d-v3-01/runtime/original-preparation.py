from pathlib import Path
import hashlib
import json
import os
import shutil
import stat

scratch = Path('/workspace/scratch/fcf5fdf8376a')
source = scratch / 't3code-ls'
target = scratch / 't3-persistence-profile-a2fb16d'
receipt_path = scratch / 't3-profile-runtime-a2fb16d.json'
assert not receipt_path.exists(), 'Runtime preparation evidence is not overwritten'
for name in ['pnpm-lock.yaml', 'pnpm-workspace.yaml', 'package.json']:
    assert (source / name).read_bytes() == (target / name).read_bytes(), name
importers = [Path('.'), Path('tools/oracles')]
workspaces = {}
for group in ['apps', 'packages']:
    for directory in sorted((target / group).iterdir()):
        manifest = directory / 'package.json'
        if directory.is_dir() and manifest.is_file():
            relative = directory.relative_to(target)
            importers.append(relative)
            model = json.loads(manifest.read_text())
            if model.get('name'):
                workspaces[model['name']] = directory
            assert (source / relative / 'package.json').read_bytes() == manifest.read_bytes()
linked_files = 0
def link_file(src, dst):
    global linked_files
    os.link(src, dst)
    linked_files += 1
    return dst
copied = []
for importer in importers:
    modules = source / importer / 'node_modules'
    if not modules.is_dir():
        continue
    destination = target / importer / 'node_modules'
    assert not destination.exists() and not destination.is_symlink(), destination
    shutil.copytree(modules, destination, symlinks=True, copy_function=link_file)
    copied.append(importer.as_posix())
rewritten = []
for importer in copied:
    modules = target / importer / 'node_modules'
    for directory, dirs, files in os.walk(modules, followlinks=False):
        for name in dirs + files:
            path = Path(directory) / name
            if not path.is_symlink():
                continue
            raw = os.readlink(path)
            package_name = path.parent.name + '/' + name if path.parent.name.startswith('@') else name
            if package_name in workspaces and path.parent.name != '.bin':
                replacement = str(workspaces[package_name])
            elif os.path.isabs(raw) and (raw == str(source) or raw.startswith(str(source) + '/')):
                replacement = str(target) + raw[len(str(source)):]
            else:
                continue
            if raw != replacement:
                path.unlink()
                path.symlink_to(replacement)
                rewritten.append(path.relative_to(target).as_posix())
aliases = []
for importer in copied:
    for name, directory in sorted(workspaces.items()):
        path = target / importer / 'node_modules' / name
        if path.exists() or path.is_symlink():
            assert path.resolve(strict=True) == directory.resolve(strict=True), path
            aliases.append({'importer': importer, 'name': name, 'target': directory.relative_to(target).as_posix()})
metadata = {
    'schema': 1,
    'purpose': 'isolated fixed-5fe diagnostic dependency preparation',
    'qualifies': False,
    'strategy': 'Separate directory/symlink entries; immutable package files hard-linked from the existing frozen installation. No installer or package/source mutation.',
    'source_workspace': str(source),
    'profile_workspace': str(target),
    'preparation_script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'linked_regular_files': linked_files,
    'importers': copied,
    'rewritten_symlinks': rewritten,
    'workspace_aliases': aliases,
    'pnpm_lock_sha256': hashlib.sha256((target/'pnpm-lock.yaml').read_bytes()).hexdigest(),
    'installed_lock_sha256': hashlib.sha256((target/'node_modules/.pnpm/lock.yaml').read_bytes()).hexdigest(),
    'modules_metadata_sha256': hashlib.sha256((target/'node_modules/.modules.yaml').read_bytes()).hexdigest(),
}
receipt_path.write_text(json.dumps(metadata, indent=2) + '\n')
print(json.dumps({key: metadata[key] for key in ['linked_regular_files','importers','pnpm_lock_sha256','installed_lock_sha256','modules_metadata_sha256']}))
print('Verified workspace aliases: ' + str(len(aliases)) + '; rewritten private symlinks: ' + str(len(rewritten)))
