# Finer native read attribution: read-only proposal

Status: approved private diagnostic design; implementation is being prepared for source review only. No production source, build, dependency layout or workload has changed. The original source-only proposal is retained unchanged as `t3-finer-attribution-proposal-a2fb16d-v1.md` (SHA-256 `3337f3e8ae7e90dd1f627312315ffebb1990c7f7ca8ccea3c74a5fd041f53565`).

## Question and fixed reference

The completed a2fb diagnostic measured mean helper evaluate spans of 128.562 ms for sidebar and 131.017 ms for history. Its application get/scan wrapper totals were much smaller, but those inclusive spans do not partition the request. The difference is unassigned wall time; it is not a measurement of JSON, CPU, allocation or I/O cost.

Trace base: `a2fb16d84f089e2a7ca681e431e6acff083695bf`, tree `9aca39040e56c362ed1edba9e69d49602b5feee8`, with the already retained observer v2 patch `fd598676c15bdeeb2c503b01a7f9fb48f161bb0d008d84119162234d180563d1`. Private worktree: `t3-persistence-profile-a2fb16d`. This remains the frozen 5fe diagnostic base; it excludes later f751/sidebar corrections and the isolated history/search experiments. Those distinctions must remain explicit if a new profile is authorized. Moving to another production base would require a fresh complete diff and identity review before building.

Goal: measure concrete application function boundaries for decoding, payload parsing, copying, ordering, key construction and selection. No production optimization is proposed here.

## What the source actually does

1. `redb_projection_window_index.rs::equal_metadata` (419–472) scans up to 128 relationship witnesses, decodes each `IndexRow`, validates its table/column/value and encoded key, fetches the compact row, then decodes a separate `Metadata` structure and checks its primary/order. `read_metadata` (475–496) repeats the compact decode for point lookups. Neither path currently has a parsing timer.
2. Each successful relationship witness normally constructs `index_key`, which hashes its indexed value and primary identity, then constructs a separate metadata key that hashes the primary again. These are three digest calls per witness on that path, a source-derived count rather than an observed timing. `request_digest` also canonicalizes JSON, sorts object keys, allocates serialized scalar fragments and formats hex bytes; its time cannot be labeled SHA-256 cost alone. The `json!` arguments and prefix construction happen outside that function.
3. Sidebar `Meta::from_index` (shell 87–99) parses the compact `payload_json` after obtaining an owned string. `ThreadData::load` (361–371) loads six relationship cohorts per requested thread, and `shell_thread` (572 onward) evaluates predicates, sorts runs, fetches selected full rows and constructs the reply. `Meta::col` borrows strings; it should not be counted as an owned copy.
4. History `retained` loads thread items, run items and attempts (window 149–175), performs per-item eligibility (198–304), including node lookup under defer_work, then builds anchors, groups, hidden sets and selected rows (305–550). `json(row)` delegates to records `payload` (142–144), which parses the compact JSON again each time it is called. The run-wide item map still has all three previously reviewed consumers; no traversal is removed.
5. `redb_application_rows::text` (25–35) validates a cell and returns `str::to_owned`; `nullable` delegates to it for non-null cells. Repeated predicates and sort-key creation therefore copy strings. `window::cloned` (65–70) clones the whole row map when populating eligible/retained cohorts. These operations are distinct from parsing.
6. `window::sort_rows` (111–123) first constructs owned decorated sort keys, then sorts, then collects rows. Sidebar has separate order sorts at shell 164, 195–214, 348 and 602–607. Timer boundaries should distinguish key construction from comparison sorting without adding a probe to every comparator call.
7. Full row reads call `redb_transactions::decode_row` (238–251), which deserializes an application row, validates cells and reconstructs its key. This is a combined decode/validation boundary. It is not the same operation as decoding compact metadata or parsing its payload string.

## Approved extension: fourteen static metrics

Keep the existing seventeen metrics and the thirteen initially proposed metrics. The source review additionally requested `digest_hex` nested inside `canonical_digest`, for thirty-one total. Every value is aggregated into the existing request ordinal; no per-call events, table names, keys, IDs, JSON values or hashes are logged.

| New metric | Exact boundary | Counts/lengths | Interpretation |
| --- | --- | --- | --- |
| `index_witness_decode` | Only `decode::<IndexRow>(&bytes)` in window-index equal_metadata and read-index visit_equal_rows (window-index 441; read-index 499) | Calls, encoded input byte length, successful output rows | Structure decoding and its normal allocations; integrity predicates remain outside. |
| `compact_metadata_decode` | Only `decode::<Metadata>(&bytes)` at window-index 454 and 489 | Calls, encoded input bytes, successful output rows | Compact row structure decoding, distinct from later payload parsing. |
| `canonical_row_decode_validate` | Existing decode_row body after the get has returned (transactions 238–251) | Calls, encoded row bytes, successful rows | Combined row deserialization/cell/key validation; contains a nested lookup-key/digest span. |
| `lookup_key_build` | Window-index key (15–20), read-index index_key (115–119), and transactions row_key (215–220) | Calls and existing output key length only | Includes JSON argument construction and prefix/hex formatting, with nested canonical_digest. Do not instrument index_prefix as the same parent and double-count it. |
| `canonical_digest` | Whole request_digest body (storage lib 303–310); no recursive hash_json probes | Calls; no extra byte traversal | Canonical JSON serialization, hashing and digest formatting together. Input byte volume is unobserved. |
| `digest_hex` | Only the existing hash.finalize().iter().map(format hex).collect() expression inside request_digest | Calls, fixed 32-byte digest input and existing output string length | SHA-256 finalization plus the unchanged hex rendering expression, nested in canonical_digest. It is not an allocator-only timer. |
| `payload_json_parse` | Actual serde_json parse in shell Meta::from_index and records payload; also shell's selected-session payload parse at 624 | Calls and the already borrowed input string length | Timer starts after text extraction. Preserve the original temporary lifetime by wrapping only the existing parse call; do not retain an additional owned string. |
| `owned_text_copy` | Only the existing successful str::to_owned in application_rows text | Calls and existing string byte length | Copy/allocation body, excluding validation and later destruction. Nullable is not separately instrumented, avoiding duplicate counts. |
| `indexed_row_clone` | Only the existing row-map clone in window cloned (65–70) | Calls and O(1) map entry count | Copy body; do not walk or reserialize the map to estimate bytes. This does not claim to count every Value/String clone. |
| `sort_key_build` | Existing decorated-key collection in window sort_rows; existing ordinal validation loop in shell sort_runs | Input/output row counts | Key extraction/validation/collection, with nested owned_text_copy. Keep the original evaluation and error order. |
| `sort_compare` | Existing sort_by / sort_by_key statements on the traced window and shell paths | Input row count | One span per complete sort, never one per comparator; excludes decorated key construction. |
| `window_eligibility` | Existing eligible-item loop in retained (198–304) | Initial items, resulting eligible rows | Inclusive selection phase, containing node awaits, metadata decode, text copies and row clones. Not pure predicate CPU. |
| `window_selection` | Existing post-eligibility selection section in retained (305–550) | Eligible input and final retained output counts using existing lengths | Inclusive anchors/grouping/filtering/ordering phase; contains parse/copy/sort children. Deferred groups remain in the existing returned result rather than being encoded in byte counters. No behavior or range scan is skipped. |
| `shell_thread_assembly` | Whole existing shell_thread call (572 onward) | One input thread and one successful output row | Inclusive per-thread assembly, containing relationship reads, metadata/payload work, sorts and canonical row reads. |

If a metric has no cheap existing byte length, mark its byte scope as unobserved in the diagnostic schema/report. Do not interpret the existing numeric zero fields as zero bytes copied or allocated. Counters describe calls/bytes processed, never physical engine operations, unique rows, heap allocation or retained memory.

Canonical row decode/validation remains combined in this first extension to avoid another broad refactor. If it dominates, a later separately reviewed diagnostic can split its existing serde call from validation. The first pass should answer whether that further detail is useful.

## Nesting and presentation

Retain the existing API marker → helper request → evaluate mapping. Show parent phases and leaf spans separately:

- shell_thread_assembly includes backend, compact decode, payload parse, copies, sorts and full row work.
- window_eligibility includes node reads plus compact decode/copies/clones; window_selection includes payload/copy/sort work.
- canonical_row_decode_validate includes lookup_key_build; lookup_key_build includes canonical_digest.
- canonical_digest includes digest_hex. The source constructs 32 temporary formatted Strings per digest, but allocator calls and their causal cost have not been measured. For 4,500 relationship witnesses, the three-digest path predicts 13,500 digest calls and 432,000 formatted String constructions before additional point/row checks; this is a conditional source count, not a runtime allocation claim.
- payload parsing starts after owned_text_copy; that copy is a sibling for this expression.
- sort_key_build includes owned_text_copy; sort_compare starts after key building ends.

Do not sum these nested totals or subtract all of them from evaluate to calculate a residual. Do not call unassigned time JSON or CPU. Report every API's per-request counts/time/byte scope, including zeros and errors, and keep cold, warmup and measured phases separate. The read profile remains a diagnostic, not a qualification or speed comparison.

## Overhead, storage and failure limits

Reuse the existing observer's checked additions, active/late-span checks, serial request attribution and shutdown-only private output. Keep 2,048 request rows, the 8 MiB output cap including its newline, private 0600 files in owned 0700 directories, strict close witness, and the existing bounded owned-worker cleanup. The helper transport and stderr stay unchanged. Overflow, incomplete spans, missing output, late work or lifecycle mismatch reject the diagnostic; never truncate it into a successful profile.

Thirty-one metrics use 3,047,424 bytes of logical Counts slots at the maximum row count (2,048 × 31 × six u64 fields), before row/vector/allocator/JSON overhead. This is a design bound, not a measured RSS or heap claim. There are no per-call record allocations or unbounded distinct-key caches. The unchanged serialization cap can reject an output whose total representation exceeds it.

High-frequency timers add Instant reads, atomics, fixed counter updates and the existing mutex aggregation. The key/metadata/text paths may execute thousands of times per hot request, so their overhead could be material; no small-overhead percentage is assumed. No extra full-value serialization, recursive byte counting, stack capture or comparison-level probe is proposed. Enabled and disabled probes use the same instrumented executable. Disabling them still leaves compiled observer branches, so that control is not an uninstrumented production baseline.

## Proposed bounded procedure, only after approval

1. Preserve observer v2 and its completed raw result unchanged. Add the new probes only in the private profiling worktree or a separate exact copy; retain the full new patch and source hashes. Driver changes are limited to the exact static metric allowlist, byte-scope definitions and report presentation. Seed/setup/prepare/validation/timing functions, fixture, service graph and all original constants must remain byte-identical.
2. Obtain source/diff review before one separately targeted Lustr release build. Record the actual coordinator command, source/compiler/runtime/helper identities and all failures. Do not overwrite any qualifying helper or the earlier diagnostic binary.
3. Keep the same frozen runtime and source aliases, overlay fixture location, three excluded warmups and twelve measured cycles. Run unchanged stock/native correctness plus rollback/reopen with observers unconfigured, then one probes-disabled and one probes-enabled native worker with all five fixed APIs. Use the existing four-worker private driver; do not manufacture an eight-pair qualification report.
4. Preserve exact off/on order, distributions, all leaf/parent counts, GC/RSS/host/filesystem observations, closure evidence and source/helper rechecks. The fixed-order, one-worker comparison provides a descriptive probe-overhead indication only. If the probes visibly perturb distributions or evidence becomes incomplete, retain that attempt and consider a coarser reviewed observer before further execution; never tune the performance gate.
5. Choose a production experiment only after the new measured boundary data and correctness constraints agree. The current search/history CI outcomes have priority; no new local build or profile is authorized by this proposal.

## Source fingerprints read before the approved private extension

- `crates/storage/src/diagnostic_profile.rs`: `07a58262a107deabaaf28049a737b07dcd619beb79498cfcc65872e902fb2be9` (12467 bytes).
- `crates/storage/src/lib.rs`: `462033ddc9a43458068a8ecdbae7ed15dc8bcb6043aa8a5a9182d982c3b98d64` (34890 bytes).
- `apps/server/src/persistence/redb_projection_window_index.rs`: `69a9e754b3ae2d629c5149c528e58087910ddb8a58e9df441750bcdf6fa02d2b` (21775 bytes).
- `apps/server/src/persistence/redb_projection_read_index.rs`: `e292ffe909d711d863055c9a7294229651228bc09f93ba0d22b9967d2c0c1a24` (33744 bytes).
- `apps/server/src/persistence/redb_projection_records.rs`: `558750eb4c44bbb6f6a24e2e1a03b027c11dc5fa06c56f46e359bf2325b2e4af` (34375 bytes).
- `apps/server/src/persistence/redb_projection_window.rs`: `401718dd80dacdd390a1e25d9464ebafe4754350b7c27d182c8f9d54e0f441af` (49527 bytes).
- `apps/server/src/persistence/redb_projection_shell.rs`: `6ffce097dc64c52294907135bbcdcd3985cfec3bb59c8f149a0f43bb2252ed11` (50709 bytes).
- `apps/server/src/persistence/redb_application_rows.rs`: `907da987018beadc97c75acc171747e660481e9814976ebcf39cbe5c5388e975` (4472 bytes).
- `apps/server/src/persistence/redb_transactions.rs`: `3d66b58ad52fb39a67e150a9390329b3f40b87eedd20bb20b7c21f1d13d2d270` (24242 bytes).

These fingerprints bind the v2 source trace. The approved extension is confined to the private profiling copy; its separate full and incremental v3 diffs and source manifest will bind the reviewed changes. The earlier v2 patch, result, source snapshot and binary remain retained. No build or measurement is authorized before that source review.
