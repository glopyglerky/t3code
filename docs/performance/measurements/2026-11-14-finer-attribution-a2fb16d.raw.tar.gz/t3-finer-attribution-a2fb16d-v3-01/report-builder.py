from pathlib import Path
import hashlib
import json

scratch = Path('/workspace/scratch/fcf5fdf8376a')
documentation = scratch / 't3-finer-profile-docs'
report_path = scratch / 't3-persistence-profile-v3-01/profile.json'
report = json.loads(report_path.read_text())
base = json.loads((scratch / 't3-profile-attribution-v3-01.json').read_text())
finer = json.loads((scratch / 't3-profile-finer-attribution-v3-01.json').read_text())
supervisor = json.loads((scratch / 't3-persistence-profile-v3-01.supervisor.json').read_text())
destination = documentation / 'docs/performance/measurements/2026-11-14-finer-attribution-a2fb16d.md'
archive = destination.with_suffix('.raw.tar.gz')
assert not destination.exists() and archive.exists()
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert digest(report_path) == 'fb27430b6aa656419ba4c6cde25ce3831779762923c41a6b6f83fc8bd76a334e'
assert report['status'] == 'completed-diagnostic' and report['qualifies'] is False
assert len(finer['workloads']) == 5 and all(len(w['metrics']) == 31 for w in finer['workloads'])
lines = []
def prose(text):
    lines.extend(text.strip().splitlines()); lines.append('')
def table(headers, rows, numeric=()):
    lines.append('| ' + ' | '.join(headers) + ' |')
    lines.append('| ' + ' | '.join('---:' if i in numeric else '---' for i in range(len(headers))) + ' |')
    lines.extend('| ' + ' | '.join(str(v) for v in row) + ' |' for row in rows); lines.append('')
def metric(workload, name):
    return next(m for m in workload['metrics'] if m['kind'] == name)
def number(value):
    return f'{value:,.3f}'

prose('''# Finer persistence attribution at a2fb16d, v3

**The diagnostic completed. It establishes no stock-performance qualification
or causal optimization gain.** Both stock/native correctness workers passed,
followed by one native probes-disabled worker and one probes-enabled worker.
The named spans locate substantial observed time in compact metadata decoding
and the existing digest finalization/hex expression. Copies and sorting are
smaller measured regions in this fixture. These findings justify bounded source
experiments; they do not predict the gain those experiments will achieve.

The [complete raw archive](2026-11-14-finer-attribution-a2fb16d.raw.tar.gz)
retains full v2/v3 patches, the incremental diff, source/build identities,
both v3 static preflights, all four raw workers, every helper/client profile,
failed derived-analysis draft and complete validated aggregates. The
[previous v2 diagnostic](2026-11-14-attribution-a2fb16d.md) remains unchanged.
The fixed eight-pair stock/native qualification workload and thresholds also
remain unchanged. Existing main has not advanced on this evidence.

## Observed regions and next hypotheses

The table uses the probes-enabled worker's twelve complete measured API calls.
Every duration is inclusive wall time; the columns overlap and must not be added.
`canonical_digest` contains `digest_hex`, key construction contains digests, and
selection/assembly contain reads, decoding, copies and sorting. `digest_hex`
includes SHA-256 finalization and the unchanged hex rendering expression.
''')
table(['API', 'API mean ms', 'Helper evaluate ms', 'Compact decode ms', 'Key build ms', 'Digest ms', 'Nested hex ms', 'Digest calls/API'], [
    [w['id'], number(w['api_ms']['mean']), number(metric(w,'evaluate')['elapsed_ms']['mean']),
     number(metric(w,'compact_metadata_decode')['elapsed_ms']['mean']), number(metric(w,'lookup_key_build')['elapsed_ms']['mean']),
     number(metric(w,'canonical_digest')['elapsed_ms']['mean']), number(metric(w,'digest_hex')['elapsed_ms']['mean']),
     f"{metric(w,'canonical_digest')['counters']['calls']['distribution']['mean']:,.0f}"] for w in finer['workloads']], range(1,8))
prose('''The source and measurements support this priority order:

1. **Test an exact-output hex encoder independently.** The observed hex span
   averages 30.601 ms/sidebar API and 22.034 ms/history API. Source inspection
   shows the existing expression calls `format!("{byte:02x}")` for each of 32
   digest bytes, then collects the strings. At the observed 20,587 and 15,169
   digest calls per API, that implies 658,784 and 485,408 executions of the
   formatting expression. This is a source-derived execution count, not an
   observed allocation count. A replacement must retain every output byte and
   existing key/digest compatibility. This diagnostic contains no such change.
2. **Investigate bounded immutable-session metadata reuse.** Compact decoding
   averages 33.714 ms/sidebar and 42.027 ms/history, with 5,890 and 6,042 decode
   calls and 6,020,160 and 6,325,407 input bytes per API. Repeated bytes may
   describe the same rows, but the observer records no keys, so row identity
   and safe reuse require a separate source audit. All witness scans, ordering,
   discovery/corruption checks, snapshot semantics and writer observations
   must be preserved. No broad cache or disk-format change is justified here.
3. **Keep key construction visible without double-counting its children.**
   Its 42.660 ms/sidebar and 34.451 ms/history spans include digest work and
   other key assembly. Subtracting overlapping aggregate timers does not
   isolate a causal canonical-JSON, allocator or CPU cost.
4. **Defer broader clone/sort refactoring.** History has 1,510 observed row-clone
   calls averaging 3.163 ms/API, 22 instrumented sorts averaging 0.178 ms,
   and 3,032 selected payload parses averaging 1.055 ms. The source sites are
   real costs, but their measured scope is smaller than compact decoding and
   the nested digest expression. Payload parsing is distinct from the compact
   metadata decoder; neither counter measures every parse in the application.

The history eligibility span averages 25.777 ms and selection 15.103 ms; sidebar
thread assembly averages 99.766 ms across 224 rows. Those parent spans contain
the child work above. They do not expose a new disjoint cost of those sizes.
The earlier search observation remains relevant: message search executes 6,398
instrumented scans/API, but this diagnostic has no seek-reuse production patch.

Observed facts are named calls, lengths and wall intervals. The source-derived
explanations above identify candidates, not proven causes or guaranteed savings.
Raw-reader wrapper time, helper evaluation and client wait must not be combined
to label an unmeasured residual as JSON, physical I/O, CPU or pure IPC.

## Exact scope and preparation

The fixed source is `a2fb16d84f089e2a7ca681e431e6acff083695bf`, tree
`9aca39040e56c362ed1edba9e69d49602b5feee8`, against stock correctness oracle
`5fe2f7e4567d9e530ded0dabc9d706db27d77b84`. The v3 patch changes only private
observation boundaries and diagnostic metadata. All original algorithms,
source queries, validation/error order, transaction/close semantics and
durability remain unchanged. The hex expression was deliberately preserved.

The driver checks six byte-identical sections against the original runner and
worker before executing: supervision, seed, canonicalization, fixture setup,
selected services and operations/correctness. Their hashes and original source
are retained. All fifteen observer source hashes and the complete v2-to-v3
diff were independently reviewed before a fresh release build.

The build used the pinned produced BlueFe compiler through the actual Lustr
coordinator, with one CPU/job, unchanged optimized settings, a fresh private
target/output and no compiler flag override. It completed in 260.338 seconds.
All 161 source/build inputs and six observed tool hashes stayed unchanged.
The v2 helper, target, source snapshot and result remain preserved. This receipt
is `manifest-reported` local diagnostic evidence, not a `verified-ci-manifest`
qualification. Observed compiler identity stays null; expected policy identity
is recorded separately.

The first v3 static preflight failed before any application worker ran. Its
complete 440-descriptor frozen dependency graph passed, but an added historical
alias loop expected a root workspace link removed during the earlier approved
clean-root normalization. The failed script/receipt is retained. The corrected
script hash-binds both historical receipts, requires all 69 removed root links
absent using `lstat` (including dangling links), and verifies the remaining 170
workspace aliases against exact private-source targets. The second preflight
passed without any package, alias, source or workload mutation. Both temporary
stock exports were removed.

Frozen pnpm 12.14.0, Node 26.12.1, per-workspace resolution, the installed lock
and all 440 external descriptors passed with no issues. The optional root Cursor
platform package remains included. The full stock export has its own workspace
aliases; it does not import live fork-relative source. The dependency-resolution
tuple hash is unchanged from v2.

## Workload and correctness

The fixture retained 256 normal threads, one archived write thread, 3,000 search
messages, a completed 1,500-item history run and 1,024-byte reasoning payloads.
Setup, export, migration, index preparation and file hashing stay outside the
API timers. Both correctness workers leave observers unconfigured, preserving
the deliberate rollback/discard lifecycle. The measurement workers still require
strict successful-close profiles from every non-owner helper connection.

Data and array order, same-transaction readback, the exact deliberate rollback
sentinel, restored state and committed reopen passed. Every cold, warmup and
measured result matched its validated result, including changing visit timestamps.
Nonempty witnesses were 224 active threads, three retained history items, one run,
one node, 13,976 history JSON bytes, and 20 results from each search.

Stock SQLite retained WAL/NORMAL and native omdb retained Immediate durability.
Logical fixture lengths were 7,168,000 SQLite bytes and 272,896,000 native bytes;
those are not allocated disk bytes, memory usage or storage traffic. Rollback
and reopen checks establish no power-loss, other-platform or real-provider proof.

## Every probes-off/on observation

The same instrumented release helper ran with probes disabled first and enabled
second, one process per condition, three excluded warmups and twelve measured
cycles. **V3 explicitly used CPU affinity `[0]`; v2 used nine available CPUs.**
Cross-version timing differences cannot isolate observer or algorithm effects.
Even within v3, fixed order, one process and host variation prevent a causal
overhead estimate. The disabled helper still contains the compiled probes.

Times are milliseconds. Cold has one observation per condition; its identical
median, p95 and worst are not independent samples or a tail estimate. Every
observed positive and negative change is retained below, without a significance
or speedup claim.
''')
table(['Workload','Off median','Off p95','Off worst','On median','On p95','On worst'], [
    [x['id']] + [number(x[k][s]) for k in ['disabled','enabled'] for s in ['median_ms','p95_ms','worst_ms']]
    for x in base['off_on']], range(1,7))
table(['Workload','Median change','p95 change','Worst change'], [
    [x['id']] + [f"{x['signed_latency_change_percent'][s]:+.2f}%" for s in ['median_ms','p95_ms','worst_ms']]
    for x in base['off_on']], range(1,4))
prose('''The mixed tail directions are material: enabled sidebar worst is 355.419 ms,
while disabled history worst is 296.369 ms and enabled message-search worst is
162.159 ms. Neither condition is uniformly faster. No tail was censored or
retried. These single-worker observations cannot be used to calibrate away a
qualification regression or select only favorable probe costs.

## Cold/open attribution

The enabled service-open marker lasted 295.578 ms. The primary helper's outside-
request store-open span was 168.445 ms, containing backend-open 168.184 ms and
checked-open 168.057 ms. These nested spans are not three independent durations.
The separate read-only startup helper's store-open span was 0.452 ms. Their
complete process lifetimes include waiting and must not be treated as open time.

The enabled cold phases are retained below. Each is a single observation.
Module loading and fixture work remain outside the reported cold API sum;
neither OS page cache nor storage device state is claimed cold.
''')
cold_markers = [m for m in base['api_markers'] if m['phase'] in ['open','cold']]
table(['Phase/API','Marker ms','Helper requests','Helper wall ms','Client total ms'], [
    [m['phase']+':'+m['api'],number(m['elapsed_ms']),base['phase_aggregates'][m['phase']+':'+m['api']]['requests'],
     number(base['phase_aggregates'][m['phase']+':'+m['api']]['native_request_wall_ms']),
     number(base['phase_aggregates'][m['phase']+':'+m['api']]['client_timing_ms']['total_ms'])] for m in cold_markers], range(1,5))
prose('''## All 31 metric scopes, every measured workload

Each row aggregates all helper requests belonging to one complete API marker,
then summarizes its twelve measured observations. Time columns are inclusive
milliseconds. Calls and byte columns are means per API. All count/unit/byte
raw values, sums, means, medians, p95 and worst values are retained in
`analysis/all-scopes.json`; every request and phase remains in `analysis/attribution.json`.

`—` means that a unit/byte field is unobserved, with a null distribution in the
derived data. It does not mean zero bytes or allocations. A row with zero calls
means that this named probe did not execute in that workload; it does not measure
uninstrumented paths elsewhere. Counter bytes are argument/return lengths at
the indicated boundary, not total copying, heap size, disk traffic or allocations.
''')
for w in finer['workloads']:
    prose('### '+w['id'])
    rows=[]
    for m in w['metrics']:
        def byte_mean(field):
            value=m['counters'][field]['distribution']
            return '—' if value is None else f"{value['mean']:,.0f}"
        rows.append([f"`{m['kind']}`",f"{m['counters']['calls']['distribution']['mean']:,.0f}",
                     *[number(m['elapsed_ms'][x]) for x in ['mean','median','p95','worst']],
                     byte_mean('input_bytes'),byte_mean('output_bytes')])
    table(['Metric','Calls/API','Mean ms','Median ms','p95 ms','Worst ms','Input bytes/API','Output bytes/API'],rows,range(1,8))
prose('### Static unit and byte definitions')
table(['Metric','Input / output units','Input / output byte scope'], [
    [f"`{s['kind']}`",s['input_units']+' / '+s['output_units'],s['input_bytes']+' / '+s['output_bytes']]
    for s in report['native_metric_scopes']])
prose('''`get` includes cached writer observations; `get_many` counts returned slots,
including missing values, while its bytes count only present values. `begin_snapshot`
covers its named wrapper, not every engine snapshot. `sort_compare` covers a
whole instrumented sort, including its comparator/key closure; it is not a
per-comparison counter. `canonical_row_decode_validate` includes row validation
and key checking; it is broader than serde parsing alone. The digest input-byte
field is unobserved; only the nested hex span uses the fixed 32-byte digest length.

## Raw verification, limits and retained failures

Independent reconstruction matched all four worker JSONs to the report, six
observer files to their hashes, 574 client/helper requests by ordinal, static
operation kind, input frame length and success, all 81 finished markers and
17 phase groups. All 31 scope definitions, exact counter fields, safe integer
bounds, digest/hex call equality and 32/64-byte hex input/output relationships
were checked. Every emitted helper proved actual store closure, zero active
spans and no incompleteness. Disabled profiles retain null request/marker data
rather than invented measurements. The owner-lock connection intentionally has
no helper profile, as recorded in the unchanged protocol.

The first all-scope metadata analyzer incorrectly tried to take the length of
disabled `markers: null`; it failed before producing derived data. Its source
and failure note remain in the archive. The corrected analyzer explicitly
requires null for disabled markers and validates the enabled marker list. This
did not alter any raw evidence, measured source, workload or application run.

All observer labels are static. Probes retain no keys, payloads, identifiers,
headers, network responses or user state. Helper output is limited to 2,048
request rows and 8 MiB including its newline; client output retains the existing
32-connection, 2,048-request-per-connection and 256-marker limits. Checked counter
overflow or late/unclosed work makes a profile incomplete. Observer output is
private and emitted after proven successful closure, with transport unchanged.
At maximum row count, 31 logical counter arrays occupy 3,047,424 bytes before
container overhead; that calculation is not measured RSS. High-frequency timers
add clock reads, atomics and aggregation; their overhead is not assumed small.

The owned supervisor completed in 60.059 seconds with exit 0, unchanged source
and helper, empty fixture directory and no remaining compiler/helper process.
It retained bounded logs, timeout and owned-process cleanup. There was exactly
one v3 application diagnostic; no result-driven rerun occurred.

## Host, filesystem and advisory memory

The host reported Intel Xeon Platinum 8573C, Linux 6.18.57, one available CPU
under the explicit affinity and 10,451,423,232 memory bytes. Load averages changed
from `[1.30, 1.25, 1.26]` to `[1.99, 1.46, 1.33]`. Supervisor preflight found
no active compiler/helper process and 4,432,856 KiB available memory. These are
context observations, not an attribution of tails to memory or scheduling.

Fixtures used the task-owned overlayfs directory, not `/tmp` tmpfs. The observer
reported type `0x794c7630` and 4,096-byte block/fragment sizes. Volume-wide block
counts below are neither fixture allocation nor a physical-device or durability
guarantee. They were sampled outside timed operations.
''')
table(['Observation','Available blocks','Bytes at reported block size'],[
    [k,f"{int(v['available_blocks']):,}",f"{int(v['available_blocks'])*int(v['block_size_bytes']):,}"]
    for k,v in report['host']['fixture_filesystem'].items()], [1,2])
memory_rows=[]
for run in report['runs']:
    if run['purpose'] != 'measurement': continue
    memory_rows.append(['on' if run['native_probes_enabled'] else 'off',
        'Unavailable' if run['process_tree_peak_rss_kib'] is None else run['process_tree_peak_rss_kib'],
        run['node_peak_rss_kib'], run['gc']['count'], number(run['gc']['duration_ms'])])
table(['Probes','Sampled process-tree peak KiB','Node-only peak KiB','GC count','GC duration ms'],memory_rows,range(1,5))
prose('''Process-tree RSS is unavailable in both workers: the sampler recorded
`Process or descendant enumeration unavailable (ENOENT)`, with zero valid samples
in 398 probes-off and 407 probes-on attempts. The retained peak is null, never
zero memory or a Node-only substitute. No process-tree memory comparison is made.
Node-only high-water data remains separately measured and excludes helper children.

When available, the 25 ms process-tree sampler can miss short peaks and double-count
shared pages. No forced collection
was used. RSS is advisory, not heap size, allocation accounting, whole-app memory
qualification or memory safety. Raw GC/RSS fields remain unchanged in each worker.

## Exact evidence identity
''')
identity=[
 ('Base commit',report['source_commit']),('Base tree',report['source_tree']),('Stock oracle',report['upstream_commit']),
 ('Full v3 patch SHA-256',report['observer_patch_sha256']),
 ('Incremental v2-to-v3 SHA-256',digest(scratch/'t3-persistence-profile-a2fb16d-v2-to-v3.patch')),
 ('Source-review manifest SHA-256',digest(scratch/'t3-persistence-profile-a2fb16d-source-v3.json')),
 ('Helper SHA-256',report['executable_sha256']),('Build receipt SHA-256',report['native_manifest_sha256']),
 ('Build log SHA-256',digest(scratch/'t3-profile-helper-a2fb16d-v3-build-01/build.log')),
 ('Failed static preflight01 SHA-256',digest(scratch/'t3-profile-runtime-static-a2fb16d-v3-01/runtime.json')),
 ('Passed static preflight02 SHA-256',digest(scratch/'t3-profile-runtime-static-a2fb16d-v3-02/runtime.json')),
 ('External resolution SHA-256',report['baseline']['runtime_provenance']['external_resolution_sha256']),
 ('Original report SHA-256',digest(report_path)),('Supervisor SHA-256',digest(scratch/'t3-persistence-profile-v3-01.supervisor.json')),
 ('Per-request attribution SHA-256',digest(scratch/'t3-profile-attribution-v3-01.json')),
 ('All-scope attribution SHA-256',digest(scratch/'t3-profile-finer-attribution-v3-01.json')),
 ('Raw archive SHA-256',digest(archive)),('Private worker SHA-256',report['extraction']['private_worker_sha256']),
 ('Toolchain lock SHA-256',report['toolchain_lock_sha256']),
]
table(['Evidence','Identity'],[[k,f'`{v}`'] for k,v in identity])
prose('''The exact invocation was:

```text
''');lines.pop();lines.append(' '.join(report['command']));lines.extend(['```',''])
prose('''The readable report was prepared in a separate documentation worktree based
on `4b5719f34a8b76a23f3c77982940cea67234186c`. That integration source and its
later sidebar corrections did not enter this fixed a2fb diagnostic. The archive
binds the actual measured bytes and actual helper, not the documentation parent.

## Decision

Retain the complete diagnostic and failures. Test the exact-output digest encoder
as a separate bounded change, then audit successful metadata reuse without
weakening witness/error checks or writer observations. The evidence supports
that order because the named decode/digest regions are much larger than the
observed selected clone/sort regions. No production change, promised gain or
threshold adjustment follows automatically from these timings. Required source,
native, adapter, full controlled app and unchanged stock-performance gates still
decide whether a later candidate can advance.
''')
destination.write_text('\n'.join(lines))
print(json.dumps({'path':str(destination),'sha256':digest(destination),'bytes':destination.stat().st_size},indent=2))
