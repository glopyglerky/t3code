# Finer persistence attribution evidence, v3

This archive is one completed diagnostic, never a qualification or stock-speed
result. run/profile.json is retained byte-for-byte. Both unconfigured correctness
workers and one native probes-disabled then one probes-enabled worker passed.
Each measured worker used three excluded warmups and twelve cycles. V3 uses one
CPU, whereas the prior v2 diagnostic used nine. Separate attempts cannot isolate
observer or algorithm speed effects; the fixed-order off/on pair is descriptive.

source/ contains the reviewed v2 baseline patch and v3 full/incremental patches,
source identities, parser checks, proposal and unchanged six-section proof.
All 31 labels and unit/byte scopes are static. The exact digest finalization and
format!(hex) algorithm remains unchanged. No production optimization is included.

build/ records the actual pinned Lustr coordinator invocation, selected environment,
six tool hashes, 161 source inputs, full log, separate optimized helper hash and
source stability. The executable is not embedded. Its local build receipt is
manifest-reported diagnostic provenance, not an independent CI qualification.

runtime/ retains both static v3 attempts, including the first failed alias check.
The full frozen 440-descriptor graph passed, but an added historical-alias loop
expected a root link removed by the already-approved normalization. The second
script binds both historical receipts, requires all 69 removed root links absent
using lstat, and checks the remaining 170 workspace aliases exactly. No aliases,
packages, workload or fixed source changed; no application worker ran in either
static attempt. Both stock exports were removed after verification.

run/ retains all four raw workers, every config/output, both complete client/helper
profile sets, supervisor source/receipt/logs, byte scopes, host/filesystem facts,
helper/source hashes and cleanup witnesses. Correctness uses only the controlled
synthetic fixture. The observer itself records no keys, identifiers or payloads.

analysis/ independently validates every raw file hash, closure, cap, request
ordinal/kind/frame/success and metric scope. It retains all 574 joined requests,
81 markers, 17 phase groups and 155 workload-by-metric rows. Every measured row
has twelve whole-API observations with raw values, means, medians, p95 and worst.
Unobserved unit/byte distributions are null, never measured zero. The first
metadata-only analyzer's null-marker mistake and corrected source are retained.

Every duration is an inclusive wall observation. Parent/child spans overlap;
no sum or residual is a CPU, allocator, JSON or physical-I/O total. In particular
canonical_digest includes digest_hex, which includes SHA-256 finalization and
unchanged hex rendering. Unit and byte counters cover named wrapper boundaries,
not memory allocations or storage traffic. All historical failures are retained.

This archive contains regular files only: no database, helper executable, target,
node_modules, user state, credentials or real-provider outputs. SHA256SUMS.json
indexes every other entry. Paths bind the original owned environment; reproduction
elsewhere needs path remapping while preserving source and workload semantics.
