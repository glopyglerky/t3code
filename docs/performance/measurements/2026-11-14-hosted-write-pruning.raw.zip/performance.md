# Persistence performance comparison

Status: **regressed**. Mode: qualify. Attempt: 2026-11-14T14-27-13.795Z-4d593cd9.

Fork commit: `d661dbb2bf693b88c8969fcda9a0f5b98e3a2cca`. Tree: `549bff502c033739693b562a854437c0292a5019`. Dirty: false.
Pinned upstream: `913d7fc45ec5814fff25c819cfe4de193ea42d63`. Tree: `95faedbd2644d046dac476ef9dcab2eb38a7eb97`.
Compiler route: bluefe-rustc-via-lustr. Build profile: release.
Compiler revision: `1b74388e196ee8813f38ba9eeb6d4ab43b6b1071`. Coordinator: `07470b20464bf097c3c88983124aff56c5e44f9a`.
Executable SHA-256: `9a084d4a821fcfe0e729e72f757c1a15762ca2a2b9c86c440632841318be5cc3`. Toolchain lock: `2cddf6970e38ab122d6d62e4543cfb3d1fd23876d4a813a4b4421babc033d1bf`.
Manifest SHA-256: `0da1f24735bfc2351cc1bc4283ad20b08f7620ccea548a49203d7cca73f695da`. Policy: `012e41ab98ad7322663f9c93b279b66064bba383464e26410eb42d9895d8424c`.

## Results

| Scenario | Phase | Upstream median / p95 / worst ms | Native median / p95 / worst ms | Paired native/upstream ratio | Latency change | 95% interval | Decision |
|---|---|---:|---:|---:|---:|---|---|
| service-open-and-first-operations | cold | 130.033 / 135.204 / 135.254 | 724.114 / 873.574 / 873.946 | 5.763 | +476.263% | 5.359–6.257 | regressed |
| sidebar-shell | warm | 10.678 / 12.348 / 14.014 | 155.119 / 169.259 / 184.529 | 14.606 | +1360.620% | 14.198–15.045 | regressed |
| sidebar-shell.p95 | warm | 10.678 / 12.348 / 14.014 | 155.119 / 169.259 / 184.529 | 13.654 | +1265.389% | 13.037–14.250 | regressed |
| history-window | warm | 24.975 / 26.783 / 27.955 | 127.377 / 141.644 / 150.502 | 5.143 | +414.276% | 5.020–5.277 | regressed |
| history-window.p95 | warm | 24.975 / 26.783 / 27.955 | 127.377 / 141.644 / 150.502 | 5.226 | +422.593% | 5.040–5.433 | regressed |
| message-search | warm | 5.590 / 6.218 / 9.644 | 36.198 / 38.943 / 44.564 | 6.480 | +547.957% | 6.311–6.644 | regressed |
| message-search.p95 | warm | 5.590 / 6.218 / 9.644 | 36.198 / 38.943 / 44.564 | 6.111 | +511.068% | 5.396–6.633 | regressed |
| accent-search | warm | 3.851 / 4.525 / 6.309 | 31.291 / 34.952 / 41.292 | 8.259 | +725.903% | 8.046–8.461 | regressed |
| accent-search.p95 | warm | 3.851 / 4.525 / 6.309 | 31.291 / 34.952 / 41.292 | 7.521 | +652.085% | 6.959–8.132 | regressed |
| visit-commit | warm | 1.147 / 1.577 / 61.750 | 6.651 / 191.083 / 355.931 | 10.735 | +973.503% | 5.754–21.221 | regressed |
| visit-commit.p95 | warm | 1.147 / 1.577 / 61.750 | 6.651 / 191.083 / 355.931 | 38.435 | +3743.474% | 17.489–82.700 | regressed |

Negative latency change means faster; positive means slower for the named workload and statistic only.

## Reasons and divergences

- service-open-and-first-operations: The whole 95% paired ratio interval is above 1.0: a measured slowdown blocks qualification. The relative interval width exceeds 10%; investigate runner noise.
- sidebar-shell: The whole 95% paired ratio interval is above 1.0: a measured slowdown blocks qualification.
- sidebar-shell.p95: The whole 95% paired ratio interval is above 1.0: a measured slowdown blocks qualification.
- history-window: The whole 95% paired ratio interval is above 1.0: a measured slowdown blocks qualification.
- history-window.p95: The whole 95% paired ratio interval is above 1.0: a measured slowdown blocks qualification.
- message-search: The whole 95% paired ratio interval is above 1.0: a measured slowdown blocks qualification.
- message-search.p95: The whole 95% paired ratio interval is above 1.0: a measured slowdown blocks qualification. The relative interval width exceeds 10%; investigate runner noise.
- accent-search: The whole 95% paired ratio interval is above 1.0: a measured slowdown blocks qualification.
- accent-search.p95: The whole 95% paired ratio interval is above 1.0: a measured slowdown blocks qualification. The relative interval width exceeds 10%; investigate runner noise.
- visit-commit: The whole 95% paired ratio interval is above 1.0: a measured slowdown blocks qualification. The relative interval width exceeds 10%; investigate runner noise.
- visit-commit.p95: The whole 95% paired ratio interval is above 1.0: a measured slowdown blocks qualification. The relative interval width exceeds 10%; investigate runner noise.

Correctness: passed.

- Every initial API result is deeply equal to pinned upstream, including array order.
- Same-transaction visit readback sees the write; rollback restores the prior row exactly.
- Committed visit survives closing and reopening each production persistence service.
- Every warmup and measured response matches the validated immutable result digest.
- SQLite production WAL/NORMAL settings are asserted; native Immediate commits use the unchanged selected production backend.

## Protocol and decisions

- The workloads are fixed before measurements: sidebar-shell, history-window, message-search, accent-search, and visit-commit transaction/readback.
- Every scenario gates independently; a faster scenario cannot offset a slower one.
- Eight balanced, seeded process pairs and all requests are retained. No slow sample is dropped or retried.
- Confidence intervals compare native/upstream latency against exactly 1.0. A 10% interval width is only a noise diagnostic, never a regression allowance.
- Migration, fixture seeding and native index preparation occur before timed workers; process-cold service acquisition and warm API calls are reported separately.
- The write comparison uses actual production settings: stock SQLite WAL/NORMAL and native Immediate. Native commits retain stronger power-loss durability; any associated slowdown remains visible and gates qualification.
- Rollback and committed reopen are required correctness checks; they do not prove power-failure durability.

## Measurement limits

- This measures the production persistence/API boundary, including native IPC and serialization, not complete UI, network, provider or whole-application performance.
- Cold means a fresh Node process and service open. The shared OS page cache is not flushed or claimed cold; backend order is balanced.
- Warm request timings exclude result fingerprinting; native IPC/serialization and upstream worker messaging remain inside the timed operation.
- RSS is a 25 ms sample of the Node process plus its native descendants. It includes shared pages more than once and can miss short peaks; it is advisory and never a heap or memory-safety claim.
- If /proc does not expose a process and its descendants, whole-process RSS is explicitly unavailable (null), never zero or a Node-only substitute.
- V8 GC is observed without forced collections. Node peak RSS excludes child helpers and is separately labeled; the process-tree sample includes them.
- Shared CI load, filesystem caching, CPU frequency and small-sample tail uncertainty remain. Inconclusive evidence cannot establish equivalence or qualify this commit.
- Filesystem observations record the fixture's statfs type and block counts outside timed intervals. A filesystem name does not establish a physical device or power-loss guarantee; comparisons across different media need an explicit limitation.

## Reproduction

```json
{
  "command": [
    "/opt/hostedtoolcache/node/26.12.1/x64/bin/node",
    "/home/runner/work/t3code-ls/t3code-ls/tools/performance-persistence.mjs",
    "--database",
    "/home/runner/work/t3code-ls/t3code-ls/bin/t3-code-ls-db",
    "--manifest",
    "/home/runner/work/t3code-ls/t3code-ls/bin/manifest.json",
    "--plan",
    "/home/runner/work/_temp/performance-plan/ci-plan.json",
    "--output",
    "/home/runner/work/_temp/performance-proof-1",
    "--mode",
    "qualify"
  ],
  "configuration": {
    "pairs": 8,
    "warmups": 3,
    "samples": 12,
    "seed": 1949524847,
    "bootstrap_resamples": 10000,
    "confidence": 0.95,
    "comparison_ratio": 1,
    "fixture": {
      "threads": 256,
      "write_threads": 1,
      "messages": 3000,
      "history_items": 1500,
      "payload_bytes": 1024
    },
    "phase": "all",
    "worker_timeout_ms": 900000,
    "worker_output_limit_bytes": 16777216,
    "worker_shutdown_grace_ms": 2000,
    "rss_sampling_interval_ms": 25
  },
  "host": {
    "platform": "linux",
    "architecture": "x64",
    "release": "7.0.0-1017-azure",
    "cpu_model": "AMD EPYC 9V74 80-Core Processor",
    "cpus": 4,
    "total_memory_bytes": 16760348672,
    "load_before": [
      2.87,
      0.93,
      0.33
    ],
    "node": "v26.12.1",
    "fixture_filesystem": {
      "before_setup": {
        "path": "/tmp/t3-redb-gate-CCIFeQ",
        "observed_at": "2026-11-14T14:27:14.945Z",
        "status": "observed",
        "type_id_hex": "0xef53",
        "type_name": null,
        "block_size_bytes": "4096",
        "fragment_size_bytes": "4096",
        "total_blocks": "37815964",
        "free_blocks": "21078686",
        "available_blocks": "21074590",
        "total_file_nodes": "19529728",
        "free_file_nodes": "18205127",
        "units": "Exact decimal strings from Node statfs; block counts are filesystem blocks."
      },
      "after_workers": {
        "path": "/tmp/t3-redb-gate-CCIFeQ",
        "observed_at": "2026-11-14T14:29:20.671Z",
        "status": "observed",
        "type_id_hex": "0xef53",
        "type_name": null,
        "block_size_bytes": "4096",
        "fragment_size_bytes": "4096",
        "total_blocks": "37815964",
        "free_blocks": "20301714",
        "available_blocks": "20297618",
        "total_file_nodes": "19529728",
        "free_file_nodes": "18167250",
        "units": "Exact decimal strings from Node statfs; block counts are filesystem blocks."
      },
      "after_cleanup": {
        "path": "/tmp",
        "observed_at": "2026-11-14T14:29:23.197Z",
        "status": "observed",
        "type_id_hex": "0xef53",
        "type_name": null,
        "block_size_bytes": "4096",
        "fragment_size_bytes": "4096",
        "total_blocks": "37815964",
        "free_blocks": "21077705",
        "available_blocks": "21073609",
        "total_file_nodes": "19529728",
        "free_file_nodes": "18205056",
        "units": "Exact decimal strings from Node statfs; block counts are filesystem blocks."
      }
    },
    "load_after": [
      1.53,
      1.11,
      0.48
    ]
  },
  "fixture": {
    "sqlite_sha256": "6e2134093f68e66b46532e382034d3e3a6b9702ad78065835c2e4a0de6ceecc2",
    "sqlite_file_bytes": 7168000,
    "export_sha256": "3f6ef9bb0ec13037a1ee663ee26aa40853c897ae0992d14dd20fc19680e21c5a",
    "native_template_sha256": "47f7572e579c61d68c90954985e8d3f7aafe0e8c2a2880de7fb361fb096b5032",
    "native_file_bytes": 272896000,
    "schema_sha256": "395b45dba23c8c59851ff0af055023d7536b0e76059fc613f1b96b6e5244a502",
    "definitions": {
      "threads": 256,
      "write_threads": 1,
      "messages": 3000,
      "history_items": 1500,
      "payload_bytes": 1024
    },
    "seed_sources": [
      {
        "path": "apps/server/src/orchestration-v2/ProjectionStore.ts",
        "sha256": "689a6dbdc96dce2041c7592062cbe2b820814977332ac608d649978ec3afb14a"
      },
      {
        "path": "apps/server/src/orchestration-v2/ProjectStore.ts",
        "sha256": "47d6c62591835ab71600e827b2efde7dc59bac15a3018b5e0e39fb58e8c1bfd2"
      }
    ]
  },
  "baseline": {
    "root": "/tmp/t3-redb-gate-CCIFeQ/upstream",
    "commit": "913d7fc45ec5814fff25c819cfe4de193ea42d63",
    "tree": "95faedbd2644d046dac476ef9dcab2eb38a7eb97",
    "archive_sha256": "dd61ceca8c7aaf1f8d8dd5319a3f45a61835ec5a43391a40919ed71d3684f562",
    "dependency_lock_sha256": "89d1c22024aebd302d81c597dc268ec22309f28214cb70071f88b742ceff4660",
    "fork_dependency_lock_sha256": "a17f5c2cdb04c1a8240a9ad5ca275d4318c262ef596e20a8f67c5d25e3d2a6c4",
    "dependency_comparison": "All settings, patches, package/snapshot resolutions and shared importers match. Only the exact existing tools/oracles importer with workspace links and Effect 4.1.3 is additional.",
    "workspace_packages": [
      "@t3tools/client-runtime",
      "@t3tools/contracts",
      "@t3tools/desktop",
      "@t3tools/marketing",
      "@t3tools/mobile",
      "@t3tools/provider-acp",
      "@t3tools/provider-acp-registry",
      "@t3tools/provider-core",
      "@t3tools/provider-cursor",
      "@t3tools/provider-fx",
      "@t3tools/provider-grok",
      "@t3tools/provider-kiro",
      "@t3tools/provider-muse",
      "@t3tools/provider-opencode",
      "@t3tools/provider-pi",
      "@t3tools/provider-testing",
      "@t3tools/secret-provider-core",
      "@t3tools/secret-provider-definitions",
      "@t3tools/secret-provider-onepassword",
      "@t3tools/shared",
      "@t3tools/source-control-azure-devops",
      "@t3tools/source-control-bitbucket",
      "@t3tools/source-control-core",
      "@t3tools/source-control-cursor-origin",
      "@t3tools/source-control-definitions",
      "@t3tools/source-control-forgejo",
      "@t3tools/source-control-gitcafe",
      "@t3tools/source-control-github",
      "@t3tools/source-control-gitlab",
      "@t3tools/source-control-testing",
      "@t3tools/ssh",
      "@t3tools/tailscale",
      "@t3tools/web",
      "effect-acp",
      "effect-codex-app-server",
      "t3"
    ],
    "external_dependencies": [
      {
        "importer": ".",
        "name": "@coderabbitai/config",
        "version": "1.2.0",
        "package_json_sha256": "54b274a22723034230cc034b7997da2e6b56aa34a7458a6175c2c83acb0b1758",
        "installed_path": "node_modules/.pnpm/@coderabbitai+config@1.2.0/node_modules/@coderabbitai/config"
      },
      {
        "importer": ".",
        "name": "@cursor/sdk-linux-x64",
        "version": "1.2.0",
        "package_json_sha256": "6e5f33caf3e737d95c381ab926ce3e8580aeeecca483b14dfdbd8d94445b15b6",
        "installed_path": "node_modules/.pnpm/@cursor+sdk-linux-x64@1.2.0/node_modules/@cursor/sdk-linux-x64"
      },
      {
        "importer": ".",
        "name": "@effect/platform-node",
        "version": "4.1.2",
        "package_json_sha256": "2901f7c08e6011794c624e346b19f85a6b455338c3991578407c3028bd64800e",
        "installed_path": "node_modules/.pnpm/@effect+platform-node@4.1.2_bufferutil@4.1.0_effect@4.1.3_redis@6.2.1_utf-8-validate@6.0.6/node_modules/@effect/platform-node"
      },
      {
        "importer": ".",
        "name": "@effect/tsgo",
        "version": "0.67.1",
        "package_json_sha256": "59e9fc21d767c96f8cdf7aaa91d0ec886584458c14e4b6700c506dbdc27a83e4",
        "installed_path": "node_modules/.pnpm/@effect+tsgo@0.67.1/node_modules/@effect/tsgo"
      },
      {
        "importer": ".",
        "name": "@shadcn/lint",
        "version": "0.1.5",
        "package_json_sha256": "1f31e9c28a593866ae372ab2c7e41deea5b4bc5ec4b36ca6125895d279c7046c",
        "installed_path": "node_modules/.pnpm/@shadcn+lint@0.1.5/node_modules/@shadcn/lint"
      },
      {
        "importer": ".",
        "name": "@types/node",
        "version": "24.12.4",
        "package_json_sha256": "456b1366f1966515c4dfec48446c82275502a2d5ea7cfbc74874323b39e3776f",
        "installed_path": "node_modules/.pnpm/@types+node@24.12.4/node_modules/@types/node"
      },
      {
        "importer": ".",
        "name": "effect",
        "version": "4.1.3",
        "package_json_sha256": "8ae4c5cf40f75346e2ab4dcacb692a98a6ddd814ecc5ffad27db087d6cfa3a9f",
        "installed_path": "node_modules/.pnpm/effect@4.1.3/node_modules/effect"
      },
      {
        "importer": ".",
        "name": "knip",
        "version": "6.34.0",
        "package_json_sha256": "08577f50907982196befbe1bf60a0c33718034b654e5d437ffae3cbd608f5380",
        "installed_path": "node_modules/.pnpm/knip@6.34.0/node_modules/knip"
      },
      {
        "importer": ".",
        "name": "vite-plus",
        "version": "1.4.0",
        "package_json_sha256": "a2901e42e05a5f1c162b994ba85bfbad074a2f8921d129995b019e0bd48c9c09",
        "installed_path": "node_modules/.pnpm/vite-plus@1.4.0_@astrojs+compiler-rs@0.5.1_@types+node@24.12.4_@vitest+browser-playwrig_71b1ef4e5049c7accee71dd249ba4133/node_modules/vite-plus"
      },
      {
        "importer": ".",
        "name": "yaml",
        "version": "2.9.0",
        "package_json_sha256": "20b8b197cbd10dad245d45e463dfe58e4c8c25a47e24bc4256ad9ab58bf35683",
        "installed_path": "node_modules/.pnpm/yaml@2.9.0/node_modules/yaml"
      },
      {
        "importer": "apps/desktop",
        "name": "@clerk/electron",
        "version": "0.1.10",
        "package_json_sha256": "5907a54345f8cfccadd3c9cfa940049f7c212ff8dfc044c98fc8c4b2a86a378e",
        "installed_path": "node_modules/.pnpm/@clerk+electron@0.1.10_@clerk+electron-passkeys@0.0.3_electron-store@8.2.0_electron@44._0ba958cb374e528e7de7319d5a8ee178/node_modules/@clerk/electron"
      },
      {
        "importer": "apps/desktop",
        "name": "@clerk/electron-passkeys",
        "version": "0.0.3",
        "package_json_sha256": "825072f9be9dd87caf0d8d941ba8f256103ea5239ef28800f28a573a0a14efd6",
        "installed_path": "node_modules/.pnpm/@clerk+electron-passkeys@0.0.3/node_modules/@clerk/electron-passkeys"
      },
      {
        "importer": "apps/desktop",
        "name": "@crowecawcaw/xa11y",
        "version": "0.15.4",
        "package_json_sha256": "4dee463a4b1c6920fa1ba80cc232c719f320252d12d3db0f5940f2c29ede7867",
        "installed_path": "node_modules/.pnpm/@crowecawcaw+xa11y@0.15.4/node_modules/@crowecawcaw/xa11y"
      },
      {
        "importer": "apps/desktop",
        "name": "@effect/platform-node",
        "version": "4.1.2",
        "package_json_sha256": "2901f7c08e6011794c624e346b19f85a6b455338c3991578407c3028bd64800e",
        "installed_path": "node_modules/.pnpm/@effect+platform-node@4.1.2_bufferutil@4.1.0_effect@4.1.3_redis@6.2.1_utf-8-validate@6.0.6/node_modules/@effect/platform-node"
      },
      {
        "importer": "apps/desktop",
        "name": "@effect/vitest",
        "version": "4.1.2",
        "package_json_sha256": "63fe8c287b8aa7420363f515f1d6330cfa5574430af94832dab4447afadcfc71",
        "installed_path": "node_modules/.pnpm/@effect+vitest@4.1.2_patch_hash=299510b71c36537a832a67e9d160a5f112a5f326a29e95c41cb45fc_81d3dd1e682774f4c17d7f713915765f/node_modules/@effect/vitest"
      },
      {
        "importer": "apps/desktop",
        "name": "@napi-rs/keyring",
        "version": "1.3.0",
        "package_json_sha256": "21c83c2e09639253133bd17d9f1832aa46cd9087850cb9d5ede81de1002ad242",
        "installed_path": "node_modules/.pnpm/@napi-rs+keyring@1.3.0/node_modules/@napi-rs/keyring"
      },
      {
        "importer": "apps/desktop",
        "name": "@types/node",
        "version": "24.12.4",
        "package_json_sha256": "456b1366f1966515c4dfec48446c82275502a2d5ea7cfbc74874323b39e3776f",
        "installed_path": "node_modules/.pnpm/@types+node@24.12.4/node_modules/@types/node"
      },
      {
        "importer": "apps/desktop",
        "name": "acorn",
        "version": "8.16.0",
        "package_json_sha256": "705aa08b7b4fee1112244952b4843c40c381a3c7a9fc77101f369a172865bfac",
        "installed_path": "node_modules/.pnpm/acorn@8.16.0/node_modules/acorn"
      },
      {
        "importer": "apps/desktop",
        "name": "cross-env",
        "version": "10.1.0",
        "package_json_sha256": "9713a4eb2d553643a8df26ca9c5f6ae9773cf68446da77cc59db77682ca4dd35",
        "installed_path": "node_modules/.pnpm/cross-env@10.1.0/node_modules/cross-env"
      },
      {
        "importer": "apps/desktop",
        "name": "dbus-next",
        "version": "0.10.2",
        "package_json_sha256": "800c3680141a01339f50d9ffc4b690597ae594a1343dade09db11bf43d056c37",
        "installed_path": "node_modules/.pnpm/dbus-next@0.10.2_patch_hash=cfff57561b0ee59b5addb3b2e6c6f20906e967507a530ab67e8db8108e520ba4/node_modules/dbus-next"
      },
      {
        "importer": "apps/desktop",
        "name": "effect",
        "version": "4.1.3",
        "package_json_sha256": "8ae4c5cf40f75346e2ab4dcacb692a98a6ddd814ecc5ffad27db087d6cfa3a9f",
        "installed_path": "node_modules/.pnpm/effect@4.1.3/node_modules/effect"
      },
      {
        "importer": "apps/desktop",
        "name": "electron",
        "version": "44.10.1",
        "package_json_sha256": "00bc5ed2f6c11af917e98158476941e9e432c2acce33a798ed77318406fbe32c",
        "installed_path": "node_modules/.pnpm/electron@44.10.1_supports-color@8.1.1/node_modules/electron"
      },
      {
        "importer": "apps/desktop",
        "name": "electron-builder",
        "version": "26.16.1",
        "package_json_sha256": "d44956b8590a2027b1982f33baa4c4d065767ac8dbb406b88f7a460dbc17f33e",
        "installed_path": "node_modules/.pnpm/electron-builder@26.16.1_electron-builder-squirrel-windows@26.16.1_supports-color@8.1.1/node_modules/electron-builder"
      },
      {
        "importer": "apps/desktop",
        "name": "electron-store",
        "version": "8.2.0",
        "package_json_sha256": "0abe95307dcd0ab794751d5f4c139debed31368c18eb0d8fdb8ac27f8f475ff0",
        "installed_path": "node_modules/.pnpm/electron-store@8.2.0/node_modules/electron-store"
      },
      {
        "importer": "apps/desktop",
        "name": "electron-updater",
        "version": "6.8.9",
        "package_json_sha256": "ea6e61c4b56bbcd46aeae6b0636cc6c115ccee7f8ce6de4faea9ef3bf94d8988",
        "installed_path": "node_modules/.pnpm/electron-updater@6.8.9_patch_hash=5e096d34a46fdbaa6d48a5803b2c0ed9c7c04f8ab43a30ebebbf726f8f28ed8e_supports-color@8.1.1/node_modules/electron-updater"
      },
      {
        "importer": "apps/desktop",
        "name": "electron-webauthn",
        "version": "1.3.1",
        "package_json_sha256": "02622309a2c2383b257a9b58da4158d53a064634b0fa2be995955b0b6df9cedb",
        "installed_path": "node_modules/.pnpm/electron-webauthn@1.3.1_typescript@6.0.3/node_modules/electron-webauthn"
      },
      {
        "importer": "apps/desktop",
        "name": "ffi-rs",
        "version": "1.3.2",
        "package_json_sha256": "a3f76613fbce43e44ba371ef743a72c6f3242f28a533f909140b402dd24a261f",
        "installed_path": "node_modules/.pnpm/ffi-rs@1.3.2/node_modules/ffi-rs"
      },
      {
        "importer": "apps/desktop",
        "name": "jsdom",
        "version": "30.1.0",
        "package_json_sha256": "651b67b0f9ae95ae7bc5aea9ed5de30cbc5a722e2ce62dbdae9a4f90c9bea059",
        "installed_path": "node_modules/.pnpm/jsdom@30.1.0_@noble+hashes@1.8.0/node_modules/jsdom"
      },
      {
        "importer": "apps/desktop",
        "name": "playwright-core",
        "version": "1.64.1",
        "package_json_sha256": "8aa1c9863fa8dea324e674254158cdc79440f4124ef2d84d38053013541cb7d6",
        "installed_path": "node_modules/.pnpm/playwright-core@1.64.1/node_modules/playwright-core"
      },
      {
        "importer": "apps/desktop",
        "name": "react-grab",
        "version": "0.1.44",
        "package_json_sha256": "b92d58b6675c9da43487840089d203ffcbc5c6f642cfd8468494b2efbe1ad435",
        "installed_path": "node_modules/.pnpm/react-grab@0.1.44_react@19.3.0/node_modules/react-grab"
      },
      {
        "importer": "apps/desktop",
        "name": "tailwindcss",
        "version": "4.3.3",
        "package_json_sha256": "3dc86b46c511947ca00838aa3f1776243abe923ac347c092e60a0cbc7ae68559",
        "installed_path": "node_modules/.pnpm/tailwindcss@4.3.3/node_modules/tailwindcss"
      },
      {
        "importer": "apps/desktop",
        "name": "tldts",
        "version": "7.4.2",
        "package_json_sha256": "d770838e7311ff80f2e3fd50765803407bd8916b1f0a327826aae26fd442eb8d",
        "installed_path": "node_modules/.pnpm/tldts@7.4.2/node_modules/tldts"
      },
      {
        "importer": "apps/desktop",
        "name": "vite-plus",
        "version": "1.4.0",
        "package_json_sha256": "a2901e42e05a5f1c162b994ba85bfbad074a2f8921d129995b019e0bd48c9c09",
        "installed_path": "node_modules/.pnpm/vite-plus@1.4.0_@astrojs+compiler-rs@0.5.1_@types+node@24.12.4_@vitest+browser-playwrig_71b1ef4e5049c7accee71dd249ba4133/node_modules/vite-plus"
      },
      {
        "importer": "apps/marketing",
        "name": "@astrojs/check",
        "version": "0.9.10",
        "package_json_sha256": "adc1de6589375b9f21d25e286d825c6f8f73fd90e8772cbcca5a7dcd88a51cc2",
        "installed_path": "node_modules/.pnpm/@astrojs+check@0.9.10_prettier@3.8.3_typescript@6.0.3/node_modules/@astrojs/check"
      },
      {
        "importer": "apps/marketing",
        "name": "@fontsource-variable/inter",
        "version": "5.3.0",
        "package_json_sha256": "1075dffa0a9ec739bdee2af296b481d2867d305d41be9e0439ca3313d3ad1298",
        "installed_path": "node_modules/.pnpm/@fontsource-variable+inter@5.3.0/node_modules/@fontsource-variable/inter"
      },
      {
        "importer": "apps/marketing",
        "name": "@vercel/config",
        "version": "0.3.0",
        "package_json_sha256": "39f17e576237567ed0df573d0fc929500d8c4fd3f8e362bb48f1831377cd0aab",
        "installed_path": "node_modules/.pnpm/@vercel+config@0.3.0/node_modules/@vercel/config"
      },
      {
        "importer": "apps/marketing",
        "name": "astro",
        "version": "7.3.5",
        "package_json_sha256": "b2a776842745d2ece9364bfcc931092c2f61a45baf4b06da0b533540ce797f19",
        "installed_path": "node_modules/.pnpm/astro@7.3.5_@types+node@24.12.4_@volar+typescript@2.4.28_typescript@6.0.3__aws4fetch@1._169ff019a7bb61484270843ad47d642e/node_modules/astro"
      },
      {
        "importer": "apps/marketing",
        "name": "sharp",
        "version": "0.35.5",
        "package_json_sha256": "ad4a2535d72eb638053a38867b1abf43c328cd1c1dbae5cf4172d498365a8b97",
        "installed_path": "node_modules/.pnpm/sharp@0.35.5_@types+node@24.12.4/node_modules/sharp"
      },
      {
        "importer": "apps/marketing",
        "name": "typescript",
        "version": "6.0.3",
        "package_json_sha256": "9332e97c30d3e53ed54910b89207ed657fb444066484df6e5b6965bf130865e9",
        "installed_path": "node_modules/.pnpm/typescript@6.0.3/node_modules/typescript"
      },
      {
        "importer": "apps/mobile",
        "name": "@babel/core",
        "version": "7.29.7",
        "package_json_sha256": "6c2893db41b54a1c03ba68e676aa3ea987db9a5c9b9a3a3aa2e8d0d9a63066c4",
        "installed_path": "node_modules/.pnpm/@babel+core@7.29.7_supports-color@8.1.1/node_modules/@babel/core"
      },
      {
        "importer": "apps/mobile",
        "name": "@clerk/expo",
        "version": "4.15.1",
        "package_json_sha256": "16a7a8407ba5fcecbe202e23525e8bfb64a52644e7ecef0b36cb9fbfb4cedf0c",
        "installed_path": "node_modules/.pnpm/@clerk+expo@4.15.1_0a077f3c30474be1f3e6856c2409b170/node_modules/@clerk/expo"
      },
      {
        "importer": "apps/mobile",
        "name": "@clerk/expo-native-components",
        "version": "0.4.4",
        "package_json_sha256": "3275604356b99938009fccbf7ba7fd7580839c377964c5e1b3ba08d37cb7ef18",
        "installed_path": "node_modules/.pnpm/@clerk+expo-native-components@0.4.4_patch_hash=7a808b92da8460750b85818552e13be3fb73d111_9201ef54b47c860fa9a4ae8bc8bf3099/node_modules/@clerk/expo-native-components"
      },
      {
        "importer": "apps/mobile",
        "name": "@effect/atom-react",
        "version": "4.1.2",
        "package_json_sha256": "2fd58077f903dd8bd7c4936ec0f24a705c856d8f1beeef3c834a209bcca929bd",
        "installed_path": "node_modules/.pnpm/@effect+atom-react@4.1.2_effect@4.1.3_react@19.3.0_scheduler@0.28.0/node_modules/@effect/atom-react"
      },
      {
        "importer": "apps/mobile",
        "name": "@effect/platform-node",
        "version": "4.1.2",
        "package_json_sha256": "2901f7c08e6011794c624e346b19f85a6b455338c3991578407c3028bd64800e",
        "installed_path": "node_modules/.pnpm/@effect+platform-node@4.1.2_bufferutil@4.1.0_effect@4.1.3_redis@6.2.1_utf-8-validate@6.0.6/node_modules/@effect/platform-node"
      },
      {
        "importer": "apps/mobile",
        "name": "@effect/vitest",
        "version": "4.1.2",
        "package_json_sha256": "63fe8c287b8aa7420363f515f1d6330cfa5574430af94832dab4447afadcfc71",
        "installed_path": "node_modules/.pnpm/@effect+vitest@4.1.2_patch_hash=299510b71c36537a832a67e9d160a5f112a5f326a29e95c41cb45fc_81d3dd1e682774f4c17d7f713915765f/node_modules/@effect/vitest"
      },
      {
        "importer": "apps/mobile",
        "name": "@expo-google-fonts/dm-sans",
        "version": "0.4.2",
        "package_json_sha256": "f41a3b011d2c43b68b394b285d3fc4956d199710873a1f342d05ed1e8d205d3a",
        "installed_path": "node_modules/.pnpm/@expo-google-fonts+dm-sans@0.4.2/node_modules/@expo-google-fonts/dm-sans"
      },
      {
        "importer": "apps/mobile",
        "name": "@expo/metro-runtime",
        "version": "58.0.17",
        "package_json_sha256": "033a4706fd9080e019e8e4d71370601b75fb5c8c65fbf00b666eaa1116d932e2",
        "installed_path": "node_modules/.pnpm/@expo+metro-runtime@58.0.17_@expo+log-box@58.0.15_expo@58.0.23_react-dom@19.3.0_react@1_9a3a36a7b616b18ea71a6f8bbfba5848/node_modules/@expo/metro-runtime"
      },
      {
        "importer": "apps/mobile",
        "name": "@expo/ui",
        "version": "58.0.27",
        "package_json_sha256": "a65b23cbb0bb22a402cb89bc7d9c0a886fc94e7c6da48769da1657897b0317b2",
        "installed_path": "node_modules/.pnpm/@expo+ui@58.0.27_patch_hash=9f2547678939f4ec78fe45163b6455aad63d3c80353d7e0cc783f6a61a7_f9320e354c098ba4e826c545c4ed6b8b/node_modules/@expo/ui"
      },
      {
        "importer": "apps/mobile",
        "name": "@formatjs/intl-displaynames",
        "version": "6.8.13",
        "package_json_sha256": "02cb4725fb116f3e53787e7dee4cd00a9c52aeee53a04b43c04442dec9980695",
        "installed_path": "node_modules/.pnpm/@formatjs+intl-displaynames@6.8.13/node_modules/@formatjs/intl-displaynames"
      },
      {
        "importer": "apps/mobile",
        "name": "@formatjs/intl-getcanonicallocales",
        "version": "2.5.6",
        "package_json_sha256": "6e44ab6483b985a60ea7e73b421feef314012f74b3214fd48faf9563f8b3c321",
        "installed_path": "node_modules/.pnpm/@formatjs+intl-getcanonicallocales@2.5.6/node_modules/@formatjs/intl-getcanonicallocales"
      },
      {
        "importer": "apps/mobile",
        "name": "@formatjs/intl-locale",
        "version": "4.2.13",
        "package_json_sha256": "2b411febd5d0f6c5cc49b057f5b3c56d17477b816a4777b59247ca39090c93bd",
        "installed_path": "node_modules/.pnpm/@formatjs+intl-locale@4.2.13/node_modules/@formatjs/intl-locale"
      },
      {
        "importer": "apps/mobile",
        "name": "@legendapp/list",
        "version": "3.7.2",
        "package_json_sha256": "56c58e745cda0a48dd12b18ea19ab98b57de0e3559127c7fe6ec967ec4259222",
        "installed_path": "node_modules/.pnpm/@legendapp+list@3.7.2_patch_hash=3c68607b8bb7a531873bcbe0b197d163ef1fdb4d4cf52a4ddf9d2b_1a8bdca797f182e303220354dc2ccdc2/node_modules/@legendapp/list"
      },
      {
        "importer": "apps/mobile",
        "name": "@material/material-color-utilities",
        "version": "0.3.0",
        "package_json_sha256": "bc6d0c72745cef5488b2eaecb191eb5b8b91036d21e5c35985fe9f5069c683a4",
        "installed_path": "node_modules/.pnpm/@material+material-color-utilities@0.3.0/node_modules/@material/material-color-utilities"
      },
      {
        "importer": "apps/mobile",
        "name": "@pierre/diffs",
        "version": "1.7.0-beta.3",
        "package_json_sha256": "0663dc59ce053c8be045cf1edc1489d94fab003735e2c74a7f224723b4c0d46c",
        "installed_path": "node_modules/.pnpm/@pierre+diffs@1.7.0-beta.3_patch_hash=4a64f63a0def94c5add9d86d70560d26d6857e1f515013386_8cf7878feba9a5fb545c4167fb5428f0/node_modules/@pierre/diffs"
      },
      {
        "importer": "apps/mobile",
        "name": "@pierre/highlights",
        "version": "0.5.0",
        "package_json_sha256": "9c78280fe2ba84f0dc20faa8b83823a56b18be39c78587110a75f435341d2170",
        "installed_path": "node_modules/.pnpm/@pierre+highlights@0.5.0/node_modules/@pierre/highlights"
      },
      {
        "importer": "apps/mobile",
        "name": "@pierre/trees",
        "version": "1.0.0-beta.6",
        "package_json_sha256": "d1899e2d7fe1ad3e97ccff57dd93bf81e6dd7904e3872862d812645b4171e1f7",
        "installed_path": "node_modules/.pnpm/@pierre+trees@1.0.0-beta.6_@pierre+theme@2.0.0_@shikijs+themes@4.2.0_react-dom@19.3.0_r_6f89bc20e49cc599ef547096bbeb5e4e/node_modules/@pierre/trees"
      },
      {
        "importer": "apps/mobile",
        "name": "@react-native-ai/apple",
        "version": "0.12.0",
        "package_json_sha256": "f048a80daf24deb35b3b20787c6fb909a36f6fd4e4a4db749c18fef20f29d26e",
        "installed_path": "node_modules/.pnpm/@react-native-ai+apple@0.12.0_patch_hash=2d09870c2848d185cb05b53ed823a46e12dba519324d8d_c9b0200e3fa44d381347d43b4930a48f/node_modules/@react-native-ai/apple"
      },
      {
        "importer": "apps/mobile",
        "name": "@react-native-menu/menu",
        "version": "2.0.0",
        "package_json_sha256": "70dada0188d98b29c1bfbe47649c2be1ed15a7a00afd9afe432644e2c007af86",
        "installed_path": "node_modules/.pnpm/@react-native-menu+menu@2.0.0_patch_hash=6872ba71b9847c5a0210b1b896923dadc3860faedfe28d_2a742f1d1834f7b6065c0a2b77551f5a/node_modules/@react-native-menu/menu"
      },
      {
        "importer": "apps/mobile",
        "name": "@react-navigation/elements",
        "version": "2.9.45",
        "package_json_sha256": "855f2bb1eeee733d465a01db83d0b6e40b0a0e8332036ac90eaed7d6930235ed",
        "installed_path": "node_modules/.pnpm/@react-navigation+elements@2.9.45_83450c2b8dad8f97d4bec4849f35b99e/node_modules/@react-navigation/elements"
      },
      {
        "importer": "apps/mobile",
        "name": "@react-navigation/native",
        "version": "7.5.1",
        "package_json_sha256": "08c16db410b4fa9c3b0d5b8649a99824ee16f140f1ce9bec0068342497ed6249",
        "installed_path": "node_modules/.pnpm/@react-navigation+native@7.5.1_react-native@0.88.1_@babel+core@7.29.7_supports-color@8._6601404653bbc2b687e34dcbe7ac88a5/node_modules/@react-navigation/native"
      },
      {
        "importer": "apps/mobile",
        "name": "@react-navigation/native-stack",
        "version": "7.21.0",
        "package_json_sha256": "6e54e0a54ae45ca6916248ef886e409c67359197aa9f2b54bbe4c1bebac34c0c",
        "installed_path": "node_modules/.pnpm/@react-navigation+native-stack@7.21.0_patch_hash=990d575444c4af2ce8218b3b7a8280fe244c03_92ba7a6e43d64fc4c68923eafaafb450/node_modules/@react-navigation/native-stack"
      },
      {
        "importer": "apps/mobile",
        "name": "@t3tools/mobile-highlights-native",
        "version": "0.0.0",
        "package_json_sha256": "e671f8a8bb3ea844d4e19d67cb13a8c3b65e9054d1da54f52b0834bebab2641d",
        "installed_path": "node_modules/.pnpm/@t3tools+mobile-highlights-native@file+apps+mobile+modules+t3-highlights_react-native-n_71e1338f8d587133ffdea8e1ad79a894/node_modules/@t3tools/mobile-highlights-native"
      },
      {
        "importer": "apps/mobile",
        "name": "@t3tools/mobile-review-diff-native",
        "version": "0.0.0",
        "package_json_sha256": "f8069b984dd5468bc6018fe53172deed700fe28706ad345b5ce06da3535c9f9d",
        "installed_path": "node_modules/.pnpm/@t3tools+mobile-review-diff-native@file+apps+mobile+modules+t3-review-diff/node_modules/@t3tools/mobile-review-diff-native"
      },
      {
        "importer": "apps/mobile",
        "name": "@t3tools/mobile-source-text",
        "version": "0.0.0",
        "package_json_sha256": "f9acced1f779de8622f6612aacce6042288b2f8a510e531e151037e49e5f03db",
        "installed_path": "node_modules/.pnpm/@t3tools+mobile-source-text@file+apps+mobile+modules+t3-source-text_react-native@0.88.1_bd012c974fecfcc52b0f38e51dc2de27/node_modules/@t3tools/mobile-source-text"
      },
      {
        "importer": "apps/mobile",
        "name": "@t3tools/mobile-terminal-native",
        "version": "0.0.0",
        "package_json_sha256": "303ec2ceb7e22415e43570946a0e0fe2be71c36b33d07ae5e79e4f5930b30956",
        "installed_path": "node_modules/.pnpm/@t3tools+mobile-terminal-native@file+apps+mobile+modules+t3-terminal/node_modules/@t3tools/mobile-terminal-native"
      },
      {
        "importer": "apps/mobile",
        "name": "@tabler/icons-react-native",
        "version": "3.44.0",
        "package_json_sha256": "cbff409e37d2368c4c53d737c62df28996267af179134d7be9ccaefe844aedd6",
        "installed_path": "node_modules/.pnpm/@tabler+icons-react-native@3.44.0_react-native-svg@15.16.1_patch_hash=110f9243ffad03654_55f4b9bef7799dca9f94e80e5a6f21b7/node_modules/@tabler/icons-react-native"
      },
      {
        "importer": "apps/mobile",
        "name": "@types/mdast",
        "version": "4.0.4",
        "package_json_sha256": "5a41865d64d4cedba58313fad775cf56bd0474d724343172bcea9f8ad24db563",
        "installed_path": "node_modules/.pnpm/@types+mdast@4.0.4/node_modules/@types/mdast"
      },
      {
        "importer": "apps/mobile",
        "name": "@types/react",
        "version": "19.3.0",
        "package_json_sha256": "505c0df4cd73d6a02c946bd9b81451584bd9c83ea72d75cff9b826efceaa19c2",
        "installed_path": "node_modules/.pnpm/@types+react@19.3.0/node_modules/@types/react"
      },
      {
        "importer": "apps/mobile",
        "name": "@types/react-dom",
        "version": "19.3.0",
        "package_json_sha256": "4a2052bb362c34f1d39cfe0818b6fe01a9f988b609e8b7e4832aff7dbf2f7180",
        "installed_path": "node_modules/.pnpm/@types+react-dom@19.3.0_@types+react@19.3.0/node_modules/@types/react-dom"
      },
      {
        "importer": "apps/mobile",
        "name": "aws4fetch",
        "version": "1.0.20",
        "package_json_sha256": "55768e57d4f5ed27fdd9c2a8bc243549a9e2f3d71827219ba496de4aa90f75cc",
        "installed_path": "node_modules/.pnpm/aws4fetch@1.0.20/node_modules/aws4fetch"
      },
      {
        "importer": "apps/mobile",
        "name": "babel-preset-expo",
        "version": "58.0.24",
        "package_json_sha256": "b450c53cf65c10d5513ac31cc2d0289121102f75c9aab36c56407d6f1318c408",
        "installed_path": "node_modules/.pnpm/babel-preset-expo@58.0.24_@babel+core@7.29.7_supports-color@8.1.1__@babel+runtime@7.29._d3e377a8992e584b59e4a7d8db65012e/node_modules/babel-preset-expo"
      },
      {
        "importer": "apps/mobile",
        "name": "clsx",
        "version": "2.1.1",
        "package_json_sha256": "a5e616b9883177fb47c1fca22b6a4ab42be1c3ed6ffae8595a5c7d88630eeec2",
        "installed_path": "node_modules/.pnpm/clsx@2.1.1/node_modules/clsx"
      },
      {
        "importer": "apps/mobile",
        "name": "diff",
        "version": "8.0.3",
        "package_json_sha256": "35b083dc3430465fbe066129e12debeb5416474e1db71abf7a8db9997789aeed",
        "installed_path": "node_modules/.pnpm/diff@8.0.3/node_modules/diff"
      },
      {
        "importer": "apps/mobile",
        "name": "effect",
        "version": "4.1.3",
        "package_json_sha256": "8ae4c5cf40f75346e2ab4dcacb692a98a6ddd814ecc5ffad27db087d6cfa3a9f",
        "installed_path": "node_modules/.pnpm/effect@4.1.3/node_modules/effect"
      },
      {
        "importer": "apps/mobile",
        "name": "expo",
        "version": "58.0.23",
        "package_json_sha256": "6d461bcd4e874be6b30583b13480fb28e74d9fa2732acba593640415693643f6",
        "installed_path": "node_modules/.pnpm/expo@58.0.23_d226faf1ca90e630d8c56a2108dee32d/node_modules/expo"
      },
      {
        "importer": "apps/mobile",
        "name": "expo-application",
        "version": "58.1.2",
        "package_json_sha256": "baad9b9de65c79515d77cde866f3595ec1cef74b8c6a62a73b1e1ff09730ca86",
        "installed_path": "node_modules/.pnpm/expo-application@58.1.2_expo@58.0.23/node_modules/expo-application"
      },
      {
        "importer": "apps/mobile",
        "name": "expo-asset",
        "version": "58.0.20",
        "package_json_sha256": "9e9f2ad7a8106015c8cc61232b35bb84f1d80fa942ed99641f7146c3ac248f12",
        "installed_path": "node_modules/.pnpm/expo-asset@58.0.20_expo@58.0.23_react-native@0.88.1_@babel+core@7.29.7_supports-color@8_d684989fe60c69344f1a15337aeb95a8/node_modules/expo-asset"
      },
      {
        "importer": "apps/mobile",
        "name": "expo-audio",
        "version": "58.0.11",
        "package_json_sha256": "10dc5e28af6145fc3cc5878402d6982af762d886c2fe37e1a45a7c46d02e0e43",
        "installed_path": "node_modules/.pnpm/expo-audio@58.0.11_patch_hash=93691f7f59edb30a3bb2c23b489e605e7ea35506b1212d4a2ebbd1fd7_4c23a38a00cce203e4783505881fe972/node_modules/expo-audio"
      },
      {
        "importer": "apps/mobile",
        "name": "expo-auth-session",
        "version": "58.0.17",
        "package_json_sha256": "c286ed0a7e9f2df13c94fbbe07a3b209d910402cfcb3121088e5fbf856bac51c",
        "installed_path": "node_modules/.pnpm/expo-auth-session@58.0.17_expo@58.0.23_react-native@0.88.1_@babel+core@7.29.7_supports-_37cf20f1350f26829cd3772bc5085d6d/node_modules/expo-auth-session"
      },
      {
        "importer": "apps/mobile",
        "name": "expo-blur",
        "version": "58.0.5",
        "package_json_sha256": "92183dae29e584974b21138ad9ef1f18cfa72853a2200ffd5ce967eafc9a8bd6",
        "installed_path": "node_modules/.pnpm/expo-blur@58.0.5_expo@58.0.23_react-native@0.88.1_@babel+core@7.29.7_supports-color@8.1_5a55dae8b9b7431dfc195f1dbc4aeccc/node_modules/expo-blur"
      },
      {
        "importer": "apps/mobile",
        "name": "expo-build-properties",
        "version": "58.0.12",
        "package_json_sha256": "6ee45ec9297154d91bc852560f762b6a6a9ea3f71c4fc02fcd1b93f1828622ef",
        "installed_path": "node_modules/.pnpm/expo-build-properties@58.0.12_expo@58.0.23/node_modules/expo-build-properties"
      },
      {
        "importer": "apps/mobile",
        "name": "expo-camera",
        "version": "58.0.14",
        "package_json_sha256": "8dd11fca3a9e0ed652b15efa8a618d845cd54bb866093c4acab9659863f96b67",
        "installed_path": "node_modules/.pnpm/expo-camera@58.0.14_@types+emscripten@1.41.5_expo@58.0.23_react-native@0.88.1_@babel+co_c64ffb4b5b223c2f35e80ef200bd617d/node_modules/expo-camera"
      },
      {
        "importer": "apps/mobile",
        "name": "expo-clipboard",
        "version": "58.0.4",
        "package_json_sha256": "5730ba76319b21e144eee7ad6e97de6d3e706eea977191bf9ff70fca15c43547",
        "installed_path": "node_modules/.pnpm/expo-clipboard@58.0.4_expo@58.0.23_react-native@0.88.1_@babel+core@7.29.7_supports-colo_ecb82b5d0389e38ebce7b43d1acdee46/node_modules/expo-clipboard"
      },
      {
        "importer": "apps/mobile",
        "name": "expo-constants",
        "version": "58.0.15",
        "package_json_sha256": "1a3adee283dc0e514170ddf724c9aed5425ffad1386b1416164cc90d97b83511",
        "installed_path": "node_modules/.pnpm/expo-constants@58.0.15_expo@58.0.23_react-native@0.88.1_@babel+core@7.29.7_supports-col_458b1377c7fba9a30e95978282325114/node_modules/expo-constants"
      },
      {
        "importer": "apps/mobile",
        "name": "expo-crypto",
        "version": "58.0.7",
        "package_json_sha256": "95d382241a7f7d9662dafaef7b590988ad4def1144e38b05f9eafc5aac7d8b3b",
        "installed_path": "node_modules/.pnpm/expo-crypto@58.0.7_expo@58.0.23/node_modules/expo-crypto"
      },
      {
        "importer": "apps/mobile",
        "name": "expo-dev-client",
        "version": "58.0.18",
        "package_json_sha256": "ad30bf1f08373adb5fbc6af6414e4de48a87dd4d7c79fe416bf18475ce7f1a13",
        "installed_path": "node_modules/.pnpm/expo-dev-client@58.0.18_expo@58.0.23_react-native@0.88.1_@babel+core@7.29.7_supports-co_69c80fbaacfb15228274a09657a2c8fc/node_modules/expo-dev-client"
      },
      {
        "importer": "apps/mobile",
        "name": "expo-device",
        "version": "58.0.5",
        "package_json_sha256": "486635f995d5c35ba6075b26a9ac0541022126fa4c3ec8e90814a9a486b0d322",
        "installed_path": "node_modules/.pnpm/expo-device@58.0.5_expo@58.0.23/node_modules/expo-device"
      },
      {
        "importer": "apps/mobile",
        "name": "expo-document-picker",
        "version": "58.0.4",
        "package_json_sha256": "aed5fdd915ff42f8de304489053d7fbf7365bc21b564991d75b6e9fc0d1ffd1b",
        "installed_path": "node_modules/.pnpm/expo-document-picker@58.0.4_expo@58.0.23/node_modules/expo-document-picker"
      },
      {
        "importer": "apps/mobile",
        "name": "expo-file-system",
        "version": "58.0.13",
        "package_json_sha256": "7a5f05dffbdfb6071054dc164f44be739b25397f846845a38989686ef7b32cac",
        "installed_path": "node_modules/.pnpm/expo-file-system@58.0.13_expo@58.0.23_react-native@0.88.1_@babel+core@7.29.7_supports-c_f224a4072ff3061a085bc9f0f2822ddf/node_modules/expo-file-system"
      },
      {
        "importer": "apps/mobile",
        "name": "expo-font",
        "version": "58.0.11",
        "package_json_sha256": "a39a111996fb3549857ce64b59fee0900af9d953f9b8581e5f116ae647041220",
        "installed_path": "node_modules/.pnpm/expo-font@58.0.11_expo@58.0.23_react-native@0.88.1_@babel+core@7.29.7_supports-color@8._fe6e6baf88bc8b1ea31c8267a32963ee/node_modules/expo-font"
      },
      {
        "importer": "apps/mobile",
        "name": "expo-glass-effect",
        "version": "58.0.5",
        "package_json_sha256": "b6dcc6477dc842dbab46af47c74e09fa16b8994d7b69427be3826cb77efacbcd",
        "installed_path": "node_modules/.pnpm/expo-glass-effect@58.0.5_expo@58.0.23_react-native@0.88.1_@babel+core@7.29.7_supports-c_f1ac9a0294601ca1ce825cb74e78f44a/node_modules/expo-glass-effect"
      },
      {
        "importer": "apps/mobile",
        "name": "expo-haptics",
        "version": "58.0.7",
        "package_json_sha256": "9617fe6f6c4af7040271f3028422ba20a0b75773a0df893c921a36a8f8b77d3d",
        "installed_path": "node_modules/.pnpm/expo-haptics@58.0.7_expo@58.0.23/node_modules/expo-haptics"
      },
      {
        "importer": "apps/mobile",
        "name": "expo-image",
        "version": "58.0.18",
        "package_json_sha256": "b21f4530a67399aaa7492c51e7b2c1aa50bc5b9c1089e86e9e9ffa7fba095f2f",
        "installed_path": "node_modules/.pnpm/expo-image@58.0.18_expo@58.0.23_react-native@0.88.1_@babel+core@7.29.7_supports-color@8_f9e87f26738f44475ab571f6f9b50af8/node_modules/expo-image"
      },
      {
        "importer": "apps/mobile",
        "name": "expo-image-manipulator",
        "version": "58.0.16",
        "package_json_sha256": "27b31ae3e5a2c46ccafe1017f43a3de090ff44136ba36e083b556d1fa24c4b93",
        "installed_path": "node_modules/.pnpm/expo-image-manipulator@58.0.16_expo@58.0.23_react-native@0.88.1_@babel+core@7.29.7_supp_a995e70d5a6d5b314e0dc1c8ee1262c9/node_modules/expo-image-manipulator"
      },
      {
        "importer": "apps/mobile",
        "name": "expo-image-picker",
        "version": "58.0.10",
        "package_json_sha256": "4e80fe1e451471d46bb78cc6ab905c7e001344761af26a46dc16edae5bf40768",
        "installed_path": "node_modules/.pnpm/expo-image-picker@58.0.10_expo@58.0.23/node_modules/expo-image-picker"
      },
      {
        "importer": "apps/mobile",
        "name": "expo-keep-awake",
        "version": "58.0.3",
        "package_json_sha256": "b2bd0d458ea4f778fd3fb60a09000a2cea2904839f875e98674c3843ebbf61d9",
        "installed_path": "node_modules/.pnpm/expo-keep-awake@58.0.3_expo@58.0.23_react@19.3.0/node_modules/expo-keep-awake"
      },
      {
        "importer": "apps/mobile",
        "name": "expo-linking",
        "version": "58.0.16",
        "package_json_sha256": "b3f6fdda6fd1cbc144b0a94de244319428af8c0edb90fd11e588f733330af0b2",
        "installed_path": "node_modules/.pnpm/expo-linking@58.0.16_expo@58.0.23_react-native@0.88.1_@babel+core@7.29.7_supports-color_c4ff51b0c20ecbf4a9f9bb640ca4f42f/node_modules/expo-linking"
      },
      {
        "importer": "apps/mobile",
        "name": "expo-network",
        "version": "58.0.4",
        "package_json_sha256": "95553c9ee8993b1b5a62e54ec0506eba7590fb877658f6acb44b845e13d6ec51",
        "installed_path": "node_modules/.pnpm/expo-network@58.0.4_patch_hash=159c2d760d1cd5102e95df51c20600111e7a72096ef0daea8215d50c_a0f6ca79937eda9709c6dc6968b625f2/node_modules/expo-network"
      },
      {
        "importer": "apps/mobile",
        "name": "expo-notifications",
        "version": "58.1.8",
        "package_json_sha256": "95985ab25a4ad0d1ed445f501cda89c44461fd57c4481472edd10fd88bac0caa",
        "installed_path": "node_modules/.pnpm/expo-notifications@58.1.8_expo@58.0.23_react-native@0.88.1_@babel+core@7.29.7_supports-_42f8a55d7998e1cb92d1eb58f3d4e683/node_modules/expo-notifications"
      },
      {
        "importer": "apps/mobile",
        "name": "expo-observe",
        "version": "58.0.18",
        "package_json_sha256": "60f0c2373d4a9960321b1c59e09d8d503c689ef465ae725432305b3c1ca1aa1a",
        "installed_path": "node_modules/.pnpm/expo-observe@58.0.18_44167fcbb622a1246dd06560eb01ad42/node_modules/expo-observe"
      },
      {
        "importer": "apps/mobile",
        "name": "expo-paste-input",
        "version": "0.2.2",
        "package_json_sha256": "cf54bc21c53fbd2f3d0c4607ab27db8c44adbc367768b506c7460e6437e276c9",
        "installed_path": "node_modules/.pnpm/expo-paste-input@0.2.2_expo@58.0.23_react-native@0.88.1_@babel+core@7.29.7_supports-col_52f91638ad42f921fabd62d1bf71c221/node_modules/expo-paste-input"
      },
      {
        "importer": "apps/mobile",
        "name": "expo-quick-actions",
        "version": "6.0.2",
        "package_json_sha256": "5c8819b5c1742610c2cb2c14e496f9574b4c28927cf82d9ba7874d5bcc4f95bf",
        "installed_path": "node_modules/.pnpm/expo-quick-actions@6.0.2_expo@58.0.23_supports-color@8.1.1_typescript@6.0.3/node_modules/expo-quick-actions"
      },
      {
        "importer": "apps/mobile",
        "name": "expo-secure-store",
        "version": "58.0.2",
        "package_json_sha256": "810fd562270182b7497ef1045a7a09a038861f7733e2967e165aa686bbad34e6",
        "installed_path": "node_modules/.pnpm/expo-secure-store@58.0.2_expo@58.0.23/node_modules/expo-secure-store"
      },
      {
        "importer": "apps/mobile",
        "name": "expo-sensors",
        "version": "58.0.4",
        "package_json_sha256": "f55f0b176095ab7bf5b597ef3daa20518e0dc694ba2b9e9858f987f3f6975f9c",
        "installed_path": "node_modules/.pnpm/expo-sensors@58.0.4_expo@58.0.23_react-native@0.88.1_@babel+core@7.29.7_supports-color@_253f3ce043ecf46320747ece01daa037/node_modules/expo-sensors"
      },
      {
        "importer": "apps/mobile",
        "name": "expo-sharing",
        "version": "58.0.22",
        "package_json_sha256": "2f4d44ff5bf33016f8820c7a04e25f9e011f1f463a9f67456e71cc27eb472f69",
        "installed_path": "node_modules/.pnpm/expo-sharing@58.0.22_patch_hash=321a86e1471e34c53f1f2937fbb4304ea3f7b7a78ad9e4d35febc2b_084825dc915e6bb0b7ce2d3e4bfef46e/node_modules/expo-sharing"
      },
      {
        "importer": "apps/mobile",
        "name": "expo-splash-screen",
        "version": "58.0.13",
        "package_json_sha256": "b696e0cc2493d7b3c562d7a1eee8b3aadc4eedf3b881174875254492b29e43ec",
        "installed_path": "node_modules/.pnpm/expo-splash-screen@58.0.13_expo@58.0.23_supports-color@8.1.1_typescript@6.0.3/node_modules/expo-splash-screen"
      },
      {
        "importer": "apps/mobile",
        "name": "expo-sqlite",
        "version": "58.0.15",
        "package_json_sha256": "08f5188824aca83d2adbe6d550d3038fe7c3393090d59aae6cfd74dff6cfac63",
        "installed_path": "node_modules/.pnpm/expo-sqlite@58.0.15_expo@58.0.23_react-native@0.88.1_@babel+core@7.29.7_supports-color@_f9a585959d833bd48c14b70922e3a515/node_modules/expo-sqlite"
      },
      {
        "importer": "apps/mobile",
        "name": "expo-symbols",
        "version": "58.0.4",
        "package_json_sha256": "2c119a886634a9623139af11b9c548a1253c5d639c2e0a70096390f4490ae0f8",
        "installed_path": "node_modules/.pnpm/expo-symbols@58.0.4_expo-font@58.0.11_expo@58.0.23_react-native@0.88.1_@babel+core@7.29_b65e4437a8ba2e84b6c97cc1a9446fdf/node_modules/expo-symbols"
      },
      {
        "importer": "apps/mobile",
        "name": "expo-updates",
        "version": "58.0.21",
        "package_json_sha256": "8db080cffa4899efa66d494520ee3b81f5091ee18528df355c46cace6f434332",
        "installed_path": "node_modules/.pnpm/expo-updates@58.0.21_expo-dev-client@58.0.18_expo@58.0.23_react-native@0.88.1_@babel+co_1ac61ffd39f9faa617fba97481fb9a6a/node_modules/expo-updates"
      },
      {
        "importer": "apps/mobile",
        "name": "expo-video",
        "version": "58.0.13",
        "package_json_sha256": "e5c737d4f65ad44144d971f3464a1bc6e9e0b7e20a237cca423303220eba3576",
        "installed_path": "node_modules/.pnpm/expo-video@58.0.13_patch_hash=e80ec3ef8c4af50a607beea1c0917e71ba679844efdb702b45d17a5f0_53d58f33d368f2aaef5561bf882f547c/node_modules/expo-video"
      },
      {
        "importer": "apps/mobile",
        "name": "expo-web-browser",
        "version": "58.0.7",
        "package_json_sha256": "d1df0c4bfa54ae66d6ed749f104975dd4dc29238464c7da85d3126894d5892ba",
        "installed_path": "node_modules/.pnpm/expo-web-browser@58.0.7_expo@58.0.23_react-native@0.88.1_@babel+core@7.29.7_supports-co_52417d08745fc660a0ee1a6b4e32e47e/node_modules/expo-web-browser"
      },
      {
        "importer": "apps/mobile",
        "name": "expo-widgets",
        "version": "58.0.27",
        "package_json_sha256": "9cb45db27b6d6f6ae68804c890a9ced46d0e55e7d98312c875b8b56cf49f2a03",
        "installed_path": "node_modules/.pnpm/expo-widgets@58.0.27_patch_hash=8bf49067f93742855e15f29559ac75c8b50230b47069060993c9ea0_f3d8833f1d03167207654859b6332f2c/node_modules/expo-widgets"
      },
      {
        "importer": "apps/mobile",
        "name": "gt",
        "version": "2.27.0",
        "package_json_sha256": "556030d6491f1aa4f78cb390276c8c7040dcf81e0b98b79f160438afffa82a34",
        "installed_path": "node_modules/.pnpm/gt@2.27.0_@babel+core@7.29.7_supports-color@8.1.1__supports-color@8.1.1/node_modules/gt"
      },
      {
        "importer": "apps/mobile",
        "name": "gt-react-native",
        "version": "11.4.18",
        "package_json_sha256": "eb82d6a9bd85f9a905107b35f61890bf6f16741736f42b37145ca07cd370678e",
        "installed_path": "node_modules/.pnpm/gt-react-native@11.4.18_react-native@0.88.1_@babel+core@7.29.7_supports-color@8.1.1__@r_fc030ddb1a7b87bc93a2a55a8f257eda/node_modules/gt-react-native"
      },
      {
        "importer": "apps/mobile",
        "name": "jsdom",
        "version": "30.1.0",
        "package_json_sha256": "651b67b0f9ae95ae7bc5aea9ed5de30cbc5a722e2ce62dbdae9a4f90c9bea059",
        "installed_path": "node_modules/.pnpm/jsdom@30.1.0_@noble+hashes@1.8.0/node_modules/jsdom"
      },
      {
        "importer": "apps/mobile",
        "name": "nitrogen",
        "version": "0.37.2",
        "package_json_sha256": "e8396a6ccfe57327bde76e3c47a4ba181a167464e3d2d8fc18aacbb21ad25572",
        "installed_path": "node_modules/.pnpm/nitrogen@0.37.2/node_modules/nitrogen"
      },
      {
        "importer": "apps/mobile",
        "name": "pele",
        "version": "1.8.0",
        "package_json_sha256": "19123c371b0d9e2d006be133e18866abb94b7d8189e5ae1bff651f79ef8c9b6d",
        "installed_path": "node_modules/.pnpm/pele@1.8.0/node_modules/pele"
      },
      {
        "importer": "apps/mobile",
        "name": "react",
        "version": "19.3.0",
        "package_json_sha256": "6e003e4e9ed25afa7fdd55613f8aa877cefa9b359d9c13f81ee704030248e24e",
        "installed_path": "node_modules/.pnpm/react@19.3.0/node_modules/react"
      },
      {
        "importer": "apps/mobile",
        "name": "react-dom",
        "version": "19.3.0",
        "package_json_sha256": "136d4af63de473392ea79d6a21932b0ed9eb37fe518ce70f4621250f3d79e9bb",
        "installed_path": "node_modules/.pnpm/react-dom@19.3.0_react@19.3.0/node_modules/react-dom"
      },
      {
        "importer": "apps/mobile",
        "name": "react-native",
        "version": "0.88.1",
        "package_json_sha256": "3f2bf69ed883e97a295b1de43f5a2d75d112ab45495153360c2fb521023c7f3f",
        "installed_path": "node_modules/.pnpm/react-native@0.88.1_@babel+core@7.29.7_supports-color@8.1.1__@react-native+metro-config_da6e9a0335c82e1f3445be2e29567972/node_modules/react-native"
      },
      {
        "importer": "apps/mobile",
        "name": "react-native-enriched-markdown",
        "version": "1.2.0-t3.18",
        "package_json_sha256": "f2ad2c117e01dbd5336534987091d681af0b02e187694d06bd5fd452863926c8",
        "installed_path": "node_modules/.pnpm/react-native-enriched-markdown@file+apps+mobile+deps+react-native-enriched-markdown-1.2_198c6fb40cc86f34c46938ffea829670/node_modules/react-native-enriched-markdown"
      },
      {
        "importer": "apps/mobile",
        "name": "react-native-gesture-handler",
        "version": "3.5.0",
        "package_json_sha256": "6076050723be1af85136a404ae0afd05edf28c6fbeee7aacd7fad4f5b22eb949",
        "installed_path": "node_modules/.pnpm/react-native-gesture-handler@3.5.0_patch_hash=171379dd378f8f11e9187876dec2116e5cbf5f21c_0faa94d72c165824390b0998be75ec03/node_modules/react-native-gesture-handler"
      },
      {
        "importer": "apps/mobile",
        "name": "react-native-image-viewing",
        "version": "0.2.2",
        "package_json_sha256": "29e849b8bef392707851a025ed391d1d7d971f27b48c3872e774b15cd72938cc",
        "installed_path": "node_modules/.pnpm/react-native-image-viewing@0.2.2_patch_hash=4aa038d541c7ddcc8f1437eb3e7b4f769f61de78e7f_6ed021fdcfbafef4ffc79a1331bbcf7f/node_modules/react-native-image-viewing"
      },
      {
        "importer": "apps/mobile",
        "name": "react-native-keyboard-controller",
        "version": "1.23.0",
        "package_json_sha256": "9f96c70f3b6a3f62af8014b7a1c6337506ff75c562e0772a9b54e0967ca5a54b",
        "installed_path": "node_modules/.pnpm/react-native-keyboard-controller@1.23.0_patch_hash=1c7c80317ef050e08d4aabe034a0813d03b4_3955041fd2e55e646b17651d2e36d6d0/node_modules/react-native-keyboard-controller"
      },
      {
        "importer": "apps/mobile",
        "name": "react-native-nitro-modules",
        "version": "0.37.2",
        "package_json_sha256": "d861a80f0c633b75e88307c6c22c8950de768a51cd85522f857a1f39c741fc5c",
        "installed_path": "node_modules/.pnpm/react-native-nitro-modules@0.37.2_react-native@0.88.1_@babel+core@7.29.7_supports-color_d19fa5874269b46a028905d629c1082e/node_modules/react-native-nitro-modules"
      },
      {
        "importer": "apps/mobile",
        "name": "react-native-pdf-jsi",
        "version": "6.1.0",
        "package_json_sha256": "59310654a6b1c9c11f0f226fe1ae4f5b775a2d01004d8fdffa8a49433d6f5da5",
        "installed_path": "node_modules/.pnpm/react-native-pdf-jsi@6.1.0_patch_hash=d29e6b69813548de641a09db705dd94823d3f96832821ae9c_3d88967f17ec333d77462597ae61aac7/node_modules/react-native-pdf-jsi"
      },
      {
        "importer": "apps/mobile",
        "name": "react-native-reanimated",
        "version": "4.7.1",
        "package_json_sha256": "48f6747c1b290642a1391402d2b8f342ee2c141840a9c7a12afe0f72e55c170c",
        "installed_path": "node_modules/.pnpm/react-native-reanimated@4.7.1_patch_hash=95ee26e5fcab5f50bc4b4c47b3f7e6278a0b20850205ef_e1cc8f3a61ae30a2d36708ace5d0d162/node_modules/react-native-reanimated"
      },
      {
        "importer": "apps/mobile",
        "name": "react-native-safe-area-context",
        "version": "5.11.1",
        "package_json_sha256": "664910ae3a789f27bdbc31b9bc9e639fceb89d5d30294dc3bb4c209a67a27a83",
        "installed_path": "node_modules/.pnpm/react-native-safe-area-context@5.11.1_react-native@0.88.1_@babel+core@7.29.7_supports-c_5fb3661127ab1b59f07a8e4442f36fcd/node_modules/react-native-safe-area-context"
      },
      {
        "importer": "apps/mobile",
        "name": "react-native-screens",
        "version": "5.0.0-t3.50",
        "package_json_sha256": "65ac95c932cbe8f8b3996543391c38606116af6da1f732952910fd5409e49bff",
        "installed_path": "node_modules/.pnpm/react-native-screens@file+apps+mobile+deps+react-native-screens-5.0.0-t3.50.tgz_react-n_c9ca249c4c8ce525136420180ebe0ccd/node_modules/react-native-screens"
      },
      {
        "importer": "apps/mobile",
        "name": "react-native-svg",
        "version": "15.16.1",
        "package_json_sha256": "59e0b0fa2531520e18d87670caf0ebb94c3dea2d90feeb7466a8f24d2da05842",
        "installed_path": "node_modules/.pnpm/react-native-svg@15.16.1_patch_hash=110f9243ffad03654ce40dd1cdb09f01af16b8fa2ccb2b2cd3d_b84212e51d208e7dd25de00bf87cb252/node_modules/react-native-svg"
      },
      {
        "importer": "apps/mobile",
        "name": "react-native-webview",
        "version": "14.0.1",
        "package_json_sha256": "fc148436be5c1a92af689e2f5c1c27cddef88f7f2f01dc1320611d59bae2245c",
        "installed_path": "node_modules/.pnpm/react-native-webview@14.0.1_patch_hash=71009983c76818bd5e73d4ca597f76efd04101600c84cd4b_1252ce399fb259f8898c8618c153cacb/node_modules/react-native-webview"
      },
      {
        "importer": "apps/mobile",
        "name": "react-native-worklets",
        "version": "0.13.1",
        "package_json_sha256": "78788d9567e340a35dad1e7fd3a45b23a3d683ba2e87f1e9a384b412b1472a2b",
        "installed_path": "node_modules/.pnpm/react-native-worklets@0.13.1_@babel+core@7.29.7_supports-color@8.1.1__@react-native+met_53b5eed0146c1e00af4b69858c0c3b93/node_modules/react-native-worklets"
      },
      {
        "importer": "apps/mobile",
        "name": "remark-gfm",
        "version": "4.0.1",
        "package_json_sha256": "c199482a69355b610bd1ff225b097776d4a990445b11e5f4c618930dacc8c79d",
        "installed_path": "node_modules/.pnpm/remark-gfm@4.0.1_supports-color@8.1.1/node_modules/remark-gfm"
      },
      {
        "importer": "apps/mobile",
        "name": "remark-parse",
        "version": "11.0.0",
        "package_json_sha256": "47be70916ff853a6c35d8d858844c7b104d100f70999d579884859cf8d88a50c",
        "installed_path": "node_modules/.pnpm/remark-parse@11.0.0_supports-color@8.1.1/node_modules/remark-parse"
      },
      {
        "importer": "apps/mobile",
        "name": "tailwind-merge",
        "version": "3.6.0",
        "package_json_sha256": "dd8a34386cdd58744a48027a30fc75103d8bf246cbbb4aa90f0b2333b25818b6",
        "installed_path": "node_modules/.pnpm/tailwind-merge@3.6.0/node_modules/tailwind-merge"
      },
      {
        "importer": "apps/mobile",
        "name": "tailwindcss",
        "version": "4.3.3",
        "package_json_sha256": "3dc86b46c511947ca00838aa3f1776243abe923ac347c092e60a0cbc7ae68559",
        "installed_path": "node_modules/.pnpm/tailwindcss@4.3.3/node_modules/tailwindcss"
      },
      {
        "importer": "apps/mobile",
        "name": "unified",
        "version": "11.0.5",
        "package_json_sha256": "f91a44220f8b7c4a4de6ebaab6fc23b92d29a95cb7e5e6a7f0f24d199779fbad",
        "installed_path": "node_modules/.pnpm/unified@11.0.5/node_modules/unified"
      },
      {
        "importer": "apps/mobile",
        "name": "uniwind",
        "version": "1.13.2",
        "package_json_sha256": "b752a91b07c2961316a3180b2f0ee41038c7b4906258cf3fb3a4392b70b3860d",
        "installed_path": "node_modules/.pnpm/uniwind@1.13.2_@expo+metro-config@58.0.21_bufferutil@4.1.0_expo@58.0.23_supports-color@_58be8f3d69f7350457dd0fe832c0cc77/node_modules/uniwind"
      },
      {
        "importer": "apps/server",
        "name": "@anthropic-ai/claude-agent-sdk",
        "version": "0.3.321",
        "package_json_sha256": "b2e2de05b39aad8a090c5b11c51ccf021e98ac7e781e696c7062001bf383f7e4",
        "installed_path": "node_modules/.pnpm/@anthropic-ai+claude-agent-sdk@0.3.321_@anthropic-ai+sdk@0.93.0_zod@4.6.7__@modelcontex_38f3fb20daecd36772d693f4f262e843/node_modules/@anthropic-ai/claude-agent-sdk"
      },
      {
        "importer": "apps/server",
        "name": "@cursor/sdk",
        "version": "1.2.0",
        "package_json_sha256": "55a97a0dbb3adb899c4b8ec07b306d5d0e226d03ea4f42f8a1dfc30b9db98dcd",
        "installed_path": "node_modules/.pnpm/@cursor+sdk@1.2.0_patch_hash=57f502128bf6accd976963b126e227c86a45d815a53a8dc450461beae3bed4a4_zod@4.6.7/node_modules/@cursor/sdk"
      },
      {
        "importer": "apps/server",
        "name": "@effect/graphql-generator",
        "version": "4.1.2",
        "package_json_sha256": "4940d91f457803adfc41e4533d83beaaafa9392144dff0a5a15ccf70a6ce8c23",
        "installed_path": "node_modules/.pnpm/@effect+graphql-generator@4.1.2_@effect+platform-node@4.1.2_bufferutil@4.1.0_effect@4.1_8afd10d0c5d2f7e73b67e0d1a4ca0336/node_modules/@effect/graphql-generator"
      },
      {
        "importer": "apps/server",
        "name": "@effect/platform-node",
        "version": "4.1.2",
        "package_json_sha256": "2901f7c08e6011794c624e346b19f85a6b455338c3991578407c3028bd64800e",
        "installed_path": "node_modules/.pnpm/@effect+platform-node@4.1.2_bufferutil@4.1.0_effect@4.1.3_redis@6.2.1_utf-8-validate@6.0.6/node_modules/@effect/platform-node"
      },
      {
        "importer": "apps/server",
        "name": "@effect/platform-node-shared",
        "version": "4.1.2",
        "package_json_sha256": "468eaad86adb8ab70c025deb373f4c31e75ea0c19eadde1c15c114e99a372d66",
        "installed_path": "node_modules/.pnpm/@effect+platform-node-shared@4.1.2_bufferutil@4.1.0_effect@4.1.3_utf-8-validate@6.0.6/node_modules/@effect/platform-node-shared"
      },
      {
        "importer": "apps/server",
        "name": "@effect/vitest",
        "version": "4.1.2",
        "package_json_sha256": "63fe8c287b8aa7420363f515f1d6330cfa5574430af94832dab4447afadcfc71",
        "installed_path": "node_modules/.pnpm/@effect+vitest@4.1.2_patch_hash=299510b71c36537a832a67e9d160a5f112a5f326a29e95c41cb45fc_81d3dd1e682774f4c17d7f713915765f/node_modules/@effect/vitest"
      },
      {
        "importer": "apps/server",
        "name": "@ff-labs/fff-node",
        "version": "0.11.0",
        "package_json_sha256": "ba3162477649ba95e1c4efcb38344c3fb43dba889fc96c406bec5889cca37ae6",
        "installed_path": "node_modules/.pnpm/@ff-labs+fff-node@0.11.0_patch_hash=3be7107340e5f388114da259637828cd47f2b32eb8ae572440715c4e38cffe6e/node_modules/@ff-labs/fff-node"
      },
      {
        "importer": "apps/server",
        "name": "@handy-computer/models",
        "version": "0.2.3",
        "package_json_sha256": "009092fe551068dde2e514777b40ece6c253c6c6bbaad7881746b983f04d5ef0",
        "installed_path": "node_modules/.pnpm/@handy-computer+models@0.2.3/node_modules/@handy-computer/models"
      },
      {
        "importer": "apps/server",
        "name": "@muse-code/sdk",
        "version": "1.4.6",
        "package_json_sha256": "44d2806ed5a24e8ee6aaacaa6259f2a7660ee5b34d53875fd97960d3e5a8b4ef",
        "installed_path": "node_modules/.pnpm/@muse-code+sdk@1.4.6_patch_hash=7b495b607fc5d76b444c7c4d58821e839726a30e6f3c53564f0d59f2d5b42101_@types+node@24.12.4/node_modules/@muse-code/sdk"
      },
      {
        "importer": "apps/server",
        "name": "@napi-rs/keyring",
        "version": "1.3.0",
        "package_json_sha256": "21c83c2e09639253133bd17d9f1832aa46cd9087850cb9d5ede81de1002ad242",
        "installed_path": "node_modules/.pnpm/@napi-rs+keyring@1.3.0/node_modules/@napi-rs/keyring"
      },
      {
        "importer": "apps/server",
        "name": "@opencode-ai/sdk",
        "version": "1.15.13",
        "package_json_sha256": "389f3fe4b859309ff51efbe8253c1968fecc4e9d148dfd555b4d6bcfd3e20fb5",
        "installed_path": "node_modules/.pnpm/@opencode-ai+sdk@1.15.13/node_modules/@opencode-ai/sdk"
      },
      {
        "importer": "apps/server",
        "name": "@types/node",
        "version": "24.12.4",
        "package_json_sha256": "456b1366f1966515c4dfec48446c82275502a2d5ea7cfbc74874323b39e3776f",
        "installed_path": "node_modules/.pnpm/@types+node@24.12.4/node_modules/@types/node"
      },
      {
        "importer": "apps/server",
        "name": "@types/proper-lockfile",
        "version": "4.1.4",
        "package_json_sha256": "892bde4e440d1536c07410155f8f7c4776d6d825c931fa34d5d04b8f0a9c02f5",
        "installed_path": "node_modules/.pnpm/@types+proper-lockfile@4.1.4/node_modules/@types/proper-lockfile"
      },
      {
        "importer": "apps/server",
        "name": "@types/yauzl",
        "version": "3.4.0",
        "package_json_sha256": "3ccc141e21141f3fc2a7e562c39950cad70cb11aeb3f16e8065912c1f38bcc82",
        "installed_path": "node_modules/.pnpm/@types+yauzl@3.4.0/node_modules/@types/yauzl"
      },
      {
        "importer": "apps/server",
        "name": "character-entities",
        "version": "2.0.2",
        "package_json_sha256": "3eaa974f1a9ede7187797d85eb1c799616144cd5ff75d094d30a44bec7d07d88",
        "installed_path": "node_modules/.pnpm/character-entities@2.0.2/node_modules/character-entities"
      },
      {
        "importer": "apps/server",
        "name": "diff",
        "version": "8.0.3",
        "package_json_sha256": "35b083dc3430465fbe066129e12debeb5416474e1db71abf7a8db9997789aeed",
        "installed_path": "node_modules/.pnpm/diff@8.0.3/node_modules/diff"
      },
      {
        "importer": "apps/server",
        "name": "effect",
        "version": "4.1.3",
        "package_json_sha256": "8ae4c5cf40f75346e2ab4dcacb692a98a6ddd814ecc5ffad27db087d6cfa3a9f",
        "installed_path": "node_modules/.pnpm/effect@4.1.3/node_modules/effect"
      },
      {
        "importer": "apps/server",
        "name": "ffi-rs",
        "version": "1.3.2",
        "package_json_sha256": "a3f76613fbce43e44ba371ef743a72c6f3242f28a533f909140b402dd24a261f",
        "installed_path": "node_modules/.pnpm/ffi-rs@1.3.2/node_modules/ffi-rs"
      },
      {
        "importer": "apps/server",
        "name": "graphql",
        "version": "16.14.1",
        "package_json_sha256": "ec4dc55bfab39edf6f772b0fbd8682c1dc65ec4387538a75e63dbc57190e4c9a",
        "installed_path": "node_modules/.pnpm/graphql@16.14.1/node_modules/graphql"
      },
      {
        "importer": "apps/server",
        "name": "node-pty",
        "version": "1.2.0-beta.15",
        "package_json_sha256": "f4a19bbc7cf4c2e35c081e6a18a3d11d21c54c2f3cc25bfe48142742a781b71d",
        "installed_path": "node_modules/.pnpm/node-pty@1.2.0-beta.15_patch_hash=f1e680afec85f650699ea756f91f469844ec4c976f4f168492a45c6b3f67d651/node_modules/node-pty"
      },
      {
        "importer": "apps/server",
        "name": "playwright-core",
        "version": "1.64.1",
        "package_json_sha256": "8aa1c9863fa8dea324e674254158cdc79440f4124ef2d84d38053013541cb7d6",
        "installed_path": "node_modules/.pnpm/playwright-core@1.64.1/node_modules/playwright-core"
      },
      {
        "importer": "apps/server",
        "name": "proper-lockfile",
        "version": "4.1.2",
        "package_json_sha256": "23888ecc7abd83a8e98e132da556eda2172792cc04c4e6d157b590667802bd2a",
        "installed_path": "node_modules/.pnpm/proper-lockfile@4.1.2/node_modules/proper-lockfile"
      },
      {
        "importer": "apps/server",
        "name": "saxes",
        "version": "6.0.0",
        "package_json_sha256": "32052572b41c2a890ed0854798c48454cc5991dcaafe5fb1718a4253046acfd3",
        "installed_path": "node_modules/.pnpm/saxes@6.0.0/node_modules/saxes"
      },
      {
        "importer": "apps/server",
        "name": "stream-chain",
        "version": "4.2.5",
        "package_json_sha256": "cd1b7376663c88e3dbb321be142253529b9d41f32c1e980ea92c535b934c6941",
        "installed_path": "node_modules/.pnpm/stream-chain@4.2.5/node_modules/stream-chain"
      },
      {
        "importer": "apps/server",
        "name": "stream-json",
        "version": "3.7.0",
        "package_json_sha256": "9176f5b9015cc834212dc64b5d4e0698c6e309037b622b3bdd5b17aa5d321059",
        "installed_path": "node_modules/.pnpm/stream-json@3.7.0/node_modules/stream-json"
      },
      {
        "importer": "apps/server",
        "name": "transcribe-cpp",
        "version": "0.4.1",
        "package_json_sha256": "06a8cfd522f531cc1f0a82f8db85c6ba1d5969f67512eb7f872f7398140640dd",
        "installed_path": "node_modules/.pnpm/transcribe-cpp@0.4.1/node_modules/transcribe-cpp"
      },
      {
        "importer": "apps/server",
        "name": "undici",
        "version": "8.12.4",
        "package_json_sha256": "1c0aa5632e07578a71cd3c31fe7a75c85e7d0071ec5238a302d4b5a11aeed5b7",
        "installed_path": "node_modules/.pnpm/undici@8.12.4/node_modules/undici"
      },
      {
        "importer": "apps/server",
        "name": "vite-plus",
        "version": "1.4.0",
        "package_json_sha256": "a2901e42e05a5f1c162b994ba85bfbad074a2f8921d129995b019e0bd48c9c09",
        "installed_path": "node_modules/.pnpm/vite-plus@1.4.0_@astrojs+compiler-rs@0.5.1_@types+node@24.12.4_@vitest+browser-playwrig_71b1ef4e5049c7accee71dd249ba4133/node_modules/vite-plus"
      },
      {
        "importer": "apps/server",
        "name": "yaml",
        "version": "2.9.0",
        "package_json_sha256": "20b8b197cbd10dad245d45e463dfe58e4c8c25a47e24bc4256ad9ab58bf35683",
        "installed_path": "node_modules/.pnpm/yaml@2.9.0/node_modules/yaml"
      },
      {
        "importer": "apps/server",
        "name": "yauzl",
        "version": "3.4.0",
        "package_json_sha256": "d7d5418b74b185df4ad276b73cf1e36040dd417d22520354e609e2748a29fcbd",
        "installed_path": "node_modules/.pnpm/yauzl@3.4.0/node_modules/yauzl"
      },
      {
        "importer": "apps/server",
        "name": "zod",
        "version": "4.6.7",
        "package_json_sha256": "c2d190d9ee4e0bdb60332aaa2130a6a98d65ddb903fe1d29248b15de57832c45",
        "installed_path": "node_modules/.pnpm/zod@4.6.7/node_modules/zod"
      },
      {
        "importer": "apps/web",
        "name": "@base-ui/react",
        "version": "1.9.0",
        "package_json_sha256": "29c2b0a1b941bdc5335ed31e31f40231dc0ad3b96343c92715029d18a32e42c3",
        "installed_path": "node_modules/.pnpm/@base-ui+react@1.9.0_@date-fns+tz@1.5.0_@types+react@19.3.0_date-fns@4.4.0_react-dom@19.3.0_react@19.3.0__react@19.3.0/node_modules/@base-ui/react"
      },
      {
        "importer": "apps/web",
        "name": "@betteroffice/docx",
        "version": "0.5.1",
        "package_json_sha256": "cc0cbc627cb64f872f6c2fd7f61ae30aa298f59144513fc183bce3831938da05",
        "installed_path": "node_modules/.pnpm/@betteroffice+docx@0.5.1_@betteroffice+fonts@0.4.0_@betteroffice+fonts-cjk@0.4.0_/node_modules/@betteroffice/docx"
      },
      {
        "importer": "apps/web",
        "name": "@betteroffice/fonts",
        "version": "0.4.0",
        "package_json_sha256": "ec6d356c3e3a4388da483227f909fce0d2844c6d062ca54650f4dfd545c071df",
        "installed_path": "node_modules/.pnpm/@betteroffice+fonts@0.4.0_@betteroffice+fonts-cjk@0.4.0/node_modules/@betteroffice/fonts"
      },
      {
        "importer": "apps/web",
        "name": "@betteroffice/fonts-cjk",
        "version": "0.4.0",
        "package_json_sha256": "098ad782104efddf9e740e2e524f1ba0e30299b817cab613d65d616580b9365c",
        "installed_path": "node_modules/.pnpm/@betteroffice+fonts-cjk@0.4.0/node_modules/@betteroffice/fonts-cjk"
      },
      {
        "importer": "apps/web",
        "name": "@betteroffice/pptx",
        "version": "0.5.1",
        "package_json_sha256": "9ea37b6e865dc7680519dcfcae966a79afcf4e32c90fb78c270cced36b4f85aa",
        "installed_path": "node_modules/.pnpm/@betteroffice+pptx@0.5.1/node_modules/@betteroffice/pptx"
      },
      {
        "importer": "apps/web",
        "name": "@betteroffice/xlsx",
        "version": "0.5.1",
        "package_json_sha256": "a9bc9a76f860b68a0965c2e0b853888640009d10a445f5e7f62fe516299c7e1c",
        "installed_path": "node_modules/.pnpm/@betteroffice+xlsx@0.5.1/node_modules/@betteroffice/xlsx"
      },
      {
        "importer": "apps/web",
        "name": "@clerk/clerk-js",
        "version": "6.42.3",
        "package_json_sha256": "90d3d8ed324e9cf1bfe4ec3d31ea7adfd8ad997f766b891e8930af1df06e4f42",
        "installed_path": "node_modules/.pnpm/@clerk+clerk-js@6.42.3_react-dom@19.3.0_react@19.3.0__react@19.3.0/node_modules/@clerk/clerk-js"
      },
      {
        "importer": "apps/web",
        "name": "@clerk/electron",
        "version": "0.1.10",
        "package_json_sha256": "5907a54345f8cfccadd3c9cfa940049f7c212ff8dfc044c98fc8c4b2a86a378e",
        "installed_path": "node_modules/.pnpm/@clerk+electron@0.1.10_@clerk+electron-passkeys@0.0.3_electron-store@8.2.0_electron@44._0ba958cb374e528e7de7319d5a8ee178/node_modules/@clerk/electron"
      },
      {
        "importer": "apps/web",
        "name": "@clerk/react",
        "version": "6.18.6",
        "package_json_sha256": "2ce0f2c29eede31ea20fe63d591cac079bd5289f851ca797523852eeb7b93e3f",
        "installed_path": "node_modules/.pnpm/@clerk+react@6.18.6_react-dom@19.3.0_react@19.3.0__react@19.3.0/node_modules/@clerk/react"
      },
      {
        "importer": "apps/web",
        "name": "@daypicker/react",
        "version": "10.0.1",
        "package_json_sha256": "9c2d6a404af444395fdbf1370ac0c26f3783e6bd0a4205da15f0e61c286b6325",
        "installed_path": "node_modules/.pnpm/@daypicker+react@10.0.1_@types+react@19.3.0_react@19.3.0/node_modules/@daypicker/react"
      },
      {
        "importer": "apps/web",
        "name": "@dnd-kit/core",
        "version": "6.3.1",
        "package_json_sha256": "4da9a60c80aa9c0564d1f31ba1502058f2b84240842269c6d54801c8d3175d77",
        "installed_path": "node_modules/.pnpm/@dnd-kit+core@6.3.1_react-dom@19.3.0_react@19.3.0__react@19.3.0/node_modules/@dnd-kit/core"
      },
      {
        "importer": "apps/web",
        "name": "@dnd-kit/modifiers",
        "version": "9.0.0",
        "package_json_sha256": "03e24881bbf1ed6ea59ef748d1e6d70bd1b2841c2dd4119a265a6e7e241b6b0c",
        "installed_path": "node_modules/.pnpm/@dnd-kit+modifiers@9.0.0_@dnd-kit+core@6.3.1_react-dom@19.3.0_react@19.3.0__react@19.3.0__react@19.3.0/node_modules/@dnd-kit/modifiers"
      },
      {
        "importer": "apps/web",
        "name": "@dnd-kit/sortable",
        "version": "10.0.0",
        "package_json_sha256": "c3b9c43549eb627d12edae5d2e1ae38e334fee774ddfe20acf1008b915f0d565",
        "installed_path": "node_modules/.pnpm/@dnd-kit+sortable@10.0.0_@dnd-kit+core@6.3.1_react-dom@19.3.0_react@19.3.0__react@19.3.0__react@19.3.0/node_modules/@dnd-kit/sortable"
      },
      {
        "importer": "apps/web",
        "name": "@dnd-kit/utilities",
        "version": "3.2.2",
        "package_json_sha256": "c1f7cb1b258509c1fdccf9b23d072f0b81fc56498be0a6334189342b5cb8a477",
        "installed_path": "node_modules/.pnpm/@dnd-kit+utilities@3.2.2_react@19.3.0/node_modules/@dnd-kit/utilities"
      },
      {
        "importer": "apps/web",
        "name": "@effect/atom-react",
        "version": "4.1.2",
        "package_json_sha256": "2fd58077f903dd8bd7c4936ec0f24a705c856d8f1beeef3c834a209bcca929bd",
        "installed_path": "node_modules/.pnpm/@effect+atom-react@4.1.2_effect@4.1.3_react@19.3.0_scheduler@0.28.0/node_modules/@effect/atom-react"
      },
      {
        "importer": "apps/web",
        "name": "@effect/platform-node",
        "version": "4.1.2",
        "package_json_sha256": "2901f7c08e6011794c624e346b19f85a6b455338c3991578407c3028bd64800e",
        "installed_path": "node_modules/.pnpm/@effect+platform-node@4.1.2_bufferutil@4.1.0_effect@4.1.3_redis@6.2.1_utf-8-validate@6.0.6/node_modules/@effect/platform-node"
      },
      {
        "importer": "apps/web",
        "name": "@effect/vitest",
        "version": "4.1.2",
        "package_json_sha256": "63fe8c287b8aa7420363f515f1d6330cfa5574430af94832dab4447afadcfc71",
        "installed_path": "node_modules/.pnpm/@effect+vitest@4.1.2_patch_hash=299510b71c36537a832a67e9d160a5f112a5f326a29e95c41cb45fc_81d3dd1e682774f4c17d7f713915765f/node_modules/@effect/vitest"
      },
      {
        "importer": "apps/web",
        "name": "@fontsource-variable/inter",
        "version": "5.3.0",
        "package_json_sha256": "1075dffa0a9ec739bdee2af296b481d2867d305d41be9e0439ca3313d3ad1298",
        "installed_path": "node_modules/.pnpm/@fontsource-variable+inter@5.3.0/node_modules/@fontsource-variable/inter"
      },
      {
        "importer": "apps/web",
        "name": "@legendapp/list",
        "version": "3.7.2",
        "package_json_sha256": "56c58e745cda0a48dd12b18ea19ab98b57de0e3559127c7fe6ec967ec4259222",
        "installed_path": "node_modules/.pnpm/@legendapp+list@3.7.2_patch_hash=3c68607b8bb7a531873bcbe0b197d163ef1fdb4d4cf52a4ddf9d2b_1a8bdca797f182e303220354dc2ccdc2/node_modules/@legendapp/list"
      },
      {
        "importer": "apps/web",
        "name": "@noble/hashes",
        "version": "1.8.0",
        "package_json_sha256": "7c4657c5e616c22cefa2691cc30670824a639dc71d97bf83925be2d239dc60e3",
        "installed_path": "node_modules/.pnpm/@noble+hashes@1.8.0/node_modules/@noble/hashes"
      },
      {
        "importer": "apps/web",
        "name": "@pierre/diffs",
        "version": "1.7.0-beta.3",
        "package_json_sha256": "0663dc59ce053c8be045cf1edc1489d94fab003735e2c74a7f224723b4c0d46c",
        "installed_path": "node_modules/.pnpm/@pierre+diffs@1.7.0-beta.3_patch_hash=4a64f63a0def94c5add9d86d70560d26d6857e1f515013386_8cf7878feba9a5fb545c4167fb5428f0/node_modules/@pierre/diffs"
      },
      {
        "importer": "apps/web",
        "name": "@pierre/trees",
        "version": "1.0.0-beta.6",
        "package_json_sha256": "d1899e2d7fe1ad3e97ccff57dd93bf81e6dd7904e3872862d812645b4171e1f7",
        "installed_path": "node_modules/.pnpm/@pierre+trees@1.0.0-beta.6_@pierre+theme@2.0.0_@shikijs+themes@4.2.0_react-dom@19.3.0_r_6f89bc20e49cc599ef547096bbeb5e4e/node_modules/@pierre/trees"
      },
      {
        "importer": "apps/web",
        "name": "@tailwindcss/vite",
        "version": "4.3.3",
        "package_json_sha256": "cba2bb8613106ca608bbd757998b2cf56a464584e3848310338fe3fe3b4761aa",
        "installed_path": "node_modules/.pnpm/@tailwindcss+vite@4.3.3_@voidzero-dev+vite-plus-core@1.4.0_@types+node@24.12.4_@volar+t_df728cce66187167ef685f8c06f3867b/node_modules/@tailwindcss/vite"
      },
      {
        "importer": "apps/web",
        "name": "@tanstack/react-pacer",
        "version": "0.19.4",
        "package_json_sha256": "2f66f2865f69b7e6a8bbef9965b5de36d92935144995d668d292d7458757c2da",
        "installed_path": "node_modules/.pnpm/@tanstack+react-pacer@0.19.4_react-dom@19.3.0_react@19.3.0__react@19.3.0/node_modules/@tanstack/react-pacer"
      },
      {
        "importer": "apps/web",
        "name": "@tanstack/react-router",
        "version": "1.170.10",
        "package_json_sha256": "7c1b6aa201c5b12eec0d740d1ab35d7c1c2b763afb041c8f7a8abc307de583b5",
        "installed_path": "node_modules/.pnpm/@tanstack+react-router@1.170.10_react-dom@19.3.0_react@19.3.0__react@19.3.0/node_modules/@tanstack/react-router"
      },
      {
        "importer": "apps/web",
        "name": "@tanstack/router-plugin",
        "version": "1.168.13",
        "package_json_sha256": "7099e78d9beb087c2f5a3c8dfdd9c6bc69a6dd231f51ed449386b3ea48763083",
        "installed_path": "node_modules/.pnpm/@tanstack+router-plugin@1.168.13_@tanstack+react-router@1.170.10_react-dom@19.3.0_react_6a4d2e9518a234e57ef99c3fe16f842b/node_modules/@tanstack/router-plugin"
      },
      {
        "importer": "apps/web",
        "name": "@tiptap/core",
        "version": "3.31.3",
        "package_json_sha256": "4d3d4d882970f7d12160073a80b866d6e9558df9f1aaf8479c4002e61946442d",
        "installed_path": "node_modules/.pnpm/@tiptap+core@3.31.3_@tiptap+pm@3.31.3/node_modules/@tiptap/core"
      },
      {
        "importer": "apps/web",
        "name": "@tiptap/extension-blockquote",
        "version": "3.31.3",
        "package_json_sha256": "c429d356e16951558c3e47f0b6b769ea06b8512172ccd774bb43f713c4053e08",
        "installed_path": "node_modules/.pnpm/@tiptap+extension-blockquote@3.31.3_@tiptap+core@3.31.3_@tiptap+pm@3.31.3__@tiptap+pm@3.31.3/node_modules/@tiptap/extension-blockquote"
      },
      {
        "importer": "apps/web",
        "name": "@tiptap/extension-bold",
        "version": "3.31.3",
        "package_json_sha256": "d9c58aab2074c6d1b4077bed94c1407635fd67d263eaa35b8816494e59d09717",
        "installed_path": "node_modules/.pnpm/@tiptap+extension-bold@3.31.3_@tiptap+core@3.31.3_@tiptap+pm@3.31.3_/node_modules/@tiptap/extension-bold"
      },
      {
        "importer": "apps/web",
        "name": "@tiptap/extension-code",
        "version": "3.31.3",
        "package_json_sha256": "e22262aed433c7fd8667a24a276e9c5576f3a4407a4afbe124f3f35632b58403",
        "installed_path": "node_modules/.pnpm/@tiptap+extension-code@3.31.3_@tiptap+core@3.31.3_@tiptap+pm@3.31.3_/node_modules/@tiptap/extension-code"
      },
      {
        "importer": "apps/web",
        "name": "@tiptap/extension-code-block",
        "version": "3.31.3",
        "package_json_sha256": "70eacb9e1e5f454fa2c3e02bce60edd2e8b49870ee75fdfcb60789f9c6b88f73",
        "installed_path": "node_modules/.pnpm/@tiptap+extension-code-block@3.31.3_@tiptap+core@3.31.3_@tiptap+pm@3.31.3__@tiptap+pm@3.31.3/node_modules/@tiptap/extension-code-block"
      },
      {
        "importer": "apps/web",
        "name": "@tiptap/extension-heading",
        "version": "3.31.3",
        "package_json_sha256": "04ac53b5079b6799b3e5b9fcb8ef3bd84c6694a71cb77e41bbbf6c2c4b3c970a",
        "installed_path": "node_modules/.pnpm/@tiptap+extension-heading@3.31.3_@tiptap+core@3.31.3_@tiptap+pm@3.31.3_/node_modules/@tiptap/extension-heading"
      },
      {
        "importer": "apps/web",
        "name": "@tiptap/extension-horizontal-rule",
        "version": "3.31.3",
        "package_json_sha256": "0a3b8a05d04e73435a8f835563ba57681f9fa754e0e8a1ce54c7214330ea80d9",
        "installed_path": "node_modules/.pnpm/@tiptap+extension-horizontal-rule@3.31.3_@tiptap+core@3.31.3_@tiptap+pm@3.31.3__@tiptap+pm@3.31.3/node_modules/@tiptap/extension-horizontal-rule"
      },
      {
        "importer": "apps/web",
        "name": "@tiptap/extension-italic",
        "version": "3.31.3",
        "package_json_sha256": "87a9cd0cb9d493dbca3bf1995df21c0297ad61f078c42275d15e9dbc646947a8",
        "installed_path": "node_modules/.pnpm/@tiptap+extension-italic@3.31.3_@tiptap+core@3.31.3_@tiptap+pm@3.31.3_/node_modules/@tiptap/extension-italic"
      },
      {
        "importer": "apps/web",
        "name": "@tiptap/extension-list",
        "version": "3.31.3",
        "package_json_sha256": "41819397465adb3b6727fd528ad0b916850ab4e84cccd87478cec9882afc7870",
        "installed_path": "node_modules/.pnpm/@tiptap+extension-list@3.31.3_@tiptap+core@3.31.3_@tiptap+pm@3.31.3__@tiptap+pm@3.31.3/node_modules/@tiptap/extension-list"
      },
      {
        "importer": "apps/web",
        "name": "@tiptap/extension-strike",
        "version": "3.31.3",
        "package_json_sha256": "6681d8a4a5f02993e76727374b5ebbd578e86a3175b547bbce8fed7663ec680e",
        "installed_path": "node_modules/.pnpm/@tiptap+extension-strike@3.31.3_@tiptap+core@3.31.3_@tiptap+pm@3.31.3_/node_modules/@tiptap/extension-strike"
      },
      {
        "importer": "apps/web",
        "name": "@tiptap/extension-task-item",
        "version": "3.31.3",
        "package_json_sha256": "eef0aad4b4afef2e03bfea3c422e38d5653db5ff0aa8961cf78a0b012f1d2bc4",
        "installed_path": "node_modules/.pnpm/@tiptap+extension-task-item@3.31.3_@tiptap+extension-list@3.31.3_@tiptap+core@3.31.3_@t_57c8db10f93f71c9bed458e47d8da805/node_modules/@tiptap/extension-task-item"
      },
      {
        "importer": "apps/web",
        "name": "@tiptap/extension-task-list",
        "version": "3.31.3",
        "package_json_sha256": "aef2b2933a42edc711935584bf779d10b4149575c5c655a2ff3b92ba8ba9707c",
        "installed_path": "node_modules/.pnpm/@tiptap+extension-task-list@3.31.3_@tiptap+extension-list@3.31.3_@tiptap+core@3.31.3_@t_9894ed369c5424845246861d2991f48e/node_modules/@tiptap/extension-task-list"
      },
      {
        "importer": "apps/web",
        "name": "@tiptap/pm",
        "version": "3.31.3",
        "package_json_sha256": "0adcd71b28162cc67300204a46ab8c8d3ffd0e461f47fdbc36bdbf7b41bd0dfe",
        "installed_path": "node_modules/.pnpm/@tiptap+pm@3.31.3/node_modules/@tiptap/pm"
      },
      {
        "importer": "apps/web",
        "name": "@tiptap/react",
        "version": "3.31.3",
        "package_json_sha256": "3775285794965ac67b97d0617f9da74655b85e38a2497d6083b6b19992fee2da",
        "installed_path": "node_modules/.pnpm/@tiptap+react@3.31.3_@floating-ui+dom@1.8.0_@tiptap+core@3.31.3_@tiptap+pm@3.31.3__@tip_451c1aef508ab55f168609dfddc3b08d/node_modules/@tiptap/react"
      },
      {
        "importer": "apps/web",
        "name": "@tiptap/starter-kit",
        "version": "3.31.3",
        "package_json_sha256": "ca8c06cf665bb3f0a893b081fbdc2e3c92636b92af847549e83d249444b79cd5",
        "installed_path": "node_modules/.pnpm/@tiptap+starter-kit@3.31.3/node_modules/@tiptap/starter-kit"
      },
      {
        "importer": "apps/web",
        "name": "@types/canvas-confetti",
        "version": "1.9.0",
        "package_json_sha256": "df31476d1c60f4d08876d6412d8aae96d298b238a79ad4331ebf50f77e350159",
        "installed_path": "node_modules/.pnpm/@types+canvas-confetti@1.9.0/node_modules/@types/canvas-confetti"
      },
      {
        "importer": "apps/web",
        "name": "@types/compression",
        "version": "1.8.1",
        "package_json_sha256": "125da80c0d58e7b4b1b3d28aabfd193d3ce08bd7d0c19725345507446c5aa0ee",
        "installed_path": "node_modules/.pnpm/@types+compression@1.8.1/node_modules/@types/compression"
      },
      {
        "importer": "apps/web",
        "name": "@types/culori",
        "version": "4.0.1",
        "package_json_sha256": "4dcdb895a307447fbd13b743b870aa87b1f2a17c3d0212d8ab6a22c472b333a9",
        "installed_path": "node_modules/.pnpm/@types+culori@4.0.1/node_modules/@types/culori"
      },
      {
        "importer": "apps/web",
        "name": "@types/hast",
        "version": "3.0.5",
        "package_json_sha256": "403fd6e55486fc6d7ebf23c0642649421ca48a291296ba467d298e391e327466",
        "installed_path": "node_modules/.pnpm/@types+hast@3.0.5/node_modules/@types/hast"
      },
      {
        "importer": "apps/web",
        "name": "@types/mdast",
        "version": "4.0.4",
        "package_json_sha256": "5a41865d64d4cedba58313fad775cf56bd0474d724343172bcea9f8ad24db563",
        "installed_path": "node_modules/.pnpm/@types+mdast@4.0.4/node_modules/@types/mdast"
      },
      {
        "importer": "apps/web",
        "name": "@types/react",
        "version": "19.3.0",
        "package_json_sha256": "505c0df4cd73d6a02c946bd9b81451584bd9c83ea72d75cff9b826efceaa19c2",
        "installed_path": "node_modules/.pnpm/@types+react@19.3.0/node_modules/@types/react"
      },
      {
        "importer": "apps/web",
        "name": "@types/react-dom",
        "version": "19.3.0",
        "package_json_sha256": "4a2052bb362c34f1d39cfe0818b6fe01a9f988b609e8b7e4832aff7dbf2f7180",
        "installed_path": "node_modules/.pnpm/@types+react-dom@19.3.0_@types+react@19.3.0/node_modules/@types/react-dom"
      },
      {
        "importer": "apps/web",
        "name": "@types/sql.js",
        "version": "1.4.11",
        "package_json_sha256": "45df6db2aa8e23840351cc5c92b9591136b8eb5263c975f14645883cbb92a064",
        "installed_path": "node_modules/.pnpm/@types+sql.js@1.4.11/node_modules/@types/sql.js"
      },
      {
        "importer": "apps/web",
        "name": "@types/use-sync-external-store",
        "version": "0.0.6",
        "package_json_sha256": "2f810fd3c676283d0498be7fbd9a171ef15fb1e492346a9ec027136e25638c9d",
        "installed_path": "node_modules/.pnpm/@types+use-sync-external-store@0.0.6/node_modules/@types/use-sync-external-store"
      },
      {
        "importer": "apps/web",
        "name": "@vercel/config",
        "version": "0.3.0",
        "package_json_sha256": "39f17e576237567ed0df573d0fc929500d8c4fd3f8e362bb48f1831377cd0aab",
        "installed_path": "node_modules/.pnpm/@vercel+config@0.3.0/node_modules/@vercel/config"
      },
      {
        "importer": "apps/web",
        "name": "@vitejs/plugin-react",
        "version": "6.1.2",
        "package_json_sha256": "b40248af3bd75adf396d903d042c09ca4f585dcdd9460d51eeeeb83c01a48643",
        "installed_path": "node_modules/.pnpm/@vitejs+plugin-react@6.1.2_@voidzero-dev+vite-plus-core@1.4.0_@types+node@24.12.4_@vola_61f08f42f25db3688038ebd56cf2ad4f/node_modules/@vitejs/plugin-react"
      },
      {
        "importer": "apps/web",
        "name": "@vitest/browser-playwright",
        "version": "5.0.5",
        "package_json_sha256": "36ba0249ceec1ef7b2acc993e2c254550a27b209674b7708da88168178bc7a1f",
        "installed_path": "node_modules/.pnpm/@vitest+browser-playwright@5.0.5_@types+node@24.12.4_@volar+typescript@2.4.28_typescrip_3c15cb4ce35ad54c14bba04cbab48ad0/node_modules/@vitest/browser-playwright"
      },
      {
        "importer": "apps/web",
        "name": "canvas-confetti",
        "version": "1.9.4",
        "package_json_sha256": "a6a30a4de45b8b0cfb3575a792f477efa7fee2514ba30d7f5c4de1bb139c897a",
        "installed_path": "node_modules/.pnpm/canvas-confetti@1.9.4/node_modules/canvas-confetti"
      },
      {
        "importer": "apps/web",
        "name": "class-variance-authority",
        "version": "0.7.1",
        "package_json_sha256": "f487885eb010b36aec829ab8fb5fc845918006c4633e3c88c750e73bd35c6381",
        "installed_path": "node_modules/.pnpm/class-variance-authority@0.7.1/node_modules/class-variance-authority"
      },
      {
        "importer": "apps/web",
        "name": "compression",
        "version": "1.8.2",
        "package_json_sha256": "0b7fae36342883daa0f2ffeb91de83d702e8e02e7186feb2d6f62e0b25d37f0a",
        "installed_path": "node_modules/.pnpm/compression@1.8.2_supports-color@8.1.1/node_modules/compression"
      },
      {
        "importer": "apps/web",
        "name": "culori",
        "version": "4.0.2",
        "package_json_sha256": "1cfe84e326d4aae05edb018d34304a376eacab18b29d591aea39bea34b2fda04",
        "installed_path": "node_modules/.pnpm/culori@4.0.2/node_modules/culori"
      },
      {
        "importer": "apps/web",
        "name": "dompurify",
        "version": "3.4.17",
        "package_json_sha256": "e6235e2a233d3f5550e2be3bf826a39f4ff5180a710779c1e16dcdf4b9eb20b9",
        "installed_path": "node_modules/.pnpm/dompurify@3.4.17/node_modules/dompurify"
      },
      {
        "importer": "apps/web",
        "name": "effect",
        "version": "4.1.3",
        "package_json_sha256": "8ae4c5cf40f75346e2ab4dcacb692a98a6ddd814ecc5ffad27db087d6cfa3a9f",
        "installed_path": "node_modules/.pnpm/effect@4.1.3/node_modules/effect"
      },
      {
        "importer": "apps/web",
        "name": "entities",
        "version": "8.1.0",
        "package_json_sha256": "b6ff1175be0fa103f032d52e42af95d95c674e3cba08d93670cc8944697bcc42",
        "installed_path": "node_modules/.pnpm/entities@8.1.0/node_modules/entities"
      },
      {
        "importer": "apps/web",
        "name": "fast-xml-parser",
        "version": "5.7.3",
        "package_json_sha256": "a9165d1ed4ad2ad8ebca75206bee95b6916375eb80580c81a40a6da5229db849",
        "installed_path": "node_modules/.pnpm/fast-xml-parser@5.7.3/node_modules/fast-xml-parser"
      },
      {
        "importer": "apps/web",
        "name": "gt",
        "version": "2.27.0",
        "package_json_sha256": "556030d6491f1aa4f78cb390276c8c7040dcf81e0b98b79f160438afffa82a34",
        "installed_path": "node_modules/.pnpm/gt@2.27.0_@babel+core@7.29.7_supports-color@8.1.1__supports-color@8.1.1/node_modules/gt"
      },
      {
        "importer": "apps/web",
        "name": "gt-react",
        "version": "11.4.18",
        "package_json_sha256": "eecab1509edad243f803b1cf474e2cc35ca4102819e3e667943107f301582b30",
        "installed_path": "node_modules/.pnpm/gt-react@11.4.18_react-dom@19.3.0_react@19.3.0__react@19.3.0/node_modules/gt-react"
      },
      {
        "importer": "apps/web",
        "name": "hast-util-to-html",
        "version": "9.0.5",
        "package_json_sha256": "e79f8c1a0d5dd456a581956f5d85fa6e65edddb20f2950bfa9d7b3920f5b3f39",
        "installed_path": "node_modules/.pnpm/hast-util-to-html@9.0.5/node_modules/hast-util-to-html"
      },
      {
        "importer": "apps/web",
        "name": "hast-util-to-jsx-runtime",
        "version": "2.3.6",
        "package_json_sha256": "30dc325d26a45aed9ca3c9c686249cc40f9e234019d220dd954dad488d9fab49",
        "installed_path": "node_modules/.pnpm/hast-util-to-jsx-runtime@2.3.6_supports-color@8.1.1/node_modules/hast-util-to-jsx-runtime"
      },
      {
        "importer": "apps/web",
        "name": "heic-to",
        "version": "1.5.2",
        "package_json_sha256": "4ac48cd4c799e3137595728b90a950b8ef7b1d3c6680c5fbfa27ca8aea9dac29",
        "installed_path": "node_modules/.pnpm/heic-to@1.5.2/node_modules/heic-to"
      },
      {
        "importer": "apps/web",
        "name": "html-url-attributes",
        "version": "3.0.1",
        "package_json_sha256": "0bd29e79398437b88c9647434c40c48168d87b22f7448f5f083f4f2d8ab063d8",
        "installed_path": "node_modules/.pnpm/html-url-attributes@3.0.1/node_modules/html-url-attributes"
      },
      {
        "importer": "apps/web",
        "name": "jsonc-parser",
        "version": "3.3.1",
        "package_json_sha256": "a7a9192caaac00d9330592f4fd572908bee037518128a0fc3db96d2cd652e2b5",
        "installed_path": "node_modules/.pnpm/jsonc-parser@3.3.1/node_modules/jsonc-parser"
      },
      {
        "importer": "apps/web",
        "name": "jszip",
        "version": "3.10.1",
        "package_json_sha256": "83569b5b130b5ec27ae281ed80420ad364baf1bf64cb82e6ac8fb891e1b4ec4c",
        "installed_path": "node_modules/.pnpm/jszip@3.10.1/node_modules/jszip"
      },
      {
        "importer": "apps/web",
        "name": "katex",
        "version": "0.18.10",
        "package_json_sha256": "ad36604c3a1bbef9c09d0be004a35e23ac763b105d7de1b50c1ffa1f9ace5fe7",
        "installed_path": "node_modules/.pnpm/katex@0.18.10/node_modules/katex"
      },
      {
        "importer": "apps/web",
        "name": "lucide-react",
        "version": "0.564.0",
        "package_json_sha256": "505b10702c7c576341aa1bd210588adee9a8548173f5d4a8fbb07d0e2204d23b",
        "installed_path": "node_modules/.pnpm/lucide-react@0.564.0_react@19.3.0/node_modules/lucide-react"
      },
      {
        "importer": "apps/web",
        "name": "mdast-util-from-markdown",
        "version": "2.0.3",
        "package_json_sha256": "4f7c4700c78d6781af46eb12b2f908b0503d8beefa8b2cea0fbfe9de8444e438",
        "installed_path": "node_modules/.pnpm/mdast-util-from-markdown@2.0.3_supports-color@8.1.1/node_modules/mdast-util-from-markdown"
      },
      {
        "importer": "apps/web",
        "name": "micromark-util-combine-extensions",
        "version": "2.0.1",
        "package_json_sha256": "43686ee41cc83e2460aaa49821d7f36b0b7fd525e88b253e10b1556520196554",
        "installed_path": "node_modules/.pnpm/micromark-util-combine-extensions@2.0.1/node_modules/micromark-util-combine-extensions"
      },
      {
        "importer": "apps/web",
        "name": "micromark-util-types",
        "version": "2.0.2",
        "package_json_sha256": "4bf761498edc00e674903db57fc6a8cf478677363adc776b8ac115771e791cd3",
        "installed_path": "node_modules/.pnpm/micromark-util-types@2.0.2/node_modules/micromark-util-types"
      },
      {
        "importer": "apps/web",
        "name": "oxc-transform-react",
        "version": "0.152.0",
        "package_json_sha256": "a1ad4ef48535b667f4e902bec7f39deb49fbf22988ddc73adb901c5e85769e43",
        "installed_path": "node_modules/.pnpm/oxc-transform-react@0.152.0/node_modules/oxc-transform-react"
      },
      {
        "importer": "apps/web",
        "name": "pdfjs-dist",
        "version": "6.4.299",
        "package_json_sha256": "8103b756525a79ec119558e9796062228290acfd5178a6b7fc93e6979511f604",
        "installed_path": "node_modules/.pnpm/pdfjs-dist@6.4.299/node_modules/pdfjs-dist"
      },
      {
        "importer": "apps/web",
        "name": "pele",
        "version": "1.8.0",
        "package_json_sha256": "19123c371b0d9e2d006be133e18866abb94b7d8189e5ae1bff651f79ef8c9b6d",
        "installed_path": "node_modules/.pnpm/pele@1.8.0/node_modules/pele"
      },
      {
        "importer": "apps/web",
        "name": "playwright",
        "version": "1.64.1",
        "package_json_sha256": "313d23ce667d93962d3a1ab4be80908cefe840e4d9e48f1cd5863b91f65e8e39",
        "installed_path": "node_modules/.pnpm/playwright@1.64.1/node_modules/playwright"
      },
      {
        "importer": "apps/web",
        "name": "react",
        "version": "19.3.0",
        "package_json_sha256": "6e003e4e9ed25afa7fdd55613f8aa877cefa9b359d9c13f81ee704030248e24e",
        "installed_path": "node_modules/.pnpm/react@19.3.0/node_modules/react"
      },
      {
        "importer": "apps/web",
        "name": "react-dom",
        "version": "19.3.0",
        "package_json_sha256": "136d4af63de473392ea79d6a21932b0ed9eb37fe518ce70f4621250f3d79e9bb",
        "installed_path": "node_modules/.pnpm/react-dom@19.3.0_react@19.3.0/node_modules/react-dom"
      },
      {
        "importer": "apps/web",
        "name": "react-markdown",
        "version": "10.1.0",
        "package_json_sha256": "c6b7d280b5e5a6b620ad252abfd318560f2223562e67414fcc3dcd1f784e89c5",
        "installed_path": "node_modules/.pnpm/react-markdown@10.1.0_@types+react@19.3.0_react@19.3.0_supports-color@8.1.1/node_modules/react-markdown"
      },
      {
        "importer": "apps/web",
        "name": "remark-gfm",
        "version": "4.0.1",
        "package_json_sha256": "c199482a69355b610bd1ff225b097776d4a990445b11e5f4c618930dacc8c79d",
        "installed_path": "node_modules/.pnpm/remark-gfm@4.0.1_supports-color@8.1.1/node_modules/remark-gfm"
      },
      {
        "importer": "apps/web",
        "name": "remark-math",
        "version": "6.0.0",
        "package_json_sha256": "936d400d2c2a3f121c4d2b6b84b8a891af02852032b0dcb31f0407d2d6a4364f",
        "installed_path": "node_modules/.pnpm/remark-math@6.0.0_supports-color@8.1.1/node_modules/remark-math"
      },
      {
        "importer": "apps/web",
        "name": "remark-parse",
        "version": "11.0.0",
        "package_json_sha256": "47be70916ff853a6c35d8d858844c7b104d100f70999d579884859cf8d88a50c",
        "installed_path": "node_modules/.pnpm/remark-parse@11.0.0_supports-color@8.1.1/node_modules/remark-parse"
      },
      {
        "importer": "apps/web",
        "name": "remark-rehype",
        "version": "11.1.2",
        "package_json_sha256": "f9886f99f9f38652d56ca256aa713e359e085ed42f7d89fd66671b49f4b83b64",
        "installed_path": "node_modules/.pnpm/remark-rehype@11.1.2/node_modules/remark-rehype"
      },
      {
        "importer": "apps/web",
        "name": "saxes",
        "version": "6.0.0",
        "package_json_sha256": "32052572b41c2a890ed0854798c48454cc5991dcaafe5fb1718a4253046acfd3",
        "installed_path": "node_modules/.pnpm/saxes@6.0.0/node_modules/saxes"
      },
      {
        "importer": "apps/web",
        "name": "sql.js",
        "version": "1.15.0",
        "package_json_sha256": "5f0f03d61efd35dca039e7f9d05ac4601a3f713e29ed66aea3f91919e1de3962",
        "installed_path": "node_modules/.pnpm/sql.js@1.15.0/node_modules/sql.js"
      },
      {
        "importer": "apps/web",
        "name": "tailwind-merge",
        "version": "3.6.0",
        "package_json_sha256": "dd8a34386cdd58744a48027a30fc75103d8bf246cbbb4aa90f0b2333b25818b6",
        "installed_path": "node_modules/.pnpm/tailwind-merge@3.6.0/node_modules/tailwind-merge"
      },
      {
        "importer": "apps/web",
        "name": "tailwindcss",
        "version": "4.3.3",
        "package_json_sha256": "3dc86b46c511947ca00838aa3f1776243abe923ac347c092e60a0cbc7ae68559",
        "installed_path": "node_modules/.pnpm/tailwindcss@4.3.3/node_modules/tailwindcss"
      },
      {
        "importer": "apps/web",
        "name": "tiff",
        "version": "7.1.3",
        "package_json_sha256": "859efa4b6d9918ec57df1c19c2a474db5d627faf3328fdfd928bd598ee883331",
        "installed_path": "node_modules/.pnpm/tiff@7.1.3/node_modules/tiff"
      },
      {
        "importer": "apps/web",
        "name": "unified",
        "version": "11.0.5",
        "package_json_sha256": "f91a44220f8b7c4a4de6ebaab6fc23b92d29a95cb7e5e6a7f0f24d199779fbad",
        "installed_path": "node_modules/.pnpm/unified@11.0.5/node_modules/unified"
      },
      {
        "importer": "apps/web",
        "name": "use-sync-external-store",
        "version": "1.6.0",
        "package_json_sha256": "dfdead719ce161e1c5edbf0fca0ce0e7d70ba87c8a8f249856c0afde81595f24",
        "installed_path": "node_modules/.pnpm/use-sync-external-store@1.6.0_react@19.3.0/node_modules/use-sync-external-store"
      },
      {
        "importer": "apps/web",
        "name": "vfile",
        "version": "6.0.3",
        "package_json_sha256": "359ca117da48c3c42c73b9032369a412c5ad3462549d85aba090461e35227745",
        "installed_path": "node_modules/.pnpm/vfile@6.0.3/node_modules/vfile"
      },
      {
        "importer": "apps/web",
        "name": "vite",
        "version": "1.4.0",
        "package_json_sha256": "42c6bea740e6f14c2ffd97a2886dbde9a1ba1a5b09541c744d1c20dea0ce66c1",
        "installed_path": "node_modules/.pnpm/@voidzero-dev+vite-plus-core@1.4.0_@types+node@24.12.4_@volar+typescript@2.4.28_typescr_8da6fd7259a67fc1789c26b281f1676a/node_modules/@voidzero-dev/vite-plus-core"
      },
      {
        "importer": "apps/web",
        "name": "vite-plus",
        "version": "1.4.0",
        "package_json_sha256": "a2901e42e05a5f1c162b994ba85bfbad074a2f8921d129995b019e0bd48c9c09",
        "installed_path": "node_modules/.pnpm/vite-plus@1.4.0_@astrojs+compiler-rs@0.5.1_@types+node@24.12.4_@vitest+browser-playwrig_71b1ef4e5049c7accee71dd249ba4133/node_modules/vite-plus"
      },
      {
        "importer": "apps/web",
        "name": "zustand",
        "version": "5.0.14",
        "package_json_sha256": "ba50e4360c27bd3e677be84c5f119b15e4c8b7890ececbb248f4f531d3a272c3",
        "installed_path": "node_modules/.pnpm/zustand@5.0.14_@types+react@19.3.0_react@19.3.0_use-sync-external-store@1.6.0_react@19.3.0_/node_modules/zustand"
      },
      {
        "importer": "packages/client-runtime",
        "name": "@effect/vitest",
        "version": "4.1.2",
        "package_json_sha256": "63fe8c287b8aa7420363f515f1d6330cfa5574430af94832dab4447afadcfc71",
        "installed_path": "node_modules/.pnpm/@effect+vitest@4.1.2_patch_hash=299510b71c36537a832a67e9d160a5f112a5f326a29e95c41cb45fc_81d3dd1e682774f4c17d7f713915765f/node_modules/@effect/vitest"
      },
      {
        "importer": "packages/client-runtime",
        "name": "@pierre/diffs",
        "version": "1.7.0-beta.3",
        "package_json_sha256": "0663dc59ce053c8be045cf1edc1489d94fab003735e2c74a7f224723b4c0d46c",
        "installed_path": "node_modules/.pnpm/@pierre+diffs@1.7.0-beta.3_patch_hash=4a64f63a0def94c5add9d86d70560d26d6857e1f515013386_8cf7878feba9a5fb545c4167fb5428f0/node_modules/@pierre/diffs"
      },
      {
        "importer": "packages/client-runtime",
        "name": "@types/mdast",
        "version": "4.0.4",
        "package_json_sha256": "5a41865d64d4cedba58313fad775cf56bd0474d724343172bcea9f8ad24db563",
        "installed_path": "node_modules/.pnpm/@types+mdast@4.0.4/node_modules/@types/mdast"
      },
      {
        "importer": "packages/client-runtime",
        "name": "@types/three",
        "version": "0.180.0",
        "package_json_sha256": "b3aca396a9c08cb7cbaa03b0dff2f2e0ebc55958715b465acd76c4f291a5eb2b",
        "installed_path": "node_modules/.pnpm/@types+three@0.180.0/node_modules/@types/three"
      },
      {
        "importer": "packages/client-runtime",
        "name": "effect",
        "version": "4.1.3",
        "package_json_sha256": "8ae4c5cf40f75346e2ab4dcacb692a98a6ddd814ecc5ffad27db087d6cfa3a9f",
        "installed_path": "node_modules/.pnpm/effect@4.1.3/node_modules/effect"
      },
      {
        "importer": "packages/client-runtime",
        "name": "jszip",
        "version": "3.10.1",
        "package_json_sha256": "83569b5b130b5ec27ae281ed80420ad364baf1bf64cb82e6ac8fb891e1b4ec4c",
        "installed_path": "node_modules/.pnpm/jszip@3.10.1/node_modules/jszip"
      },
      {
        "importer": "packages/client-runtime",
        "name": "remark-gfm",
        "version": "4.0.1",
        "package_json_sha256": "c199482a69355b610bd1ff225b097776d4a990445b11e5f4c618930dacc8c79d",
        "installed_path": "node_modules/.pnpm/remark-gfm@4.0.1_supports-color@8.1.1/node_modules/remark-gfm"
      },
      {
        "importer": "packages/client-runtime",
        "name": "remark-parse",
        "version": "11.0.0",
        "package_json_sha256": "47be70916ff853a6c35d8d858844c7b104d100f70999d579884859cf8d88a50c",
        "installed_path": "node_modules/.pnpm/remark-parse@11.0.0_supports-color@8.1.1/node_modules/remark-parse"
      },
      {
        "importer": "packages/client-runtime",
        "name": "three",
        "version": "0.180.0",
        "package_json_sha256": "aa42494664dba4cf76d89c6975ee38321a402f09a048672e190bad6f13beec93",
        "installed_path": "node_modules/.pnpm/three@0.180.0/node_modules/three"
      },
      {
        "importer": "packages/client-runtime",
        "name": "unbash",
        "version": "5.0.0",
        "package_json_sha256": "1e8cedd154cd34f9f7e3d24045daac558505361833f02d6e3797d5f9bfc98e7f",
        "installed_path": "node_modules/.pnpm/unbash@5.0.0/node_modules/unbash"
      },
      {
        "importer": "packages/client-runtime",
        "name": "unified",
        "version": "11.0.5",
        "package_json_sha256": "f91a44220f8b7c4a4de6ebaab6fc23b92d29a95cb7e5e6a7f0f24d199779fbad",
        "installed_path": "node_modules/.pnpm/unified@11.0.5/node_modules/unified"
      },
      {
        "importer": "packages/client-runtime",
        "name": "vite-plus",
        "version": "1.4.0",
        "package_json_sha256": "a2901e42e05a5f1c162b994ba85bfbad074a2f8921d129995b019e0bd48c9c09",
        "installed_path": "node_modules/.pnpm/vite-plus@1.4.0_@astrojs+compiler-rs@0.5.1_@types+node@24.12.4_@vitest+browser-playwrig_71b1ef4e5049c7accee71dd249ba4133/node_modules/vite-plus"
      },
      {
        "importer": "packages/contracts",
        "name": "@effect/vitest",
        "version": "4.1.2",
        "package_json_sha256": "63fe8c287b8aa7420363f515f1d6330cfa5574430af94832dab4447afadcfc71",
        "installed_path": "node_modules/.pnpm/@effect+vitest@4.1.2_patch_hash=299510b71c36537a832a67e9d160a5f112a5f326a29e95c41cb45fc_81d3dd1e682774f4c17d7f713915765f/node_modules/@effect/vitest"
      },
      {
        "importer": "packages/contracts",
        "name": "effect",
        "version": "4.1.3",
        "package_json_sha256": "8ae4c5cf40f75346e2ab4dcacb692a98a6ddd814ecc5ffad27db087d6cfa3a9f",
        "installed_path": "node_modules/.pnpm/effect@4.1.3/node_modules/effect"
      },
      {
        "importer": "packages/contracts",
        "name": "vite-plus",
        "version": "1.4.0",
        "package_json_sha256": "a2901e42e05a5f1c162b994ba85bfbad074a2f8921d129995b019e0bd48c9c09",
        "installed_path": "node_modules/.pnpm/vite-plus@1.4.0_@astrojs+compiler-rs@0.5.1_@types+node@24.12.4_@vitest+browser-playwrig_71b1ef4e5049c7accee71dd249ba4133/node_modules/vite-plus"
      },
      {
        "importer": "packages/effect-acp",
        "name": "@effect/openapi-generator",
        "version": "4.1.2",
        "package_json_sha256": "710c0d83c27d4bc1cd273d1fe3b5d227231f42d3561ffdd1d85a81fd2e1cb9a0",
        "installed_path": "node_modules/.pnpm/@effect+openapi-generator@4.1.2_@effect+platform-node@4.1.2_bufferutil@4.1.0_effect@4.1_30314c07d9954daae64da0f4007085c9/node_modules/@effect/openapi-generator"
      },
      {
        "importer": "packages/effect-acp",
        "name": "@effect/platform-node",
        "version": "4.1.2",
        "package_json_sha256": "2901f7c08e6011794c624e346b19f85a6b455338c3991578407c3028bd64800e",
        "installed_path": "node_modules/.pnpm/@effect+platform-node@4.1.2_bufferutil@4.1.0_effect@4.1.3_redis@6.2.1_utf-8-validate@6.0.6/node_modules/@effect/platform-node"
      },
      {
        "importer": "packages/effect-acp",
        "name": "@effect/vitest",
        "version": "4.1.2",
        "package_json_sha256": "63fe8c287b8aa7420363f515f1d6330cfa5574430af94832dab4447afadcfc71",
        "installed_path": "node_modules/.pnpm/@effect+vitest@4.1.2_patch_hash=299510b71c36537a832a67e9d160a5f112a5f326a29e95c41cb45fc_81d3dd1e682774f4c17d7f713915765f/node_modules/@effect/vitest"
      },
      {
        "importer": "packages/effect-acp",
        "name": "@types/node",
        "version": "24.12.4",
        "package_json_sha256": "456b1366f1966515c4dfec48446c82275502a2d5ea7cfbc74874323b39e3776f",
        "installed_path": "node_modules/.pnpm/@types+node@24.12.4/node_modules/@types/node"
      },
      {
        "importer": "packages/effect-acp",
        "name": "effect",
        "version": "4.1.3",
        "package_json_sha256": "8ae4c5cf40f75346e2ab4dcacb692a98a6ddd814ecc5ffad27db087d6cfa3a9f",
        "installed_path": "node_modules/.pnpm/effect@4.1.3/node_modules/effect"
      },
      {
        "importer": "packages/effect-acp",
        "name": "vite-plus",
        "version": "1.4.0",
        "package_json_sha256": "a2901e42e05a5f1c162b994ba85bfbad074a2f8921d129995b019e0bd48c9c09",
        "installed_path": "node_modules/.pnpm/vite-plus@1.4.0_@astrojs+compiler-rs@0.5.1_@types+node@24.12.4_@vitest+browser-playwrig_71b1ef4e5049c7accee71dd249ba4133/node_modules/vite-plus"
      },
      {
        "importer": "packages/effect-codex-app-server",
        "name": "@effect/openapi-generator",
        "version": "4.1.2",
        "package_json_sha256": "710c0d83c27d4bc1cd273d1fe3b5d227231f42d3561ffdd1d85a81fd2e1cb9a0",
        "installed_path": "node_modules/.pnpm/@effect+openapi-generator@4.1.2_@effect+platform-node@4.1.2_bufferutil@4.1.0_effect@4.1_30314c07d9954daae64da0f4007085c9/node_modules/@effect/openapi-generator"
      },
      {
        "importer": "packages/effect-codex-app-server",
        "name": "@effect/platform-node",
        "version": "4.1.2",
        "package_json_sha256": "2901f7c08e6011794c624e346b19f85a6b455338c3991578407c3028bd64800e",
        "installed_path": "node_modules/.pnpm/@effect+platform-node@4.1.2_bufferutil@4.1.0_effect@4.1.3_redis@6.2.1_utf-8-validate@6.0.6/node_modules/@effect/platform-node"
      },
      {
        "importer": "packages/effect-codex-app-server",
        "name": "@effect/vitest",
        "version": "4.1.2",
        "package_json_sha256": "63fe8c287b8aa7420363f515f1d6330cfa5574430af94832dab4447afadcfc71",
        "installed_path": "node_modules/.pnpm/@effect+vitest@4.1.2_patch_hash=299510b71c36537a832a67e9d160a5f112a5f326a29e95c41cb45fc_81d3dd1e682774f4c17d7f713915765f/node_modules/@effect/vitest"
      },
      {
        "importer": "packages/effect-codex-app-server",
        "name": "@types/node",
        "version": "24.12.4",
        "package_json_sha256": "456b1366f1966515c4dfec48446c82275502a2d5ea7cfbc74874323b39e3776f",
        "installed_path": "node_modules/.pnpm/@types+node@24.12.4/node_modules/@types/node"
      },
      {
        "importer": "packages/effect-codex-app-server",
        "name": "effect",
        "version": "4.1.3",
        "package_json_sha256": "8ae4c5cf40f75346e2ab4dcacb692a98a6ddd814ecc5ffad27db087d6cfa3a9f",
        "installed_path": "node_modules/.pnpm/effect@4.1.3/node_modules/effect"
      },
      {
        "importer": "packages/effect-codex-app-server",
        "name": "vite-plus",
        "version": "1.4.0",
        "package_json_sha256": "a2901e42e05a5f1c162b994ba85bfbad074a2f8921d129995b019e0bd48c9c09",
        "installed_path": "node_modules/.pnpm/vite-plus@1.4.0_@astrojs+compiler-rs@0.5.1_@types+node@24.12.4_@vitest+browser-playwrig_71b1ef4e5049c7accee71dd249ba4133/node_modules/vite-plus"
      },
      {
        "importer": "packages/provider-acp",
        "name": "@effect/platform-node",
        "version": "4.1.2",
        "package_json_sha256": "2901f7c08e6011794c624e346b19f85a6b455338c3991578407c3028bd64800e",
        "installed_path": "node_modules/.pnpm/@effect+platform-node@4.1.2_bufferutil@4.1.0_effect@4.1.3_redis@6.2.1_utf-8-validate@6.0.6/node_modules/@effect/platform-node"
      },
      {
        "importer": "packages/provider-acp",
        "name": "@effect/vitest",
        "version": "4.1.2",
        "package_json_sha256": "63fe8c287b8aa7420363f515f1d6330cfa5574430af94832dab4447afadcfc71",
        "installed_path": "node_modules/.pnpm/@effect+vitest@4.1.2_patch_hash=299510b71c36537a832a67e9d160a5f112a5f326a29e95c41cb45fc_81d3dd1e682774f4c17d7f713915765f/node_modules/@effect/vitest"
      },
      {
        "importer": "packages/provider-acp",
        "name": "@types/node",
        "version": "24.12.4",
        "package_json_sha256": "456b1366f1966515c4dfec48446c82275502a2d5ea7cfbc74874323b39e3776f",
        "installed_path": "node_modules/.pnpm/@types+node@24.12.4/node_modules/@types/node"
      },
      {
        "importer": "packages/provider-acp",
        "name": "diff",
        "version": "8.0.3",
        "package_json_sha256": "35b083dc3430465fbe066129e12debeb5416474e1db71abf7a8db9997789aeed",
        "installed_path": "node_modules/.pnpm/diff@8.0.3/node_modules/diff"
      },
      {
        "importer": "packages/provider-acp",
        "name": "effect",
        "version": "4.1.3",
        "package_json_sha256": "8ae4c5cf40f75346e2ab4dcacb692a98a6ddd814ecc5ffad27db087d6cfa3a9f",
        "installed_path": "node_modules/.pnpm/effect@4.1.3/node_modules/effect"
      },
      {
        "importer": "packages/provider-acp",
        "name": "vite-plus",
        "version": "1.4.0",
        "package_json_sha256": "a2901e42e05a5f1c162b994ba85bfbad074a2f8921d129995b019e0bd48c9c09",
        "installed_path": "node_modules/.pnpm/vite-plus@1.4.0_@astrojs+compiler-rs@0.5.1_@types+node@24.12.4_@vitest+browser-playwrig_71b1ef4e5049c7accee71dd249ba4133/node_modules/vite-plus"
      },
      {
        "importer": "packages/provider-acp-registry",
        "name": "@effect/platform-node",
        "version": "4.1.2",
        "package_json_sha256": "2901f7c08e6011794c624e346b19f85a6b455338c3991578407c3028bd64800e",
        "installed_path": "node_modules/.pnpm/@effect+platform-node@4.1.2_bufferutil@4.1.0_effect@4.1.3_redis@6.2.1_utf-8-validate@6.0.6/node_modules/@effect/platform-node"
      },
      {
        "importer": "packages/provider-acp-registry",
        "name": "@effect/vitest",
        "version": "4.1.2",
        "package_json_sha256": "63fe8c287b8aa7420363f515f1d6330cfa5574430af94832dab4447afadcfc71",
        "installed_path": "node_modules/.pnpm/@effect+vitest@4.1.2_patch_hash=299510b71c36537a832a67e9d160a5f112a5f326a29e95c41cb45fc_81d3dd1e682774f4c17d7f713915765f/node_modules/@effect/vitest"
      },
      {
        "importer": "packages/provider-acp-registry",
        "name": "@noble/hashes",
        "version": "1.8.0",
        "package_json_sha256": "7c4657c5e616c22cefa2691cc30670824a639dc71d97bf83925be2d239dc60e3",
        "installed_path": "node_modules/.pnpm/@noble+hashes@1.8.0/node_modules/@noble/hashes"
      },
      {
        "importer": "packages/provider-acp-registry",
        "name": "@types/node",
        "version": "24.12.4",
        "package_json_sha256": "456b1366f1966515c4dfec48446c82275502a2d5ea7cfbc74874323b39e3776f",
        "installed_path": "node_modules/.pnpm/@types+node@24.12.4/node_modules/@types/node"
      },
      {
        "importer": "packages/provider-acp-registry",
        "name": "effect",
        "version": "4.1.3",
        "package_json_sha256": "8ae4c5cf40f75346e2ab4dcacb692a98a6ddd814ecc5ffad27db087d6cfa3a9f",
        "installed_path": "node_modules/.pnpm/effect@4.1.3/node_modules/effect"
      },
      {
        "importer": "packages/provider-acp-registry",
        "name": "vite-plus",
        "version": "1.4.0",
        "package_json_sha256": "a2901e42e05a5f1c162b994ba85bfbad074a2f8921d129995b019e0bd48c9c09",
        "installed_path": "node_modules/.pnpm/vite-plus@1.4.0_@astrojs+compiler-rs@0.5.1_@types+node@24.12.4_@vitest+browser-playwrig_71b1ef4e5049c7accee71dd249ba4133/node_modules/vite-plus"
      },
      {
        "importer": "packages/provider-core",
        "name": "@effect/platform-node",
        "version": "4.1.2",
        "package_json_sha256": "2901f7c08e6011794c624e346b19f85a6b455338c3991578407c3028bd64800e",
        "installed_path": "node_modules/.pnpm/@effect+platform-node@4.1.2_bufferutil@4.1.0_effect@4.1.3_redis@6.2.1_utf-8-validate@6.0.6/node_modules/@effect/platform-node"
      },
      {
        "importer": "packages/provider-core",
        "name": "@effect/vitest",
        "version": "4.1.2",
        "package_json_sha256": "63fe8c287b8aa7420363f515f1d6330cfa5574430af94832dab4447afadcfc71",
        "installed_path": "node_modules/.pnpm/@effect+vitest@4.1.2_patch_hash=299510b71c36537a832a67e9d160a5f112a5f326a29e95c41cb45fc_81d3dd1e682774f4c17d7f713915765f/node_modules/@effect/vitest"
      },
      {
        "importer": "packages/provider-core",
        "name": "@types/node",
        "version": "24.12.4",
        "package_json_sha256": "456b1366f1966515c4dfec48446c82275502a2d5ea7cfbc74874323b39e3776f",
        "installed_path": "node_modules/.pnpm/@types+node@24.12.4/node_modules/@types/node"
      },
      {
        "importer": "packages/provider-core",
        "name": "effect",
        "version": "4.1.3",
        "package_json_sha256": "8ae4c5cf40f75346e2ab4dcacb692a98a6ddd814ecc5ffad27db087d6cfa3a9f",
        "installed_path": "node_modules/.pnpm/effect@4.1.3/node_modules/effect"
      },
      {
        "importer": "packages/provider-core",
        "name": "vite-plus",
        "version": "1.4.0",
        "package_json_sha256": "a2901e42e05a5f1c162b994ba85bfbad074a2f8921d129995b019e0bd48c9c09",
        "installed_path": "node_modules/.pnpm/vite-plus@1.4.0_@astrojs+compiler-rs@0.5.1_@types+node@24.12.4_@vitest+browser-playwrig_71b1ef4e5049c7accee71dd249ba4133/node_modules/vite-plus"
      },
      {
        "importer": "packages/provider-cursor",
        "name": "@cursor/sdk",
        "version": "1.2.0",
        "package_json_sha256": "55a97a0dbb3adb899c4b8ec07b306d5d0e226d03ea4f42f8a1dfc30b9db98dcd",
        "installed_path": "node_modules/.pnpm/@cursor+sdk@1.2.0_patch_hash=57f502128bf6accd976963b126e227c86a45d815a53a8dc450461beae3bed4a4_zod@4.6.7/node_modules/@cursor/sdk"
      },
      {
        "importer": "packages/provider-cursor",
        "name": "@effect/platform-node",
        "version": "4.1.2",
        "package_json_sha256": "2901f7c08e6011794c624e346b19f85a6b455338c3991578407c3028bd64800e",
        "installed_path": "node_modules/.pnpm/@effect+platform-node@4.1.2_bufferutil@4.1.0_effect@4.1.3_redis@6.2.1_utf-8-validate@6.0.6/node_modules/@effect/platform-node"
      },
      {
        "importer": "packages/provider-cursor",
        "name": "@effect/vitest",
        "version": "4.1.2",
        "package_json_sha256": "63fe8c287b8aa7420363f515f1d6330cfa5574430af94832dab4447afadcfc71",
        "installed_path": "node_modules/.pnpm/@effect+vitest@4.1.2_patch_hash=299510b71c36537a832a67e9d160a5f112a5f326a29e95c41cb45fc_81d3dd1e682774f4c17d7f713915765f/node_modules/@effect/vitest"
      },
      {
        "importer": "packages/provider-cursor",
        "name": "@types/node",
        "version": "24.12.4",
        "package_json_sha256": "456b1366f1966515c4dfec48446c82275502a2d5ea7cfbc74874323b39e3776f",
        "installed_path": "node_modules/.pnpm/@types+node@24.12.4/node_modules/@types/node"
      },
      {
        "importer": "packages/provider-cursor",
        "name": "effect",
        "version": "4.1.3",
        "package_json_sha256": "8ae4c5cf40f75346e2ab4dcacb692a98a6ddd814ecc5ffad27db087d6cfa3a9f",
        "installed_path": "node_modules/.pnpm/effect@4.1.3/node_modules/effect"
      },
      {
        "importer": "packages/provider-cursor",
        "name": "jsonc-parser",
        "version": "3.3.1",
        "package_json_sha256": "a7a9192caaac00d9330592f4fd572908bee037518128a0fc3db96d2cd652e2b5",
        "installed_path": "node_modules/.pnpm/jsonc-parser@3.3.1/node_modules/jsonc-parser"
      },
      {
        "importer": "packages/provider-cursor",
        "name": "vite-plus",
        "version": "1.4.0",
        "package_json_sha256": "a2901e42e05a5f1c162b994ba85bfbad074a2f8921d129995b019e0bd48c9c09",
        "installed_path": "node_modules/.pnpm/vite-plus@1.4.0_@astrojs+compiler-rs@0.5.1_@types+node@24.12.4_@vitest+browser-playwrig_71b1ef4e5049c7accee71dd249ba4133/node_modules/vite-plus"
      },
      {
        "importer": "packages/provider-cursor",
        "name": "yaml",
        "version": "2.9.0",
        "package_json_sha256": "20b8b197cbd10dad245d45e463dfe58e4c8c25a47e24bc4256ad9ab58bf35683",
        "installed_path": "node_modules/.pnpm/yaml@2.9.0/node_modules/yaml"
      },
      {
        "importer": "packages/provider-fx",
        "name": "@effect/platform-node",
        "version": "4.1.2",
        "package_json_sha256": "2901f7c08e6011794c624e346b19f85a6b455338c3991578407c3028bd64800e",
        "installed_path": "node_modules/.pnpm/@effect+platform-node@4.1.2_bufferutil@4.1.0_effect@4.1.3_redis@6.2.1_utf-8-validate@6.0.6/node_modules/@effect/platform-node"
      },
      {
        "importer": "packages/provider-fx",
        "name": "@effect/vitest",
        "version": "4.1.2",
        "package_json_sha256": "63fe8c287b8aa7420363f515f1d6330cfa5574430af94832dab4447afadcfc71",
        "installed_path": "node_modules/.pnpm/@effect+vitest@4.1.2_patch_hash=299510b71c36537a832a67e9d160a5f112a5f326a29e95c41cb45fc_81d3dd1e682774f4c17d7f713915765f/node_modules/@effect/vitest"
      },
      {
        "importer": "packages/provider-fx",
        "name": "@types/node",
        "version": "24.12.4",
        "package_json_sha256": "456b1366f1966515c4dfec48446c82275502a2d5ea7cfbc74874323b39e3776f",
        "installed_path": "node_modules/.pnpm/@types+node@24.12.4/node_modules/@types/node"
      },
      {
        "importer": "packages/provider-fx",
        "name": "effect",
        "version": "4.1.3",
        "package_json_sha256": "8ae4c5cf40f75346e2ab4dcacb692a98a6ddd814ecc5ffad27db087d6cfa3a9f",
        "installed_path": "node_modules/.pnpm/effect@4.1.3/node_modules/effect"
      },
      {
        "importer": "packages/provider-fx",
        "name": "vite-plus",
        "version": "1.4.0",
        "package_json_sha256": "a2901e42e05a5f1c162b994ba85bfbad074a2f8921d129995b019e0bd48c9c09",
        "installed_path": "node_modules/.pnpm/vite-plus@1.4.0_@astrojs+compiler-rs@0.5.1_@types+node@24.12.4_@vitest+browser-playwrig_71b1ef4e5049c7accee71dd249ba4133/node_modules/vite-plus"
      },
      {
        "importer": "packages/provider-grok",
        "name": "@effect/platform-node",
        "version": "4.1.2",
        "package_json_sha256": "2901f7c08e6011794c624e346b19f85a6b455338c3991578407c3028bd64800e",
        "installed_path": "node_modules/.pnpm/@effect+platform-node@4.1.2_bufferutil@4.1.0_effect@4.1.3_redis@6.2.1_utf-8-validate@6.0.6/node_modules/@effect/platform-node"
      },
      {
        "importer": "packages/provider-grok",
        "name": "@effect/vitest",
        "version": "4.1.2",
        "package_json_sha256": "63fe8c287b8aa7420363f515f1d6330cfa5574430af94832dab4447afadcfc71",
        "installed_path": "node_modules/.pnpm/@effect+vitest@4.1.2_patch_hash=299510b71c36537a832a67e9d160a5f112a5f326a29e95c41cb45fc_81d3dd1e682774f4c17d7f713915765f/node_modules/@effect/vitest"
      },
      {
        "importer": "packages/provider-grok",
        "name": "@types/node",
        "version": "24.12.4",
        "package_json_sha256": "456b1366f1966515c4dfec48446c82275502a2d5ea7cfbc74874323b39e3776f",
        "installed_path": "node_modules/.pnpm/@types+node@24.12.4/node_modules/@types/node"
      },
      {
        "importer": "packages/provider-grok",
        "name": "effect",
        "version": "4.1.3",
        "package_json_sha256": "8ae4c5cf40f75346e2ab4dcacb692a98a6ddd814ecc5ffad27db087d6cfa3a9f",
        "installed_path": "node_modules/.pnpm/effect@4.1.3/node_modules/effect"
      },
      {
        "importer": "packages/provider-grok",
        "name": "vite-plus",
        "version": "1.4.0",
        "package_json_sha256": "a2901e42e05a5f1c162b994ba85bfbad074a2f8921d129995b019e0bd48c9c09",
        "installed_path": "node_modules/.pnpm/vite-plus@1.4.0_@astrojs+compiler-rs@0.5.1_@types+node@24.12.4_@vitest+browser-playwrig_71b1ef4e5049c7accee71dd249ba4133/node_modules/vite-plus"
      },
      {
        "importer": "packages/provider-kiro",
        "name": "@effect/platform-node",
        "version": "4.1.2",
        "package_json_sha256": "2901f7c08e6011794c624e346b19f85a6b455338c3991578407c3028bd64800e",
        "installed_path": "node_modules/.pnpm/@effect+platform-node@4.1.2_bufferutil@4.1.0_effect@4.1.3_redis@6.2.1_utf-8-validate@6.0.6/node_modules/@effect/platform-node"
      },
      {
        "importer": "packages/provider-kiro",
        "name": "@effect/vitest",
        "version": "4.1.2",
        "package_json_sha256": "63fe8c287b8aa7420363f515f1d6330cfa5574430af94832dab4447afadcfc71",
        "installed_path": "node_modules/.pnpm/@effect+vitest@4.1.2_patch_hash=299510b71c36537a832a67e9d160a5f112a5f326a29e95c41cb45fc_81d3dd1e682774f4c17d7f713915765f/node_modules/@effect/vitest"
      },
      {
        "importer": "packages/provider-kiro",
        "name": "@types/node",
        "version": "24.12.4",
        "package_json_sha256": "456b1366f1966515c4dfec48446c82275502a2d5ea7cfbc74874323b39e3776f",
        "installed_path": "node_modules/.pnpm/@types+node@24.12.4/node_modules/@types/node"
      },
      {
        "importer": "packages/provider-kiro",
        "name": "effect",
        "version": "4.1.3",
        "package_json_sha256": "8ae4c5cf40f75346e2ab4dcacb692a98a6ddd814ecc5ffad27db087d6cfa3a9f",
        "installed_path": "node_modules/.pnpm/effect@4.1.3/node_modules/effect"
      },
      {
        "importer": "packages/provider-kiro",
        "name": "vite-plus",
        "version": "1.4.0",
        "package_json_sha256": "a2901e42e05a5f1c162b994ba85bfbad074a2f8921d129995b019e0bd48c9c09",
        "installed_path": "node_modules/.pnpm/vite-plus@1.4.0_@astrojs+compiler-rs@0.5.1_@types+node@24.12.4_@vitest+browser-playwrig_71b1ef4e5049c7accee71dd249ba4133/node_modules/vite-plus"
      },
      {
        "importer": "packages/provider-muse",
        "name": "@effect/platform-node",
        "version": "4.1.2",
        "package_json_sha256": "2901f7c08e6011794c624e346b19f85a6b455338c3991578407c3028bd64800e",
        "installed_path": "node_modules/.pnpm/@effect+platform-node@4.1.2_bufferutil@4.1.0_effect@4.1.3_redis@6.2.1_utf-8-validate@6.0.6/node_modules/@effect/platform-node"
      },
      {
        "importer": "packages/provider-muse",
        "name": "@effect/vitest",
        "version": "4.1.2",
        "package_json_sha256": "63fe8c287b8aa7420363f515f1d6330cfa5574430af94832dab4447afadcfc71",
        "installed_path": "node_modules/.pnpm/@effect+vitest@4.1.2_patch_hash=299510b71c36537a832a67e9d160a5f112a5f326a29e95c41cb45fc_81d3dd1e682774f4c17d7f713915765f/node_modules/@effect/vitest"
      },
      {
        "importer": "packages/provider-muse",
        "name": "@muse-code/sdk",
        "version": "1.4.6",
        "package_json_sha256": "44d2806ed5a24e8ee6aaacaa6259f2a7660ee5b34d53875fd97960d3e5a8b4ef",
        "installed_path": "node_modules/.pnpm/@muse-code+sdk@1.4.6_patch_hash=7b495b607fc5d76b444c7c4d58821e839726a30e6f3c53564f0d59f2d5b42101_@types+node@24.12.4/node_modules/@muse-code/sdk"
      },
      {
        "importer": "packages/provider-muse",
        "name": "@types/node",
        "version": "24.12.4",
        "package_json_sha256": "456b1366f1966515c4dfec48446c82275502a2d5ea7cfbc74874323b39e3776f",
        "installed_path": "node_modules/.pnpm/@types+node@24.12.4/node_modules/@types/node"
      },
      {
        "importer": "packages/provider-muse",
        "name": "effect",
        "version": "4.1.3",
        "package_json_sha256": "8ae4c5cf40f75346e2ab4dcacb692a98a6ddd814ecc5ffad27db087d6cfa3a9f",
        "installed_path": "node_modules/.pnpm/effect@4.1.3/node_modules/effect"
      },
      {
        "importer": "packages/provider-muse",
        "name": "vite-plus",
        "version": "1.4.0",
        "package_json_sha256": "a2901e42e05a5f1c162b994ba85bfbad074a2f8921d129995b019e0bd48c9c09",
        "installed_path": "node_modules/.pnpm/vite-plus@1.4.0_@astrojs+compiler-rs@0.5.1_@types+node@24.12.4_@vitest+browser-playwrig_71b1ef4e5049c7accee71dd249ba4133/node_modules/vite-plus"
      },
      {
        "importer": "packages/provider-opencode",
        "name": "@effect/platform-node",
        "version": "4.1.2",
        "package_json_sha256": "2901f7c08e6011794c624e346b19f85a6b455338c3991578407c3028bd64800e",
        "installed_path": "node_modules/.pnpm/@effect+platform-node@4.1.2_bufferutil@4.1.0_effect@4.1.3_redis@6.2.1_utf-8-validate@6.0.6/node_modules/@effect/platform-node"
      },
      {
        "importer": "packages/provider-opencode",
        "name": "@effect/vitest",
        "version": "4.1.2",
        "package_json_sha256": "63fe8c287b8aa7420363f515f1d6330cfa5574430af94832dab4447afadcfc71",
        "installed_path": "node_modules/.pnpm/@effect+vitest@4.1.2_patch_hash=299510b71c36537a832a67e9d160a5f112a5f326a29e95c41cb45fc_81d3dd1e682774f4c17d7f713915765f/node_modules/@effect/vitest"
      },
      {
        "importer": "packages/provider-opencode",
        "name": "@opencode-ai/sdk",
        "version": "1.15.13",
        "package_json_sha256": "389f3fe4b859309ff51efbe8253c1968fecc4e9d148dfd555b4d6bcfd3e20fb5",
        "installed_path": "node_modules/.pnpm/@opencode-ai+sdk@1.15.13/node_modules/@opencode-ai/sdk"
      },
      {
        "importer": "packages/provider-opencode",
        "name": "@opencode/client",
        "version": "2.0.28",
        "package_json_sha256": "ff43ff5e26e6bc2188a5d20478e96e8715c01c5514f030ca496c716db9c9a856",
        "installed_path": "node_modules/.pnpm/@opencode+client@2.0.28_effect@4.1.3/node_modules/@opencode/client"
      },
      {
        "importer": "packages/provider-opencode",
        "name": "@opencode/protocol",
        "version": "2.0.28",
        "package_json_sha256": "f47856974ae1913bf3bf60d4b25fed10189532551f9f5fd93c077e7bdd1533b0",
        "installed_path": "node_modules/.pnpm/@opencode+protocol@2.0.28/node_modules/@opencode/protocol"
      },
      {
        "importer": "packages/provider-opencode",
        "name": "@opencode/schema",
        "version": "2.0.28",
        "package_json_sha256": "2c9a769cc21321d0b12f63129b01b0645f208e37bcddd50d86dc025da5491976",
        "installed_path": "node_modules/.pnpm/@opencode+schema@2.0.28/node_modules/@opencode/schema"
      },
      {
        "importer": "packages/provider-opencode",
        "name": "@types/node",
        "version": "24.12.4",
        "package_json_sha256": "456b1366f1966515c4dfec48446c82275502a2d5ea7cfbc74874323b39e3776f",
        "installed_path": "node_modules/.pnpm/@types+node@24.12.4/node_modules/@types/node"
      },
      {
        "importer": "packages/provider-opencode",
        "name": "effect",
        "version": "4.1.3",
        "package_json_sha256": "8ae4c5cf40f75346e2ab4dcacb692a98a6ddd814ecc5ffad27db087d6cfa3a9f",
        "installed_path": "node_modules/.pnpm/effect@4.1.3/node_modules/effect"
      },
      {
        "importer": "packages/provider-opencode",
        "name": "vite-plus",
        "version": "1.4.0",
        "package_json_sha256": "a2901e42e05a5f1c162b994ba85bfbad074a2f8921d129995b019e0bd48c9c09",
        "installed_path": "node_modules/.pnpm/vite-plus@1.4.0_@astrojs+compiler-rs@0.5.1_@types+node@24.12.4_@vitest+browser-playwrig_71b1ef4e5049c7accee71dd249ba4133/node_modules/vite-plus"
      },
      {
        "importer": "packages/provider-pi",
        "name": "@effect/platform-node",
        "version": "4.1.2",
        "package_json_sha256": "2901f7c08e6011794c624e346b19f85a6b455338c3991578407c3028bd64800e",
        "installed_path": "node_modules/.pnpm/@effect+platform-node@4.1.2_bufferutil@4.1.0_effect@4.1.3_redis@6.2.1_utf-8-validate@6.0.6/node_modules/@effect/platform-node"
      },
      {
        "importer": "packages/provider-pi",
        "name": "@effect/vitest",
        "version": "4.1.2",
        "package_json_sha256": "63fe8c287b8aa7420363f515f1d6330cfa5574430af94832dab4447afadcfc71",
        "installed_path": "node_modules/.pnpm/@effect+vitest@4.1.2_patch_hash=299510b71c36537a832a67e9d160a5f112a5f326a29e95c41cb45fc_81d3dd1e682774f4c17d7f713915765f/node_modules/@effect/vitest"
      },
      {
        "importer": "packages/provider-pi",
        "name": "@types/node",
        "version": "24.12.4",
        "package_json_sha256": "456b1366f1966515c4dfec48446c82275502a2d5ea7cfbc74874323b39e3776f",
        "installed_path": "node_modules/.pnpm/@types+node@24.12.4/node_modules/@types/node"
      },
      {
        "importer": "packages/provider-pi",
        "name": "effect",
        "version": "4.1.3",
        "package_json_sha256": "8ae4c5cf40f75346e2ab4dcacb692a98a6ddd814ecc5ffad27db087d6cfa3a9f",
        "installed_path": "node_modules/.pnpm/effect@4.1.3/node_modules/effect"
      },
      {
        "importer": "packages/provider-pi",
        "name": "vite-plus",
        "version": "1.4.0",
        "package_json_sha256": "a2901e42e05a5f1c162b994ba85bfbad074a2f8921d129995b019e0bd48c9c09",
        "installed_path": "node_modules/.pnpm/vite-plus@1.4.0_@astrojs+compiler-rs@0.5.1_@types+node@24.12.4_@vitest+browser-playwrig_71b1ef4e5049c7accee71dd249ba4133/node_modules/vite-plus"
      },
      {
        "importer": "packages/provider-testing",
        "name": "@effect/platform-node",
        "version": "4.1.2",
        "package_json_sha256": "2901f7c08e6011794c624e346b19f85a6b455338c3991578407c3028bd64800e",
        "installed_path": "node_modules/.pnpm/@effect+platform-node@4.1.2_bufferutil@4.1.0_effect@4.1.3_redis@6.2.1_utf-8-validate@6.0.6/node_modules/@effect/platform-node"
      },
      {
        "importer": "packages/provider-testing",
        "name": "@types/node",
        "version": "24.12.4",
        "package_json_sha256": "456b1366f1966515c4dfec48446c82275502a2d5ea7cfbc74874323b39e3776f",
        "installed_path": "node_modules/.pnpm/@types+node@24.12.4/node_modules/@types/node"
      },
      {
        "importer": "packages/provider-testing",
        "name": "effect",
        "version": "4.1.3",
        "package_json_sha256": "8ae4c5cf40f75346e2ab4dcacb692a98a6ddd814ecc5ffad27db087d6cfa3a9f",
        "installed_path": "node_modules/.pnpm/effect@4.1.3/node_modules/effect"
      },
      {
        "importer": "packages/secret-provider-core",
        "name": "@effect/platform-node",
        "version": "4.1.2",
        "package_json_sha256": "2901f7c08e6011794c624e346b19f85a6b455338c3991578407c3028bd64800e",
        "installed_path": "node_modules/.pnpm/@effect+platform-node@4.1.2_bufferutil@4.1.0_effect@4.1.3_redis@6.2.1_utf-8-validate@6.0.6/node_modules/@effect/platform-node"
      },
      {
        "importer": "packages/secret-provider-core",
        "name": "@effect/vitest",
        "version": "4.1.2",
        "package_json_sha256": "63fe8c287b8aa7420363f515f1d6330cfa5574430af94832dab4447afadcfc71",
        "installed_path": "node_modules/.pnpm/@effect+vitest@4.1.2_patch_hash=299510b71c36537a832a67e9d160a5f112a5f326a29e95c41cb45fc_81d3dd1e682774f4c17d7f713915765f/node_modules/@effect/vitest"
      },
      {
        "importer": "packages/secret-provider-core",
        "name": "@types/node",
        "version": "24.12.4",
        "package_json_sha256": "456b1366f1966515c4dfec48446c82275502a2d5ea7cfbc74874323b39e3776f",
        "installed_path": "node_modules/.pnpm/@types+node@24.12.4/node_modules/@types/node"
      },
      {
        "importer": "packages/secret-provider-core",
        "name": "effect",
        "version": "4.1.3",
        "package_json_sha256": "8ae4c5cf40f75346e2ab4dcacb692a98a6ddd814ecc5ffad27db087d6cfa3a9f",
        "installed_path": "node_modules/.pnpm/effect@4.1.3/node_modules/effect"
      },
      {
        "importer": "packages/secret-provider-core",
        "name": "vite-plus",
        "version": "1.4.0",
        "package_json_sha256": "a2901e42e05a5f1c162b994ba85bfbad074a2f8921d129995b019e0bd48c9c09",
        "installed_path": "node_modules/.pnpm/vite-plus@1.4.0_@astrojs+compiler-rs@0.5.1_@types+node@24.12.4_@vitest+browser-playwrig_71b1ef4e5049c7accee71dd249ba4133/node_modules/vite-plus"
      },
      {
        "importer": "packages/secret-provider-onepassword",
        "name": "@effect/platform-node",
        "version": "4.1.2",
        "package_json_sha256": "2901f7c08e6011794c624e346b19f85a6b455338c3991578407c3028bd64800e",
        "installed_path": "node_modules/.pnpm/@effect+platform-node@4.1.2_bufferutil@4.1.0_effect@4.1.3_redis@6.2.1_utf-8-validate@6.0.6/node_modules/@effect/platform-node"
      },
      {
        "importer": "packages/secret-provider-onepassword",
        "name": "@effect/vitest",
        "version": "4.1.2",
        "package_json_sha256": "63fe8c287b8aa7420363f515f1d6330cfa5574430af94832dab4447afadcfc71",
        "installed_path": "node_modules/.pnpm/@effect+vitest@4.1.2_patch_hash=299510b71c36537a832a67e9d160a5f112a5f326a29e95c41cb45fc_81d3dd1e682774f4c17d7f713915765f/node_modules/@effect/vitest"
      },
      {
        "importer": "packages/secret-provider-onepassword",
        "name": "@types/node",
        "version": "24.12.4",
        "package_json_sha256": "456b1366f1966515c4dfec48446c82275502a2d5ea7cfbc74874323b39e3776f",
        "installed_path": "node_modules/.pnpm/@types+node@24.12.4/node_modules/@types/node"
      },
      {
        "importer": "packages/secret-provider-onepassword",
        "name": "effect",
        "version": "4.1.3",
        "package_json_sha256": "8ae4c5cf40f75346e2ab4dcacb692a98a6ddd814ecc5ffad27db087d6cfa3a9f",
        "installed_path": "node_modules/.pnpm/effect@4.1.3/node_modules/effect"
      },
      {
        "importer": "packages/secret-provider-onepassword",
        "name": "vite-plus",
        "version": "1.4.0",
        "package_json_sha256": "a2901e42e05a5f1c162b994ba85bfbad074a2f8921d129995b019e0bd48c9c09",
        "installed_path": "node_modules/.pnpm/vite-plus@1.4.0_@astrojs+compiler-rs@0.5.1_@types+node@24.12.4_@vitest+browser-playwrig_71b1ef4e5049c7accee71dd249ba4133/node_modules/vite-plus"
      },
      {
        "importer": "packages/shared",
        "name": "@effect/platform-node",
        "version": "4.1.2",
        "package_json_sha256": "2901f7c08e6011794c624e346b19f85a6b455338c3991578407c3028bd64800e",
        "installed_path": "node_modules/.pnpm/@effect+platform-node@4.1.2_bufferutil@4.1.0_effect@4.1.3_redis@6.2.1_utf-8-validate@6.0.6/node_modules/@effect/platform-node"
      },
      {
        "importer": "packages/shared",
        "name": "@effect/vitest",
        "version": "4.1.2",
        "package_json_sha256": "63fe8c287b8aa7420363f515f1d6330cfa5574430af94832dab4447afadcfc71",
        "installed_path": "node_modules/.pnpm/@effect+vitest@4.1.2_patch_hash=299510b71c36537a832a67e9d160a5f112a5f326a29e95c41cb45fc_81d3dd1e682774f4c17d7f713915765f/node_modules/@effect/vitest"
      },
      {
        "importer": "packages/shared",
        "name": "@noble/curves",
        "version": "1.9.1",
        "package_json_sha256": "d496cbba8f48a7407657170c84542e337e2fdfdc71bb7f5fd9e350daab119f31",
        "installed_path": "node_modules/.pnpm/@noble+curves@1.9.1/node_modules/@noble/curves"
      },
      {
        "importer": "packages/shared",
        "name": "@noble/hashes",
        "version": "1.8.0",
        "package_json_sha256": "7c4657c5e616c22cefa2691cc30670824a639dc71d97bf83925be2d239dc60e3",
        "installed_path": "node_modules/.pnpm/@noble+hashes@1.8.0/node_modules/@noble/hashes"
      },
      {
        "importer": "packages/shared",
        "name": "@types/mdast",
        "version": "4.0.4",
        "package_json_sha256": "5a41865d64d4cedba58313fad775cf56bd0474d724343172bcea9f8ad24db563",
        "installed_path": "node_modules/.pnpm/@types+mdast@4.0.4/node_modules/@types/mdast"
      },
      {
        "importer": "packages/shared",
        "name": "@types/node",
        "version": "24.12.4",
        "package_json_sha256": "456b1366f1966515c4dfec48446c82275502a2d5ea7cfbc74874323b39e3776f",
        "installed_path": "node_modules/.pnpm/@types+node@24.12.4/node_modules/@types/node"
      },
      {
        "importer": "packages/shared",
        "name": "effect",
        "version": "4.1.3",
        "package_json_sha256": "8ae4c5cf40f75346e2ab4dcacb692a98a6ddd814ecc5ffad27db087d6cfa3a9f",
        "installed_path": "node_modules/.pnpm/effect@4.1.3/node_modules/effect"
      },
      {
        "importer": "packages/shared",
        "name": "ffi-rs",
        "version": "1.3.2",
        "package_json_sha256": "a3f76613fbce43e44ba371ef743a72c6f3242f28a533f909140b402dd24a261f",
        "installed_path": "node_modules/.pnpm/ffi-rs@1.3.2/node_modules/ffi-rs"
      },
      {
        "importer": "packages/shared",
        "name": "mdast-util-directive",
        "version": "3.1.0",
        "package_json_sha256": "b4d5d332da2b09ba98af49baa65bbe1d953f3db4f2da3b115493e54584cc9009",
        "installed_path": "node_modules/.pnpm/mdast-util-directive@3.1.0_supports-color@8.1.1/node_modules/mdast-util-directive"
      },
      {
        "importer": "packages/shared",
        "name": "mdast-util-to-hast",
        "version": "13.2.1",
        "package_json_sha256": "aa1e17fedf46914534ba0c67016734edc6d0fc919057556eb1034160f795b596",
        "installed_path": "node_modules/.pnpm/mdast-util-to-hast@13.2.1_patch_hash=57ea46c73aea3c876ab8d351fe0482ddd081dcb4a0610576e399dbe5eb59d2b1/node_modules/mdast-util-to-hast"
      },
      {
        "importer": "packages/shared",
        "name": "micromark-extension-directive",
        "version": "4.0.0",
        "package_json_sha256": "eeab5d27227d5f97df653e0d08c8bea945681f4b41255b49cfa125ac7cf5a5a8",
        "installed_path": "node_modules/.pnpm/micromark-extension-directive@4.0.0/node_modules/micromark-extension-directive"
      },
      {
        "importer": "packages/shared",
        "name": "micromark-util-character",
        "version": "2.1.1",
        "package_json_sha256": "bf43c5df782cf1cf985d89a8f01fd1a7b7b4bae9bf2b9c07e633c2379b1dbd7f",
        "installed_path": "node_modules/.pnpm/micromark-util-character@2.1.1/node_modules/micromark-util-character"
      },
      {
        "importer": "packages/shared",
        "name": "micromark-util-types",
        "version": "2.0.2",
        "package_json_sha256": "4bf761498edc00e674903db57fc6a8cf478677363adc776b8ac115771e791cd3",
        "installed_path": "node_modules/.pnpm/micromark-util-types@2.0.2/node_modules/micromark-util-types"
      },
      {
        "importer": "packages/shared",
        "name": "property-information",
        "version": "7.2.0",
        "package_json_sha256": "6cacc66c65e31d11d9d4e5677c1375667faf334e585b69a9d319a0ca25676530",
        "installed_path": "node_modules/.pnpm/property-information@7.2.0/node_modules/property-information"
      },
      {
        "importer": "packages/shared",
        "name": "rehype-raw",
        "version": "7.0.0",
        "package_json_sha256": "b3313f6329e5b99fd26107f15d4a06bbd2644d1ee93f10fea5ee898be3248c05",
        "installed_path": "node_modules/.pnpm/rehype-raw@7.0.0/node_modules/rehype-raw"
      },
      {
        "importer": "packages/shared",
        "name": "rehype-sanitize",
        "version": "6.0.0",
        "package_json_sha256": "b8c794050d76ff903a42c31e8f7a18e85e966cf231b67d9363a81c0dd5157465",
        "installed_path": "node_modules/.pnpm/rehype-sanitize@6.0.0/node_modules/rehype-sanitize"
      },
      {
        "importer": "packages/shared",
        "name": "remark-breaks",
        "version": "4.0.0",
        "package_json_sha256": "df633e5c230d648c90bbfdfe5e75d28a2492af508a38b8751d9faf28af0443c6",
        "installed_path": "node_modules/.pnpm/remark-breaks@4.0.0/node_modules/remark-breaks"
      },
      {
        "importer": "packages/shared",
        "name": "remark-gfm",
        "version": "4.0.1",
        "package_json_sha256": "c199482a69355b610bd1ff225b097776d4a990445b11e5f4c618930dacc8c79d",
        "installed_path": "node_modules/.pnpm/remark-gfm@4.0.1_supports-color@8.1.1/node_modules/remark-gfm"
      },
      {
        "importer": "packages/shared",
        "name": "remark-math",
        "version": "6.0.0",
        "package_json_sha256": "936d400d2c2a3f121c4d2b6b84b8a891af02852032b0dcb31f0407d2d6a4364f",
        "installed_path": "node_modules/.pnpm/remark-math@6.0.0_supports-color@8.1.1/node_modules/remark-math"
      },
      {
        "importer": "packages/shared",
        "name": "remark-parse",
        "version": "11.0.0",
        "package_json_sha256": "47be70916ff853a6c35d8d858844c7b104d100f70999d579884859cf8d88a50c",
        "installed_path": "node_modules/.pnpm/remark-parse@11.0.0_supports-color@8.1.1/node_modules/remark-parse"
      },
      {
        "importer": "packages/shared",
        "name": "remark-rehype",
        "version": "11.1.2",
        "package_json_sha256": "f9886f99f9f38652d56ca256aa713e359e085ed42f7d89fd66671b49f4b83b64",
        "installed_path": "node_modules/.pnpm/remark-rehype@11.1.2/node_modules/remark-rehype"
      },
      {
        "importer": "packages/shared",
        "name": "unified",
        "version": "11.0.5",
        "package_json_sha256": "f91a44220f8b7c4a4de6ebaab6fc23b92d29a95cb7e5e6a7f0f24d199779fbad",
        "installed_path": "node_modules/.pnpm/unified@11.0.5/node_modules/unified"
      },
      {
        "importer": "packages/shared",
        "name": "vite-plus",
        "version": "1.4.0",
        "package_json_sha256": "a2901e42e05a5f1c162b994ba85bfbad074a2f8921d129995b019e0bd48c9c09",
        "installed_path": "node_modules/.pnpm/vite-plus@1.4.0_@astrojs+compiler-rs@0.5.1_@types+node@24.12.4_@vitest+browser-playwrig_71b1ef4e5049c7accee71dd249ba4133/node_modules/vite-plus"
      },
      {
        "importer": "packages/shared",
        "name": "yaml",
        "version": "2.9.0",
        "package_json_sha256": "20b8b197cbd10dad245d45e463dfe58e4c8c25a47e24bc4256ad9ab58bf35683",
        "installed_path": "node_modules/.pnpm/yaml@2.9.0/node_modules/yaml"
      },
      {
        "importer": "packages/source-control-azure-devops",
        "name": "@effect/platform-node",
        "version": "4.1.2",
        "package_json_sha256": "2901f7c08e6011794c624e346b19f85a6b455338c3991578407c3028bd64800e",
        "installed_path": "node_modules/.pnpm/@effect+platform-node@4.1.2_bufferutil@4.1.0_effect@4.1.3_redis@6.2.1_utf-8-validate@6.0.6/node_modules/@effect/platform-node"
      },
      {
        "importer": "packages/source-control-azure-devops",
        "name": "@effect/vitest",
        "version": "4.1.2",
        "package_json_sha256": "63fe8c287b8aa7420363f515f1d6330cfa5574430af94832dab4447afadcfc71",
        "installed_path": "node_modules/.pnpm/@effect+vitest@4.1.2_patch_hash=299510b71c36537a832a67e9d160a5f112a5f326a29e95c41cb45fc_81d3dd1e682774f4c17d7f713915765f/node_modules/@effect/vitest"
      },
      {
        "importer": "packages/source-control-azure-devops",
        "name": "@types/node",
        "version": "24.12.4",
        "package_json_sha256": "456b1366f1966515c4dfec48446c82275502a2d5ea7cfbc74874323b39e3776f",
        "installed_path": "node_modules/.pnpm/@types+node@24.12.4/node_modules/@types/node"
      },
      {
        "importer": "packages/source-control-azure-devops",
        "name": "diff",
        "version": "8.0.3",
        "package_json_sha256": "35b083dc3430465fbe066129e12debeb5416474e1db71abf7a8db9997789aeed",
        "installed_path": "node_modules/.pnpm/diff@8.0.3/node_modules/diff"
      },
      {
        "importer": "packages/source-control-azure-devops",
        "name": "effect",
        "version": "4.1.3",
        "package_json_sha256": "8ae4c5cf40f75346e2ab4dcacb692a98a6ddd814ecc5ffad27db087d6cfa3a9f",
        "installed_path": "node_modules/.pnpm/effect@4.1.3/node_modules/effect"
      },
      {
        "importer": "packages/source-control-azure-devops",
        "name": "vite-plus",
        "version": "1.4.0",
        "package_json_sha256": "a2901e42e05a5f1c162b994ba85bfbad074a2f8921d129995b019e0bd48c9c09",
        "installed_path": "node_modules/.pnpm/vite-plus@1.4.0_@astrojs+compiler-rs@0.5.1_@types+node@24.12.4_@vitest+browser-playwrig_71b1ef4e5049c7accee71dd249ba4133/node_modules/vite-plus"
      },
      {
        "importer": "packages/source-control-bitbucket",
        "name": "@effect/platform-node",
        "version": "4.1.2",
        "package_json_sha256": "2901f7c08e6011794c624e346b19f85a6b455338c3991578407c3028bd64800e",
        "installed_path": "node_modules/.pnpm/@effect+platform-node@4.1.2_bufferutil@4.1.0_effect@4.1.3_redis@6.2.1_utf-8-validate@6.0.6/node_modules/@effect/platform-node"
      },
      {
        "importer": "packages/source-control-bitbucket",
        "name": "@effect/vitest",
        "version": "4.1.2",
        "package_json_sha256": "63fe8c287b8aa7420363f515f1d6330cfa5574430af94832dab4447afadcfc71",
        "installed_path": "node_modules/.pnpm/@effect+vitest@4.1.2_patch_hash=299510b71c36537a832a67e9d160a5f112a5f326a29e95c41cb45fc_81d3dd1e682774f4c17d7f713915765f/node_modules/@effect/vitest"
      },
      {
        "importer": "packages/source-control-bitbucket",
        "name": "@types/node",
        "version": "24.12.4",
        "package_json_sha256": "456b1366f1966515c4dfec48446c82275502a2d5ea7cfbc74874323b39e3776f",
        "installed_path": "node_modules/.pnpm/@types+node@24.12.4/node_modules/@types/node"
      },
      {
        "importer": "packages/source-control-bitbucket",
        "name": "effect",
        "version": "4.1.3",
        "package_json_sha256": "8ae4c5cf40f75346e2ab4dcacb692a98a6ddd814ecc5ffad27db087d6cfa3a9f",
        "installed_path": "node_modules/.pnpm/effect@4.1.3/node_modules/effect"
      },
      {
        "importer": "packages/source-control-bitbucket",
        "name": "vite-plus",
        "version": "1.4.0",
        "package_json_sha256": "a2901e42e05a5f1c162b994ba85bfbad074a2f8921d129995b019e0bd48c9c09",
        "installed_path": "node_modules/.pnpm/vite-plus@1.4.0_@astrojs+compiler-rs@0.5.1_@types+node@24.12.4_@vitest+browser-playwrig_71b1ef4e5049c7accee71dd249ba4133/node_modules/vite-plus"
      },
      {
        "importer": "packages/source-control-core",
        "name": "@effect/vitest",
        "version": "4.1.2",
        "package_json_sha256": "63fe8c287b8aa7420363f515f1d6330cfa5574430af94832dab4447afadcfc71",
        "installed_path": "node_modules/.pnpm/@effect+vitest@4.1.2_patch_hash=299510b71c36537a832a67e9d160a5f112a5f326a29e95c41cb45fc_81d3dd1e682774f4c17d7f713915765f/node_modules/@effect/vitest"
      },
      {
        "importer": "packages/source-control-core",
        "name": "@types/node",
        "version": "24.12.4",
        "package_json_sha256": "456b1366f1966515c4dfec48446c82275502a2d5ea7cfbc74874323b39e3776f",
        "installed_path": "node_modules/.pnpm/@types+node@24.12.4/node_modules/@types/node"
      },
      {
        "importer": "packages/source-control-core",
        "name": "effect",
        "version": "4.1.3",
        "package_json_sha256": "8ae4c5cf40f75346e2ab4dcacb692a98a6ddd814ecc5ffad27db087d6cfa3a9f",
        "installed_path": "node_modules/.pnpm/effect@4.1.3/node_modules/effect"
      },
      {
        "importer": "packages/source-control-core",
        "name": "vite-plus",
        "version": "1.4.0",
        "package_json_sha256": "a2901e42e05a5f1c162b994ba85bfbad074a2f8921d129995b019e0bd48c9c09",
        "installed_path": "node_modules/.pnpm/vite-plus@1.4.0_@astrojs+compiler-rs@0.5.1_@types+node@24.12.4_@vitest+browser-playwrig_71b1ef4e5049c7accee71dd249ba4133/node_modules/vite-plus"
      },
      {
        "importer": "packages/source-control-cursor-origin",
        "name": "@effect/platform-node",
        "version": "4.1.2",
        "package_json_sha256": "2901f7c08e6011794c624e346b19f85a6b455338c3991578407c3028bd64800e",
        "installed_path": "node_modules/.pnpm/@effect+platform-node@4.1.2_bufferutil@4.1.0_effect@4.1.3_redis@6.2.1_utf-8-validate@6.0.6/node_modules/@effect/platform-node"
      },
      {
        "importer": "packages/source-control-cursor-origin",
        "name": "@effect/vitest",
        "version": "4.1.2",
        "package_json_sha256": "63fe8c287b8aa7420363f515f1d6330cfa5574430af94832dab4447afadcfc71",
        "installed_path": "node_modules/.pnpm/@effect+vitest@4.1.2_patch_hash=299510b71c36537a832a67e9d160a5f112a5f326a29e95c41cb45fc_81d3dd1e682774f4c17d7f713915765f/node_modules/@effect/vitest"
      },
      {
        "importer": "packages/source-control-cursor-origin",
        "name": "@types/node",
        "version": "24.12.4",
        "package_json_sha256": "456b1366f1966515c4dfec48446c82275502a2d5ea7cfbc74874323b39e3776f",
        "installed_path": "node_modules/.pnpm/@types+node@24.12.4/node_modules/@types/node"
      },
      {
        "importer": "packages/source-control-cursor-origin",
        "name": "effect",
        "version": "4.1.3",
        "package_json_sha256": "8ae4c5cf40f75346e2ab4dcacb692a98a6ddd814ecc5ffad27db087d6cfa3a9f",
        "installed_path": "node_modules/.pnpm/effect@4.1.3/node_modules/effect"
      },
      {
        "importer": "packages/source-control-cursor-origin",
        "name": "vite-plus",
        "version": "1.4.0",
        "package_json_sha256": "a2901e42e05a5f1c162b994ba85bfbad074a2f8921d129995b019e0bd48c9c09",
        "installed_path": "node_modules/.pnpm/vite-plus@1.4.0_@astrojs+compiler-rs@0.5.1_@types+node@24.12.4_@vitest+browser-playwrig_71b1ef4e5049c7accee71dd249ba4133/node_modules/vite-plus"
      },
      {
        "importer": "packages/source-control-forgejo",
        "name": "@effect/platform-node",
        "version": "4.1.2",
        "package_json_sha256": "2901f7c08e6011794c624e346b19f85a6b455338c3991578407c3028bd64800e",
        "installed_path": "node_modules/.pnpm/@effect+platform-node@4.1.2_bufferutil@4.1.0_effect@4.1.3_redis@6.2.1_utf-8-validate@6.0.6/node_modules/@effect/platform-node"
      },
      {
        "importer": "packages/source-control-forgejo",
        "name": "@effect/vitest",
        "version": "4.1.2",
        "package_json_sha256": "63fe8c287b8aa7420363f515f1d6330cfa5574430af94832dab4447afadcfc71",
        "installed_path": "node_modules/.pnpm/@effect+vitest@4.1.2_patch_hash=299510b71c36537a832a67e9d160a5f112a5f326a29e95c41cb45fc_81d3dd1e682774f4c17d7f713915765f/node_modules/@effect/vitest"
      },
      {
        "importer": "packages/source-control-forgejo",
        "name": "@types/node",
        "version": "24.12.4",
        "package_json_sha256": "456b1366f1966515c4dfec48446c82275502a2d5ea7cfbc74874323b39e3776f",
        "installed_path": "node_modules/.pnpm/@types+node@24.12.4/node_modules/@types/node"
      },
      {
        "importer": "packages/source-control-forgejo",
        "name": "effect",
        "version": "4.1.3",
        "package_json_sha256": "8ae4c5cf40f75346e2ab4dcacb692a98a6ddd814ecc5ffad27db087d6cfa3a9f",
        "installed_path": "node_modules/.pnpm/effect@4.1.3/node_modules/effect"
      },
      {
        "importer": "packages/source-control-forgejo",
        "name": "vite-plus",
        "version": "1.4.0",
        "package_json_sha256": "a2901e42e05a5f1c162b994ba85bfbad074a2f8921d129995b019e0bd48c9c09",
        "installed_path": "node_modules/.pnpm/vite-plus@1.4.0_@astrojs+compiler-rs@0.5.1_@types+node@24.12.4_@vitest+browser-playwrig_71b1ef4e5049c7accee71dd249ba4133/node_modules/vite-plus"
      },
      {
        "importer": "packages/source-control-gitcafe",
        "name": "@effect/vitest",
        "version": "4.1.2",
        "package_json_sha256": "63fe8c287b8aa7420363f515f1d6330cfa5574430af94832dab4447afadcfc71",
        "installed_path": "node_modules/.pnpm/@effect+vitest@4.1.2_patch_hash=299510b71c36537a832a67e9d160a5f112a5f326a29e95c41cb45fc_81d3dd1e682774f4c17d7f713915765f/node_modules/@effect/vitest"
      },
      {
        "importer": "packages/source-control-gitcafe",
        "name": "@types/node",
        "version": "24.12.4",
        "package_json_sha256": "456b1366f1966515c4dfec48446c82275502a2d5ea7cfbc74874323b39e3776f",
        "installed_path": "node_modules/.pnpm/@types+node@24.12.4/node_modules/@types/node"
      },
      {
        "importer": "packages/source-control-gitcafe",
        "name": "effect",
        "version": "4.1.3",
        "package_json_sha256": "8ae4c5cf40f75346e2ab4dcacb692a98a6ddd814ecc5ffad27db087d6cfa3a9f",
        "installed_path": "node_modules/.pnpm/effect@4.1.3/node_modules/effect"
      },
      {
        "importer": "packages/source-control-gitcafe",
        "name": "vite-plus",
        "version": "1.4.0",
        "package_json_sha256": "a2901e42e05a5f1c162b994ba85bfbad074a2f8921d129995b019e0bd48c9c09",
        "installed_path": "node_modules/.pnpm/vite-plus@1.4.0_@astrojs+compiler-rs@0.5.1_@types+node@24.12.4_@vitest+browser-playwrig_71b1ef4e5049c7accee71dd249ba4133/node_modules/vite-plus"
      },
      {
        "importer": "packages/source-control-github",
        "name": "@effect/graphql-generator",
        "version": "4.1.2",
        "package_json_sha256": "4940d91f457803adfc41e4533d83beaaafa9392144dff0a5a15ccf70a6ce8c23",
        "installed_path": "node_modules/.pnpm/@effect+graphql-generator@4.1.2_@effect+platform-node@4.1.2_bufferutil@4.1.0_effect@4.1_8afd10d0c5d2f7e73b67e0d1a4ca0336/node_modules/@effect/graphql-generator"
      },
      {
        "importer": "packages/source-control-github",
        "name": "@effect/platform-node",
        "version": "4.1.2",
        "package_json_sha256": "2901f7c08e6011794c624e346b19f85a6b455338c3991578407c3028bd64800e",
        "installed_path": "node_modules/.pnpm/@effect+platform-node@4.1.2_bufferutil@4.1.0_effect@4.1.3_redis@6.2.1_utf-8-validate@6.0.6/node_modules/@effect/platform-node"
      },
      {
        "importer": "packages/source-control-github",
        "name": "@effect/vitest",
        "version": "4.1.2",
        "package_json_sha256": "63fe8c287b8aa7420363f515f1d6330cfa5574430af94832dab4447afadcfc71",
        "installed_path": "node_modules/.pnpm/@effect+vitest@4.1.2_patch_hash=299510b71c36537a832a67e9d160a5f112a5f326a29e95c41cb45fc_81d3dd1e682774f4c17d7f713915765f/node_modules/@effect/vitest"
      },
      {
        "importer": "packages/source-control-github",
        "name": "@types/node",
        "version": "24.12.4",
        "package_json_sha256": "456b1366f1966515c4dfec48446c82275502a2d5ea7cfbc74874323b39e3776f",
        "installed_path": "node_modules/.pnpm/@types+node@24.12.4/node_modules/@types/node"
      },
      {
        "importer": "packages/source-control-github",
        "name": "effect",
        "version": "4.1.3",
        "package_json_sha256": "8ae4c5cf40f75346e2ab4dcacb692a98a6ddd814ecc5ffad27db087d6cfa3a9f",
        "installed_path": "node_modules/.pnpm/effect@4.1.3/node_modules/effect"
      },
      {
        "importer": "packages/source-control-github",
        "name": "vite-plus",
        "version": "1.4.0",
        "package_json_sha256": "a2901e42e05a5f1c162b994ba85bfbad074a2f8921d129995b019e0bd48c9c09",
        "installed_path": "node_modules/.pnpm/vite-plus@1.4.0_@astrojs+compiler-rs@0.5.1_@types+node@24.12.4_@vitest+browser-playwrig_71b1ef4e5049c7accee71dd249ba4133/node_modules/vite-plus"
      },
      {
        "importer": "packages/source-control-gitlab",
        "name": "@effect/vitest",
        "version": "4.1.2",
        "package_json_sha256": "63fe8c287b8aa7420363f515f1d6330cfa5574430af94832dab4447afadcfc71",
        "installed_path": "node_modules/.pnpm/@effect+vitest@4.1.2_patch_hash=299510b71c36537a832a67e9d160a5f112a5f326a29e95c41cb45fc_81d3dd1e682774f4c17d7f713915765f/node_modules/@effect/vitest"
      },
      {
        "importer": "packages/source-control-gitlab",
        "name": "@types/node",
        "version": "24.12.4",
        "package_json_sha256": "456b1366f1966515c4dfec48446c82275502a2d5ea7cfbc74874323b39e3776f",
        "installed_path": "node_modules/.pnpm/@types+node@24.12.4/node_modules/@types/node"
      },
      {
        "importer": "packages/source-control-gitlab",
        "name": "effect",
        "version": "4.1.3",
        "package_json_sha256": "8ae4c5cf40f75346e2ab4dcacb692a98a6ddd814ecc5ffad27db087d6cfa3a9f",
        "installed_path": "node_modules/.pnpm/effect@4.1.3/node_modules/effect"
      },
      {
        "importer": "packages/source-control-gitlab",
        "name": "vite-plus",
        "version": "1.4.0",
        "package_json_sha256": "a2901e42e05a5f1c162b994ba85bfbad074a2f8921d129995b019e0bd48c9c09",
        "installed_path": "node_modules/.pnpm/vite-plus@1.4.0_@astrojs+compiler-rs@0.5.1_@types+node@24.12.4_@vitest+browser-playwrig_71b1ef4e5049c7accee71dd249ba4133/node_modules/vite-plus"
      },
      {
        "importer": "packages/source-control-testing",
        "name": "@effect/platform-node",
        "version": "4.1.2",
        "package_json_sha256": "2901f7c08e6011794c624e346b19f85a6b455338c3991578407c3028bd64800e",
        "installed_path": "node_modules/.pnpm/@effect+platform-node@4.1.2_bufferutil@4.1.0_effect@4.1.3_redis@6.2.1_utf-8-validate@6.0.6/node_modules/@effect/platform-node"
      },
      {
        "importer": "packages/source-control-testing",
        "name": "@types/node",
        "version": "24.12.4",
        "package_json_sha256": "456b1366f1966515c4dfec48446c82275502a2d5ea7cfbc74874323b39e3776f",
        "installed_path": "node_modules/.pnpm/@types+node@24.12.4/node_modules/@types/node"
      },
      {
        "importer": "packages/source-control-testing",
        "name": "effect",
        "version": "4.1.3",
        "package_json_sha256": "8ae4c5cf40f75346e2ab4dcacb692a98a6ddd814ecc5ffad27db087d6cfa3a9f",
        "installed_path": "node_modules/.pnpm/effect@4.1.3/node_modules/effect"
      },
      {
        "importer": "packages/ssh",
        "name": "@effect/platform-node",
        "version": "4.1.2",
        "package_json_sha256": "2901f7c08e6011794c624e346b19f85a6b455338c3991578407c3028bd64800e",
        "installed_path": "node_modules/.pnpm/@effect+platform-node@4.1.2_bufferutil@4.1.0_effect@4.1.3_redis@6.2.1_utf-8-validate@6.0.6/node_modules/@effect/platform-node"
      },
      {
        "importer": "packages/ssh",
        "name": "@effect/vitest",
        "version": "4.1.2",
        "package_json_sha256": "63fe8c287b8aa7420363f515f1d6330cfa5574430af94832dab4447afadcfc71",
        "installed_path": "node_modules/.pnpm/@effect+vitest@4.1.2_patch_hash=299510b71c36537a832a67e9d160a5f112a5f326a29e95c41cb45fc_81d3dd1e682774f4c17d7f713915765f/node_modules/@effect/vitest"
      },
      {
        "importer": "packages/ssh",
        "name": "@types/node",
        "version": "24.12.4",
        "package_json_sha256": "456b1366f1966515c4dfec48446c82275502a2d5ea7cfbc74874323b39e3776f",
        "installed_path": "node_modules/.pnpm/@types+node@24.12.4/node_modules/@types/node"
      },
      {
        "importer": "packages/ssh",
        "name": "effect",
        "version": "4.1.3",
        "package_json_sha256": "8ae4c5cf40f75346e2ab4dcacb692a98a6ddd814ecc5ffad27db087d6cfa3a9f",
        "installed_path": "node_modules/.pnpm/effect@4.1.3/node_modules/effect"
      },
      {
        "importer": "packages/ssh",
        "name": "vite-plus",
        "version": "1.4.0",
        "package_json_sha256": "a2901e42e05a5f1c162b994ba85bfbad074a2f8921d129995b019e0bd48c9c09",
        "installed_path": "node_modules/.pnpm/vite-plus@1.4.0_@astrojs+compiler-rs@0.5.1_@types+node@24.12.4_@vitest+browser-playwrig_71b1ef4e5049c7accee71dd249ba4133/node_modules/vite-plus"
      },
      {
        "importer": "packages/tailscale",
        "name": "@effect/vitest",
        "version": "4.1.2",
        "package_json_sha256": "63fe8c287b8aa7420363f515f1d6330cfa5574430af94832dab4447afadcfc71",
        "installed_path": "node_modules/.pnpm/@effect+vitest@4.1.2_patch_hash=299510b71c36537a832a67e9d160a5f112a5f326a29e95c41cb45fc_81d3dd1e682774f4c17d7f713915765f/node_modules/@effect/vitest"
      },
      {
        "importer": "packages/tailscale",
        "name": "@types/node",
        "version": "24.12.4",
        "package_json_sha256": "456b1366f1966515c4dfec48446c82275502a2d5ea7cfbc74874323b39e3776f",
        "installed_path": "node_modules/.pnpm/@types+node@24.12.4/node_modules/@types/node"
      },
      {
        "importer": "packages/tailscale",
        "name": "effect",
        "version": "4.1.3",
        "package_json_sha256": "8ae4c5cf40f75346e2ab4dcacb692a98a6ddd814ecc5ffad27db087d6cfa3a9f",
        "installed_path": "node_modules/.pnpm/effect@4.1.3/node_modules/effect"
      },
      {
        "importer": "packages/tailscale",
        "name": "vite-plus",
        "version": "1.4.0",
        "package_json_sha256": "a2901e42e05a5f1c162b994ba85bfbad074a2f8921d129995b019e0bd48c9c09",
        "installed_path": "node_modules/.pnpm/vite-plus@1.4.0_@astrojs+compiler-rs@0.5.1_@types+node@24.12.4_@vitest+browser-playwrig_71b1ef4e5049c7accee71dd249ba4133/node_modules/vite-plus"
      }
    ],
    "resolved_runtime": [
      {
        "importer": "apps/server",
        "name": "@anthropic-ai/claude-agent-sdk",
        "expected_version": "0.3.321",
        "actual_version": "0.3.321",
        "package_json_sha256": "b2e2de05b39aad8a090c5b11c51ccf021e98ac7e781e696c7062001bf383f7e4",
        "installed_path": "node_modules/.pnpm/@anthropic-ai+claude-agent-sdk@0.3.321_@anthropic-ai+sdk@0.93.0_zod@4.6.7__@modelcontex_38f3fb20daecd36772d693f4f262e843/node_modules/@anthropic-ai/claude-agent-sdk"
      },
      {
        "importer": "apps/server",
        "name": "@cursor/sdk",
        "expected_version": "1.2.0",
        "actual_version": "1.2.0",
        "package_json_sha256": "55a97a0dbb3adb899c4b8ec07b306d5d0e226d03ea4f42f8a1dfc30b9db98dcd",
        "installed_path": "node_modules/.pnpm/@cursor+sdk@1.2.0_patch_hash=57f502128bf6accd976963b126e227c86a45d815a53a8dc450461beae3bed4a4_zod@4.6.7/node_modules/@cursor/sdk"
      },
      {
        "importer": "apps/server",
        "name": "@effect/platform-node",
        "expected_version": "4.1.2",
        "actual_version": "4.1.2",
        "package_json_sha256": "2901f7c08e6011794c624e346b19f85a6b455338c3991578407c3028bd64800e",
        "installed_path": "node_modules/.pnpm/@effect+platform-node@4.1.2_bufferutil@4.1.0_effect@4.1.3_redis@6.2.1_utf-8-validate@6.0.6/node_modules/@effect/platform-node"
      },
      {
        "importer": "apps/server",
        "name": "@effect/platform-node-shared",
        "expected_version": "4.1.2",
        "actual_version": "4.1.2",
        "package_json_sha256": "468eaad86adb8ab70c025deb373f4c31e75ea0c19eadde1c15c114e99a372d66",
        "installed_path": "node_modules/.pnpm/@effect+platform-node-shared@4.1.2_bufferutil@4.1.0_effect@4.1.3_utf-8-validate@6.0.6/node_modules/@effect/platform-node-shared"
      },
      {
        "importer": "apps/server",
        "name": "@ff-labs/fff-node",
        "expected_version": "0.11.0",
        "actual_version": "0.11.0",
        "package_json_sha256": "ba3162477649ba95e1c4efcb38344c3fb43dba889fc96c406bec5889cca37ae6",
        "installed_path": "node_modules/.pnpm/@ff-labs+fff-node@0.11.0_patch_hash=3be7107340e5f388114da259637828cd47f2b32eb8ae572440715c4e38cffe6e/node_modules/@ff-labs/fff-node"
      },
      {
        "importer": "apps/server",
        "name": "@muse-code/sdk",
        "expected_version": "1.4.6",
        "actual_version": "1.4.6",
        "package_json_sha256": "44d2806ed5a24e8ee6aaacaa6259f2a7660ee5b34d53875fd97960d3e5a8b4ef",
        "installed_path": "node_modules/.pnpm/@muse-code+sdk@1.4.6_patch_hash=7b495b607fc5d76b444c7c4d58821e839726a30e6f3c53564f0d59f2d5b42101_@types+node@24.12.4/node_modules/@muse-code/sdk"
      },
      {
        "importer": "apps/server",
        "name": "@napi-rs/keyring",
        "expected_version": "1.3.0",
        "actual_version": "1.3.0",
        "package_json_sha256": "21c83c2e09639253133bd17d9f1832aa46cd9087850cb9d5ede81de1002ad242",
        "installed_path": "node_modules/.pnpm/@napi-rs+keyring@1.3.0/node_modules/@napi-rs/keyring"
      },
      {
        "importer": "apps/server",
        "name": "character-entities",
        "expected_version": "2.0.2",
        "actual_version": "2.0.2",
        "package_json_sha256": "3eaa974f1a9ede7187797d85eb1c799616144cd5ff75d094d30a44bec7d07d88",
        "installed_path": "node_modules/.pnpm/character-entities@2.0.2/node_modules/character-entities"
      },
      {
        "importer": "apps/server",
        "name": "diff",
        "expected_version": "8.0.3",
        "actual_version": "8.0.3",
        "package_json_sha256": "35b083dc3430465fbe066129e12debeb5416474e1db71abf7a8db9997789aeed",
        "installed_path": "node_modules/.pnpm/diff@8.0.3/node_modules/diff"
      },
      {
        "importer": "apps/server",
        "name": "effect",
        "expected_version": "4.1.3",
        "actual_version": "4.1.3",
        "package_json_sha256": "8ae4c5cf40f75346e2ab4dcacb692a98a6ddd814ecc5ffad27db087d6cfa3a9f",
        "installed_path": "node_modules/.pnpm/effect@4.1.3/node_modules/effect"
      },
      {
        "importer": "apps/server",
        "name": "ffi-rs",
        "expected_version": "1.3.2",
        "actual_version": "1.3.2",
        "package_json_sha256": "a3f76613fbce43e44ba371ef743a72c6f3242f28a533f909140b402dd24a261f",
        "installed_path": "node_modules/.pnpm/ffi-rs@1.3.2/node_modules/ffi-rs"
      },
      {
        "importer": "apps/server",
        "name": "node-pty",
        "expected_version": "1.2.0-beta.15",
        "actual_version": "1.2.0-beta.15",
        "package_json_sha256": "f4a19bbc7cf4c2e35c081e6a18a3d11d21c54c2f3cc25bfe48142742a781b71d",
        "installed_path": "node_modules/.pnpm/node-pty@1.2.0-beta.15_patch_hash=f1e680afec85f650699ea756f91f469844ec4c976f4f168492a45c6b3f67d651/node_modules/node-pty"
      },
      {
        "importer": "apps/server",
        "name": "playwright-core",
        "expected_version": "1.64.1",
        "actual_version": "1.64.1",
        "package_json_sha256": "8aa1c9863fa8dea324e674254158cdc79440f4124ef2d84d38053013541cb7d6",
        "installed_path": "node_modules/.pnpm/playwright-core@1.64.1/node_modules/playwright-core"
      },
      {
        "importer": "apps/server",
        "name": "proper-lockfile",
        "expected_version": "4.1.2",
        "actual_version": "4.1.2",
        "package_json_sha256": "23888ecc7abd83a8e98e132da556eda2172792cc04c4e6d157b590667802bd2a",
        "installed_path": "node_modules/.pnpm/proper-lockfile@4.1.2/node_modules/proper-lockfile"
      },
      {
        "importer": "apps/server",
        "name": "saxes",
        "expected_version": "6.0.0",
        "actual_version": "6.0.0",
        "package_json_sha256": "32052572b41c2a890ed0854798c48454cc5991dcaafe5fb1718a4253046acfd3",
        "installed_path": "node_modules/.pnpm/saxes@6.0.0/node_modules/saxes"
      },
      {
        "importer": "apps/server",
        "name": "stream-chain",
        "expected_version": "4.2.5",
        "actual_version": "4.2.5",
        "package_json_sha256": "cd1b7376663c88e3dbb321be142253529b9d41f32c1e980ea92c535b934c6941",
        "installed_path": "node_modules/.pnpm/stream-chain@4.2.5/node_modules/stream-chain"
      },
      {
        "importer": "apps/server",
        "name": "stream-json",
        "expected_version": "3.7.0",
        "actual_version": "3.7.0",
        "package_json_sha256": "9176f5b9015cc834212dc64b5d4e0698c6e309037b622b3bdd5b17aa5d321059",
        "installed_path": "node_modules/.pnpm/stream-json@3.7.0/node_modules/stream-json"
      },
      {
        "importer": "apps/server",
        "name": "transcribe-cpp",
        "expected_version": "0.4.1",
        "actual_version": "0.4.1",
        "package_json_sha256": "06a8cfd522f531cc1f0a82f8db85c6ba1d5969f67512eb7f872f7398140640dd",
        "installed_path": "node_modules/.pnpm/transcribe-cpp@0.4.1/node_modules/transcribe-cpp"
      },
      {
        "importer": "apps/server",
        "name": "undici",
        "expected_version": "8.12.4",
        "actual_version": "8.12.4",
        "package_json_sha256": "1c0aa5632e07578a71cd3c31fe7a75c85e7d0071ec5238a302d4b5a11aeed5b7",
        "installed_path": "node_modules/.pnpm/undici@8.12.4/node_modules/undici"
      },
      {
        "importer": "apps/server",
        "name": "yaml",
        "expected_version": "2.9.0",
        "actual_version": "2.9.0",
        "package_json_sha256": "20b8b197cbd10dad245d45e463dfe58e4c8c25a47e24bc4256ad9ab58bf35683",
        "installed_path": "node_modules/.pnpm/yaml@2.9.0/node_modules/yaml"
      },
      {
        "importer": "apps/server",
        "name": "yauzl",
        "expected_version": "3.4.0",
        "actual_version": "3.4.0",
        "package_json_sha256": "d7d5418b74b185df4ad276b73cf1e36040dd417d22520354e609e2748a29fcbd",
        "installed_path": "node_modules/.pnpm/yauzl@3.4.0/node_modules/yauzl"
      },
      {
        "importer": "apps/server",
        "name": "zod",
        "expected_version": "4.6.7",
        "actual_version": "4.6.7",
        "package_json_sha256": "c2d190d9ee4e0bdb60332aaa2130a6a98d65ddb903fe1d29248b15de57832c45",
        "installed_path": "node_modules/.pnpm/zod@4.6.7/node_modules/zod"
      },
      {
        "importer": "packages/shared",
        "name": "@noble/curves",
        "expected_version": "1.9.1",
        "actual_version": "1.9.1",
        "package_json_sha256": "d496cbba8f48a7407657170c84542e337e2fdfdc71bb7f5fd9e350daab119f31",
        "installed_path": "node_modules/.pnpm/@noble+curves@1.9.1/node_modules/@noble/curves"
      },
      {
        "importer": "packages/shared",
        "name": "@noble/hashes",
        "expected_version": "1.8.0",
        "actual_version": "1.8.0",
        "package_json_sha256": "7c4657c5e616c22cefa2691cc30670824a639dc71d97bf83925be2d239dc60e3",
        "installed_path": "node_modules/.pnpm/@noble+hashes@1.8.0/node_modules/@noble/hashes"
      },
      {
        "importer": "packages/shared",
        "name": "effect",
        "expected_version": "4.1.3",
        "actual_version": "4.1.3",
        "package_json_sha256": "8ae4c5cf40f75346e2ab4dcacb692a98a6ddd814ecc5ffad27db087d6cfa3a9f",
        "installed_path": "node_modules/.pnpm/effect@4.1.3/node_modules/effect"
      },
      {
        "importer": "packages/shared",
        "name": "ffi-rs",
        "expected_version": "1.3.2",
        "actual_version": "1.3.2",
        "package_json_sha256": "a3f76613fbce43e44ba371ef743a72c6f3242f28a533f909140b402dd24a261f",
        "installed_path": "node_modules/.pnpm/ffi-rs@1.3.2/node_modules/ffi-rs"
      },
      {
        "importer": "packages/shared",
        "name": "mdast-util-directive",
        "expected_version": "3.1.0",
        "actual_version": "3.1.0",
        "package_json_sha256": "b4d5d332da2b09ba98af49baa65bbe1d953f3db4f2da3b115493e54584cc9009",
        "installed_path": "node_modules/.pnpm/mdast-util-directive@3.1.0_supports-color@8.1.1/node_modules/mdast-util-directive"
      },
      {
        "importer": "packages/shared",
        "name": "mdast-util-to-hast",
        "expected_version": "13.2.1",
        "actual_version": "13.2.1",
        "package_json_sha256": "aa1e17fedf46914534ba0c67016734edc6d0fc919057556eb1034160f795b596",
        "installed_path": "node_modules/.pnpm/mdast-util-to-hast@13.2.1_patch_hash=57ea46c73aea3c876ab8d351fe0482ddd081dcb4a0610576e399dbe5eb59d2b1/node_modules/mdast-util-to-hast"
      },
      {
        "importer": "packages/shared",
        "name": "micromark-extension-directive",
        "expected_version": "4.0.0",
        "actual_version": "4.0.0",
        "package_json_sha256": "eeab5d27227d5f97df653e0d08c8bea945681f4b41255b49cfa125ac7cf5a5a8",
        "installed_path": "node_modules/.pnpm/micromark-extension-directive@4.0.0/node_modules/micromark-extension-directive"
      },
      {
        "importer": "packages/shared",
        "name": "micromark-util-character",
        "expected_version": "2.1.1",
        "actual_version": "2.1.1",
        "package_json_sha256": "bf43c5df782cf1cf985d89a8f01fd1a7b7b4bae9bf2b9c07e633c2379b1dbd7f",
        "installed_path": "node_modules/.pnpm/micromark-util-character@2.1.1/node_modules/micromark-util-character"
      },
      {
        "importer": "packages/shared",
        "name": "property-information",
        "expected_version": "7.2.0",
        "actual_version": "7.2.0",
        "package_json_sha256": "6cacc66c65e31d11d9d4e5677c1375667faf334e585b69a9d319a0ca25676530",
        "installed_path": "node_modules/.pnpm/property-information@7.2.0/node_modules/property-information"
      },
      {
        "importer": "packages/shared",
        "name": "rehype-raw",
        "expected_version": "7.0.0",
        "actual_version": "7.0.0",
        "package_json_sha256": "b3313f6329e5b99fd26107f15d4a06bbd2644d1ee93f10fea5ee898be3248c05",
        "installed_path": "node_modules/.pnpm/rehype-raw@7.0.0/node_modules/rehype-raw"
      },
      {
        "importer": "packages/shared",
        "name": "rehype-sanitize",
        "expected_version": "6.0.0",
        "actual_version": "6.0.0",
        "package_json_sha256": "b8c794050d76ff903a42c31e8f7a18e85e966cf231b67d9363a81c0dd5157465",
        "installed_path": "node_modules/.pnpm/rehype-sanitize@6.0.0/node_modules/rehype-sanitize"
      },
      {
        "importer": "packages/shared",
        "name": "remark-breaks",
        "expected_version": "4.0.0",
        "actual_version": "4.0.0",
        "package_json_sha256": "df633e5c230d648c90bbfdfe5e75d28a2492af508a38b8751d9faf28af0443c6",
        "installed_path": "node_modules/.pnpm/remark-breaks@4.0.0/node_modules/remark-breaks"
      },
      {
        "importer": "packages/shared",
        "name": "remark-gfm",
        "expected_version": "4.0.1",
        "actual_version": "4.0.1",
        "package_json_sha256": "c199482a69355b610bd1ff225b097776d4a990445b11e5f4c618930dacc8c79d",
        "installed_path": "node_modules/.pnpm/remark-gfm@4.0.1_supports-color@8.1.1/node_modules/remark-gfm"
      },
      {
        "importer": "packages/shared",
        "name": "remark-math",
        "expected_version": "6.0.0",
        "actual_version": "6.0.0",
        "package_json_sha256": "936d400d2c2a3f121c4d2b6b84b8a891af02852032b0dcb31f0407d2d6a4364f",
        "installed_path": "node_modules/.pnpm/remark-math@6.0.0_supports-color@8.1.1/node_modules/remark-math"
      },
      {
        "importer": "packages/shared",
        "name": "remark-parse",
        "expected_version": "11.0.0",
        "actual_version": "11.0.0",
        "package_json_sha256": "47be70916ff853a6c35d8d858844c7b104d100f70999d579884859cf8d88a50c",
        "installed_path": "node_modules/.pnpm/remark-parse@11.0.0_supports-color@8.1.1/node_modules/remark-parse"
      },
      {
        "importer": "packages/shared",
        "name": "remark-rehype",
        "expected_version": "11.1.2",
        "actual_version": "11.1.2",
        "package_json_sha256": "f9886f99f9f38652d56ca256aa713e359e085ed42f7d89fd66671b49f4b83b64",
        "installed_path": "node_modules/.pnpm/remark-rehype@11.1.2/node_modules/remark-rehype"
      },
      {
        "importer": "packages/shared",
        "name": "unified",
        "expected_version": "11.0.5",
        "actual_version": "11.0.5",
        "package_json_sha256": "f91a44220f8b7c4a4de6ebaab6fc23b92d29a95cb7e5e6a7f0f24d199779fbad",
        "installed_path": "node_modules/.pnpm/unified@11.0.5/node_modules/unified"
      },
      {
        "importer": "packages/shared",
        "name": "yaml",
        "expected_version": "2.9.0",
        "actual_version": "2.9.0",
        "package_json_sha256": "20b8b197cbd10dad245d45e463dfe58e4c8c25a47e24bc4256ad9ab58bf35683",
        "installed_path": "node_modules/.pnpm/yaml@2.9.0/node_modules/yaml"
      },
      {
        "importer": "packages/contracts",
        "name": "effect",
        "expected_version": "4.1.3",
        "actual_version": "4.1.3",
        "package_json_sha256": "8ae4c5cf40f75346e2ab4dcacb692a98a6ddd814ecc5ffad27db087d6cfa3a9f",
        "installed_path": "node_modules/.pnpm/effect@4.1.3/node_modules/effect"
      }
    ],
    "runtime_provenance": {
      "status": "verified",
      "issues": [],
      "package_manager": "pnpm@12.14.0",
      "installed_lock_sha256": "f155f609971b8e9c031c4e5ebac811211c0b87f51adca7f60046ba0f5a9c5ceb",
      "modules_metadata_sha256": "e579435d7d216c3cf4591889db41dfd545f3b4b26fe1bee5bf6fbf3e56f3fb4d",
      "installed_lock_matches_application_lock": true,
      "node_executable_sha256": "08f12d42fb304468e8ee86247fe686aae5b225836ea65e9d6566c11ae6ba2e8e",
      "external_packages_within_virtual_store": true,
      "external_resolution_sha256": "215febeb42c657ec13ce66c7da4ce621ee7f87a4eefcf0a4a521955a085e897f",
      "per_workspace_resolution": true
    },
    "sqlite_wrapper_sha256": "4c758731477f83a648dcc33fe0a79a18b5ae4b56fb53f7f6c97a80a32468e180",
    "resolution": "Every relative and workspace import resolves inside the pinned upstream export. Each workspace retains its actual installed external dependency and peer-instance targets; qualification requires those targets inside the source-matched frozen pnpm virtual store."
  },
  "durability": {
    "upstream": {
      "journal_mode": "wal",
      "synchronous": "NORMAL",
      "synchronous_numeric": 1,
      "reader_worker": true,
      "writer_worker": true
    },
    "native": {
      "engine": "omdb",
      "durability": "Immediate"
    },
    "comparison": "Actual selected production defaults; stronger native commit durability is preserved and any cost is included in visit-commit."
  },
  "sources": {
    "tools/performance-persistence.mjs": "9655edb1bbcec0cab60c2847cb70728884e03bcf7a9f3b39244e911dc1c61c6d",
    "tools/performance-worker.mjs": "8678ada514f86bfc83e82871d4e067cfd982342d8eefb3a3e45e09a52baa36ce",
    "tools/performance-statistics.mjs": "47ed48c3d848ac3681b4e425912e26205e4eeb96beaa14ae0cc84806b8bd8bbb",
    "tools/performance-contract.json": "c5c48c1ede643bb80c10f786bb82898a3dec71eb89a652d81135b2ed3dbdcb36",
    "tools/performance-baseline.mjs": "3bcf93571bb65db34dd798810e5198ce7e3e330cdb5034da0259607b00999ddf",
    "tools/performance-memory.mjs": "413c459bf61efe030323086dcab67ddaebb23ad473e72db455947b8e12c3f175",
    "tools/performance-runtime.mjs": "b4931091de9c14bb1cf7d94cdf9ad01c135a5f8afa4cdf96e74b440b719fa769",
    "tools/performance-filesystem.mjs": "c9557b4c5d9d5aa2a8886ce7c4a8b16d47acb2c165e3238fa1c2ea07cb954fb9",
    "apps/server/src/persistence/Omdb.ts": "d419cee6b7141d349c9e62501734cac29fa002a16e746a40f02a6af114f51bc1",
    "apps/server/src/orchestration-v2/NativeProjectionStore.ts": "eb22ff076bbd889ce9eaa72ecb3d7bcca313496bb31058fab4bf92ff958c6fa7",
    "apps/server/src/orchestration-v2/NativeThreadSearch.ts": "ebdea6dfe28aebfbd02eeee8afbabce8be64ccdb277de2f646d2d181429deddd",
    "apps/server/src/persistence/omdb-schema.json": "395b45dba23c8c59851ff0af055023d7536b0e76059fc613f1b96b6e5244a502",
    "crates/storage/src/backend.rs": "0037d45539c089faa953a3f6e067de57830b6e533f8b55d2dbcd19886af96f33"
  }
}
```

Raw process order, every request duration, GC observations and sampled process-tree RSS are in performance.json and the worker JSON files. No result row is omitted.
