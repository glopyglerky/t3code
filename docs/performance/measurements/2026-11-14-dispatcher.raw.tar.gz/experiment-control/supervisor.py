import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess


ROOT = Path('/workspace/scratch/fcf5fdf8376a/t3code-ls')
SCRATCH = ROOT.parent
OUTPUT = SCRATCH / 't3-performance-dispatcher-01'
BACKUP = SCRATCH / 't3-performance-clean-root-aliases-02'
HELPER = SCRATCH / 't3-target/release/t3-code-ls-db'
HELPER_SHA256 = '9700ef49aa1131364ac5a220cfb5004e4ff4244f135e7d95bf305525606c077e'
EVIDENCE = SCRATCH / 't3-performance-dispatcher-01.filesystem.json'
FIXTURES = SCRATCH / 't3-performance-dispatcher-fixtures'
ENVIRONMENT = os.environ.copy()
ENVIRONMENT['PATH'] = str(SCRATCH / 't3-runtime/node_modules/.bin') + ':' + ENVIRONMENT['PATH']
ENVIRONMENT['T3_CODE_LS_TEST_RUNTIME'] = str(SCRATCH / 't3-test-runtime')
ENVIRONMENT['T3CODE_DEV_SEED'] = '0'
ENVIRONMENT['TMPDIR'] = str(FIXTURES)


def current_time():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def filesystem_snapshot():
    data = {'observed_at': current_time(), 'paths': {}}
    for path in ['/tmp', '/workspace', str(FIXTURES)]:
        stat = os.statvfs(path)
        data['paths'][path] = {key: getattr(stat, key) for key in [
            'f_bsize', 'f_frsize', 'f_blocks', 'f_bfree', 'f_bavail',
            'f_files', 'f_ffree', 'f_favail', 'f_flag', 'f_namemax',
        ]}
        data['paths'][path]['available_bytes'] = stat.f_bavail * stat.f_frsize
    data['df_bytes'] = subprocess.check_output(
        ['df', '-B1', '-T', '/tmp', '/workspace', str(FIXTURES)], text=True,
    )
    return data


def interrupted(signum, frame):
    raise KeyboardInterrupt(f'Supervisor received signal {signum}')


assert not OUTPUT.exists(), 'Use a fresh output directory'
assert not BACKUP.exists(), 'Use a fresh alias backup directory'
assert not EVIDENCE.exists(), 'Preserve previous filesystem evidence'
assert not FIXTURES.exists(), 'Use a fresh task-owned fixture root'
assert hashlib.sha256(HELPER.read_bytes()).hexdigest() == HELPER_SHA256
assert not subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=normal'], cwd=ROOT, text=True).strip()
assert subprocess.check_output(['node', '--version'], env=ENVIRONMENT, text=True).strip() == 'v26.12.1'
assert ENVIRONMENT.get('T3_CODE_LS_TEST_TMPDIR') is None, 'Do not override the selected TMPDIR fixture root'
FIXTURES.mkdir()
assert subprocess.check_output(['node', '--input-type=module', '-e', 'import { tmpdir } from "node:os"; console.log(tmpdir());'], env=ENVIRONMENT, text=True).strip() == str(FIXTURES)

BACKUP.mkdir()
modules = ROOT / 'node_modules'
manifest = json.loads((ROOT / 'package.json').read_text())
keep = set()
for key in ['dependencies', 'devDependencies', 'optionalDependencies']:
    keep.update(manifest.get(key, {}))
keep.update(['effect', '@effect/platform-node', 'yaml', '@t3tools/contracts', '@t3tools/shared'])
entries = []
for path in sorted(modules.iterdir()):
    if path.name.startswith('.'):
        continue
    if path.name.startswith('@') and path.is_dir() and not path.is_symlink():
        entries.extend(sorted(path.iterdir()))
    else:
        entries.append(path)

evidence = {
    'schema_version': 1,
    'experiment': 'dispatcher-01',
    'source_commit_before': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
    'source_tree_before': subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=ROOT, text=True).strip(),
    'helper_sha256': HELPER_SHA256,
    'fixture_medium': 'Task-owned TMPDIR on /workspace overlay, changed from the earlier local /tmp tmpfs fixtures',
    'fixture_root': str(FIXTURES),
    'node_os_tmpdir_verified': True,
    'limitations': [
        'The fixture medium and verified frozen dependency layout changed from the previous local timing attempts. Across-attempt changes cannot be attributed solely to the dispatcher patch.',
        'The current local filesystem is a container overlay; physical device and host persistence guarantees are not established.',
        'Immediate native commits and SQLite WAL/NORMAL remain unchanged, but this run makes no power-loss durability claim.',
        'Available tmpfs space reflects other pre-existing contents; unrelated temporary directories were not removed by this supervisor.',
    ],
    'capacity_probe': {
        'node_version': 'v26.12.1',
        'method': 'Owned temporary sparse file, copied with node:fs copyFileSync, then both files removed.',
        'source_logical_bytes': 272896000,
        'source_allocated_bytes': 8192,
        'copy_logical_bytes': 272896000,
        'copy_allocated_bytes': 272896000,
        'minimum_nine_native_copy_bytes': 2456064000,
    },
    'before': filesystem_snapshot(),
}
EVIDENCE.write_text(json.dumps(evidence, indent=2) + '\n')
if evidence['before']['paths'][str(FIXTURES)]['available_bytes'] < 3000000000:
    raise RuntimeError('Less than 3 GB available on the selected fixture filesystem; review capacity before starting the fixed eight-pair run')

moved = []
signal.signal(signal.SIGTERM, interrupted)
signal.signal(signal.SIGINT, interrupted)
try:
    for path in entries:
        relative = path.relative_to(modules)
        if str(relative) in keep:
            continue
        target = BACKUP / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        os.rename(path, target)
        moved.append(str(relative))
    (BACKUP / 'restore-manifest.json').write_text(json.dumps(moved, indent=2) + '\n')
    print(f'Moved {len(moved)} generated root aliases; source and workspace modules are unchanged.', flush=True)
    command = ['node', 'tools/performance-persistence.mjs', '--database', str(HELPER), '--output', str(OUTPUT), '--mode', 'diagnostic']
    evidence['command'] = command
    EVIDENCE.write_text(json.dumps(evidence, indent=2) + '\n')
    with (SCRATCH / 't3-performance-dispatcher-01.log').open('x') as log:
        child = subprocess.Popen(command, cwd=ROOT, env=ENVIRONMENT, stdout=log, stderr=subprocess.STDOUT)
        try:
            evidence['exit_code'] = child.wait()
        except BaseException:
            child.terminate()
            try:
                child.wait(timeout=15)
            except subprocess.TimeoutExpired:
                child.kill()
                child.wait(timeout=5)
            raise
finally:
    for relative in reversed(moved):
        target = modules / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        assert not os.path.lexists(target), f'Unexpected replacement at {target}'
        os.rename(BACKUP / relative, target)
    evidence['after'] = filesystem_snapshot()
    evidence['restored_root_aliases'] = len(moved)
    evidence['source_commit_after'] = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
    evidence['source_dirty_after'] = bool(subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=normal'], cwd=ROOT, text=True).strip())
    EVIDENCE.write_text(json.dumps(evidence, indent=2) + '\n')
    if OUTPUT.is_dir():
        (OUTPUT / 'filesystem-observations.json').write_text(EVIDENCE.read_text())
    print(f'Restored {len(moved)} root aliases; filesystem observations retained at {EVIDENCE}', flush=True)

raise SystemExit(evidence['exit_code'])
