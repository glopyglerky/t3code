# Persistence request attribution diagnostic

Status: completed-diagnostic. Qualifies: false. Attempt: 2026-11-14T16-19-52.469Z-f63971f4.

Base commit: a2fb16d84f089e2a7ca681e431e6acff083695bf. Tree: 9aca39040e56c362ed1edba9e69d49602b5feee8.
Observer patch SHA-256: fd598676c15bdeeb2c503b01a7f9fb48f161bb0d008d84119162234d180563d1.
Helper SHA-256: e29ae6419d7b6138a43eacdcf86803c410b2522600fbff20d3219e1bd42369b4.
Build receipt SHA-256: 94b532e63376cd235165acab975e3ed5465f66a09d13f8b405fbe0a8cd65a7ea.
Pinned stock oracle: 5fe2f7e4567d9e530ded0dabc9d706db27d77b84.

Compiler provenance: **manifest-reported**. Manifest-reported route: bluefe-rustc-via-lustr. Build profile: release.
Expected route: bluefe-rustc-via-lustr. Expected compiler revision: `1b74388e196ee8813f38ba9eeb6d4ab43b6b1071`. Expected coordinator: `07470b20464bf097c3c88983124aff56c5e44f9a`.
Manifest-reported compiler identity: not supplied. The expected lock identity does not establish which drivers built this executable.
Diagnostic mode binds only the supplied manifest's executable hash; its source, compiler route and build identity are reported claims, not qualification.

## Same instrumented build, probes disabled and enabled

| Workload | Disabled median / p95 / worst ms | Enabled median / p95 / worst ms |
|---|---:|---:|
| service-open-and-first-operations | 715.774 / 715.774 / 715.774 | 712.328 / 712.328 / 712.328 |
| sidebar-shell | 139.031 / 175.969 / 201.361 | 139.049 / 170.510 / 183.978 |
| history-window | 126.904 / 153.935 / 172.427 | 123.738 / 188.932 / 237.322 |
| message-search | 45.596 / 51.923 / 54.864 | 44.448 / 55.958 / 57.247 |
| accent-search | 40.024 / 43.812 / 44.157 | 37.468 / 44.112 / 45.582 |
| visit-commit | 5.630 / 6.343 / 6.909 | 6.003 / 7.460 / 8.137 |

One worker per condition. These descriptive distributions do not establish a causal overhead or production speed ratio.

Correctness: passed.

## Decisions and limits

- This isolated diagnostic runs the existing stock/native correctness and reopen checks with observers unconfigured, then one native probes-disabled worker and one native probes-enabled worker.
- Correctness validation retains its deliberate rollback and discarded-helper lifecycle. It has no attribution profile; its original data/order, exact rollback sentinel and committed reopen checks remain required.
- Both native measurement workers use the same instrumented optimized helper, the same fixture, three excluded warmups and twelve retained samples per API.
- The fixed qualification contract and thresholds are unchanged. This attempt does not run its eight paired stock/native comparisons and cannot qualify any source.
- The disabled/enabled comparison indicates probe overhead only, with one process per condition and a fixed order. It is not an uninstrumented production comparison or a causal speed estimate.
- Fixture creation, migration and index preparation remain outside worker API timing, using the unchanged original runner logic.
- All native metrics name instrumented application-wrapper calls. Get includes cached writer observations; begin_snapshot covers its named entry point, not every engine snapshot.
- Times are inclusive wall times. Request/evaluate, store/backend/checked open, get_many/get, and commit_staged/commit_actual overlap; their totals must not be added or subtracted as disjoint costs. A residual is not proof of JSON, CPU or pure IPC cost.
- The client wait includes write, helper work, transport, scheduling and UTF-8 framing. Client decode includes envelope and result validation.
- Only static labels, ordinals, counts, lengths and timings are added by observers. No database keys, identifiers or payload values are recorded by probes.
- Successful helper output requires proven backend handle closure, complete request rows, zero active spans, and no recorded late span. Missing output rejects the profile.
- The observer has fixed row and byte caps. Overflow, incomplete shutdown or mismatched request ordinals rejects the diagnostic.
- RSS and GC retain the original advisory scope. The OS page cache is not flushed; filesystem metadata does not prove physical-device or power-loss behavior.
- The raw correctness worker results use only the existing controlled synthetic fixture. They are separate from the metadata-only probe files.

Raw native/client probe files, all worker samples, source hashes, exact command, host/filesystem facts and the build receipt are retained with profile.json.
