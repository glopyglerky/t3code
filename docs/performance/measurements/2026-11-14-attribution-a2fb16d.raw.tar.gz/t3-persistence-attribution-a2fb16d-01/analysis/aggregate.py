from pathlib import Path
import collections
import hashlib
import json
import math
import statistics

scratch = Path('/workspace/scratch/fcf5fdf8376a')
root = scratch/'t3-persistence-profile-01'
destination = scratch/'t3-profile-attribution-01.json'
assert not destination.exists(), 'Derived evidence is not overwritten'
digest = lambda data: hashlib.sha256(data).hexdigest()
read = lambda path: json.loads(path.read_text())
report = read(root/'profile.json')
assert report['status']=='completed-diagnostic' and report['qualifies'] is False
assert report['correctness']['status']=='passed'
assert report['baseline']['runtime_provenance']['status']=='verified'
assert not report['baseline']['runtime_provenance']['issues']
assert len(report['runs']) == 4
for run in report['runs']:
    name = ('validation-'+run['backend']) if run['purpose']=='validation' else (
        'native-probes-enabled' if run['native_probes_enabled'] else 'native-probes-disabled')
    assert read(root/(name+'.json')) == run, name
for profile in report['profiles']:
    for file in profile['files']:
        path = root/(profile['worker']+'.observer')/file['file']
        assert path.stat().st_size==file['bytes'] and digest(path.read_bytes())==file['sha256']
workers={run['native_probes_enabled']:run for run in report['runs'] if run['purpose']=='measurement'}
assert set(workers)=={False,True}
apis=list(workers[True]['result']['samples'])
assert apis==['sidebar-shell','history-window','message-search','accent-search','visit-commit']
for worker in workers.values():
    assert all(len(worker['result']['samples'][api])==12 for api in apis)
client_path=root/'native-probes-enabled.observer/client.json'
client=read(client_path)
assert client['incomplete'] is False and client['enabled'] is True
markers={m['ordinal']:m for m in client['markers']}
assert len(markers)==81 and all(m['finished'] for m in markers.values())
requests=[]
startup=[]
metric_fields=['calls','elapsed_ns','input_units','input_bytes','output_units','output_bytes']
groups=collections.defaultdict(lambda:{
    'requests':0,'native_request_wall_ms':0.0,
    'client_timing_ms':dict.fromkeys(['encode_ms','wait_ms','decode_ms','total_ms'],0.0),
    'metrics':{},
})
for connection in client['connections']:
    if connection['helper_file'] is None:
        assert connection['mode']=='owner-lock'
        continue
    helper_path=root/'native-probes-enabled.observer'/connection['helper_file']
    helper=read(helper_path)
    assert helper['store_close_confirmed'] and helper['active_spans_at_flush']==0 and not helper['incomplete']
    assert len(helper['requests'])==len(connection['requests'])+1
    startup.append({'connection':connection['ordinal'],'mode':connection['mode'],
                    'helper_file':connection['helper_file'],
                    'process_elapsed_ms':helper['process_elapsed_ns']/1e6,
                    'outside_request':helper['requests'][0]})
    for index,(native_client,native_helper) in enumerate(zip(connection['requests'],helper['requests'][1:]),1):
        assert native_client['helper_ordinal']==native_helper['ordinal']==index
        assert native_client['kind']==native_helper['kind']
        assert native_client['input_bytes']==native_helper['frame_bytes']
        assert native_client['finished'] and native_helper['finished']
        assert native_client['success'] is True and native_helper['response_ok'] is True
        marker=markers.get(native_client['marker'])
        group=(marker['phase']+':'+marker['api']) if marker else 'outside-api'
        row={'connection':connection['ordinal'],'helper_file':connection['helper_file'],
             'phase_api':group,'marker_ordinal':native_client['marker'],
             'sample_index':marker['sample'] if marker else None,
             'client':native_client,'helper':native_helper}
        requests.append(row)
        aggregate=groups[group]
        aggregate['requests']+=1
        aggregate['native_request_wall_ms']+=native_helper['elapsed_ns']/1e6
        for key in aggregate['client_timing_ms']:
            aggregate['client_timing_ms'][key]+=native_client[key] or 0.0
        for metric in native_helper['metrics']:
            target=aggregate['metrics'].setdefault(metric['kind'],dict.fromkeys(metric_fields,0))
            for field in metric_fields:
                target[field]+=metric['counts'][field]

def quantile(values, q):
    values=sorted(values)
    position=(len(values)-1)*q
    lower=math.floor(position)
    fraction=position-lower
    return values[lower]+fraction*(values[min(lower+1,len(values)-1)]-values[lower])
def summary(values):
    return {'count':len(values),'mean_ms':statistics.mean(values),'median_ms':quantile(values,.5),
            'p95_ms':quantile(values,.95),'worst_ms':max(values)}
off_on=[]
for api in ['service-open-and-first-operations']+apis:
    values={enabled:([worker['result']['cold_open_ms']] if api=='service-open-and-first-operations' else
                    worker['result']['samples'][api]) for enabled,worker in workers.items()}
    off=summary(values[False]); on=summary(values[True])
    off_on.append({'id':api,'disabled':off,'enabled':on,
                   'signed_latency_change_percent':{metric:(on[metric]/off[metric]-1)*100
                       for metric in ['median_ms','p95_ms','worst_ms']}})
sample_apis=[]
for api in apis:
    aggregate=groups['sample:'+api]
    row={'id':api,'api':summary(workers[True]['result']['samples'][api]),
         'requests_per_api':aggregate['requests']/12,
         'native_request_wall_ms_per_api':aggregate['native_request_wall_ms']/12,
         'client_ms_per_api':{key:value/12 for key,value in aggregate['client_timing_ms'].items()},
         'metrics_per_api':{name:{field:value/12 for field,value in totals.items()}
                            for name,totals in aggregate['metrics'].items()}}
    sample_apis.append(row)
result={
 'schema':1,'purpose':'derived attribution from retained metadata only','qualifies':False,
 'report_sha256':digest((root/'profile.json').read_bytes()),
 'analysis_source_sha256':digest(Path(__file__).read_bytes()),
 'source_commit':report['source_commit'],'source_tree':report['source_tree'],
 'observer_patch_sha256':report['observer_patch_sha256'],'helper_sha256':report['executable_sha256'],
 'unchanged_source_sections':report['extraction'],
 'correctness':{'status':'passed','cardinality':next(r for r in report['runs'] if r['backend']=='native' and r['purpose']=='validation')['result']['cardinality']},
 'off_on':off_on,'sample_api_summary':sample_apis,
 'startup_connections':startup,'phase_aggregates':dict(groups),
 'api_markers':client['markers'],'requests':requests,
 'interpretation_limits':[
  'Only one fixed-order process per probe condition, with three excluded warmups and twelve measured API cycles. No paired stock speed verdict, confidence interval or causal overhead estimate.',
  'Client, request, evaluate, open, get_many/get and commit_staged/commit_actual intervals overlap. Do not add them as independent costs or label residuals JSON, CPU, physical I/O or pure IPC.',
  'Calls and byte counts are aggregate application-wrapper observations. Returned bytes can count the same value repeatedly; they are not memory usage or storage traffic.',
  'The repeated node-root read hypothesis also requires source analysis. These probes contain no key or parser attribution.',
 ],
}
destination.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'analysis_sha256':digest(destination.read_bytes()),'bytes':destination.stat().st_size,
                  'requests':len(requests),'markers':len(markers),'phase_groups':len(groups),
                  'correctness':result['correctness'],'off_on':off_on},indent=2))
