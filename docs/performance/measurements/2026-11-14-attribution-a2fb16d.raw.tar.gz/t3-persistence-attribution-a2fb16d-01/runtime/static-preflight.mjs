import * as Assert from "node:assert/strict";
import * as Crypto from "node:crypto";
import * as FS from "node:fs/promises";
import * as Path from "node:path";
import * as URL from "node:url";
import { createPinnedBaseline } from "./t3-persistence-profile-a2fb16d/tools/performance-baseline.mjs";

const root = "/workspace/scratch/fcf5fdf8376a/t3-persistence-profile-a2fb16d";
const output = "/workspace/scratch/fcf5fdf8376a/t3-profile-runtime-static-a2fb16d-02";
await FS.mkdir(output, { mode: 0o700 });
const upstream = JSON.parse(await FS.readFile(Path.join(root, "upstream.lock.json"), "utf8")).upstream;
const report = {
  schema: 1, purpose: "static runtime/source-alias attestation", qualifies: false, status: "running",
  node: process.version, command: [process.execPath, ...process.argv.slice(1)],
  observer_source_sha256: Crypto.createHash("sha256").update(await FS.readFile(URL.fileURLToPath(import.meta.url))).digest("hex"),
  application_workload_executed: false, measurement_started: false,
  baseline_export_removed_after_static_validation: false,
};
try {
  report.baseline = await createPinnedBaseline(root, upstream.commit, upstream.root_tree,
    Path.join(output, "stock-export"), { qualify: true });
  report.imports = Object.fromEntries(await Promise.all(
    ["effect", "@effect/platform-node", "yaml", "@t3tools/contracts", "@t3tools/shared"].map(async (name) => {
      const target = await FS.realpath(Path.join(root, "node_modules", name));
      Assert.ok(target.startsWith(root + "/"));
      if (name.startsWith("@t3tools/")) Assert.ok(target.startsWith(root + "/packages/"));
      else Assert.ok(target.startsWith(root + "/node_modules/.pnpm/"));
      return [name, target];
    }),
  ));
  report.status = "passed";
} catch (error) {
  report.status = "failed";
  report.error = { name: error.name, message: error.message };
} finally {
  await FS.rm(Path.join(output, "stock-export"), { recursive: true, force: true });
  report.baseline_export_removed_after_static_validation = true;
  await FS.writeFile(Path.join(output, "runtime.json"), JSON.stringify(report, null, 2) + "\n", { flag: "wx", mode: 0o600 });
}
const bytes = await FS.readFile(Path.join(output, "runtime.json"));
console.log(JSON.stringify({
  status: report.status, runtime_status: report.baseline?.runtime_provenance.status,
  issues: report.baseline?.runtime_provenance.issues,
  external_dependencies: report.baseline?.external_dependencies.length,
  node: process.version, imports: report.imports,
  report_sha256: Crypto.createHash("sha256").update(bytes).digest("hex"),
  runtime_provenance: report.baseline?.runtime_provenance, error: report.error,
}));
process.exitCode = report.status === "passed" ? 0 : 1;
