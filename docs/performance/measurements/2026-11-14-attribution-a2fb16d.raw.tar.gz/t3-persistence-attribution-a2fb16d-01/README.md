# Persistence attribution evidence

This is one non-qualifying diagnostic, completed on 2026-11-14. The original
report remains byte-for-byte in run/profile.json. All four workers, their full
outputs, and both probes-off/on client/helper metadata sets are retained.
The validation workers intentionally have no observer profiles: their unchanged
deliberate rollback/discard and reopen lifecycle was tested with probes
unconfigured. No timing sample or failure was removed.

source/ retains the unbuilt v1 source-review draft and the corrected, built v2
patch, both private-driver/worker deltas, exact file hashes, original base
runner/worker bytes, and unchanged-section witnesses. The v1-to-v2 correction
removed observer requirements from validation only; measurement was unchanged.

build/ contains the actual Lustr coordinator command, source/tool identities,
preserved helper hash, full build log and supervisor source. The executable is
not embedded. Its route evidence is local diagnostic evidence, not a CI receipt.

runtime/ retains the first rejected static preflight, private root-link
normalization, and second verified preflight with 440 per-importer frozen
dependency descriptors. All source workspace aliases resolve into the isolated
profile checkout. Neither preflight ran an application workload. Only generated
private aliases changed; main source, package bytes and per-workspace importer
links did not change.

run/ also contains the exact supervisor command, timing/cleanup outcome, host
and filesystem observations, all raw sample distributions, correctness witnesses,
synthetic validation results, source hashes, and separately scoped build metadata.
Probes log only static labels, ordinals, counts, lengths and timings. Full
correctness outputs contain only the benchmark's controlled synthetic fixture.

analysis/ is derived after the completed run. It retains all 574 joined requests,
81 API markers, 17 phase groups, startup rows and per-API off/on summaries.
The script validates worker/report identity, file hashes, request ordinals,
operation kinds, frame sizes, success and complete closure before aggregation.
Its paths identify the original owned environment; reproducing elsewhere needs
path remapping, without changing the analysis or underlying evidence.

Times are inclusive wall observations. Nested totals must not be summed as
independent costs or subtracted to label a residual JSON, CPU or pure IPC.
Counts are application-wrapper calls, not physical storage-operation counts.
Probes-off and probes-on use the same instrumented build, in fixed order, one
process each. They do not establish causal overhead or stock performance parity.

The archive contains regular files only, no database, executable, target,
node_modules, user state, credential or network-provider output. SHA256SUMS.json
records every other archive entry. Archive metadata is normalized for inspection.
