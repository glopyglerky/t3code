from pathlib import Path
import gzip
import hashlib
import io
import json
import subprocess
import tarfile

scratch = Path('/workspace/scratch/fcf5fdf8376a')
documentation = scratch/'t3-profile-docs-ee178c'
destination = documentation/'docs/performance/measurements/2026-11-14-attribution-a2fb16d.raw.tar.gz'
assert not destination.exists(), 'Retained evidence must not be overwritten'
base = 'a2fb16d84f089e2a7ca681e431e6acff083695bf'
prefix = 't3-persistence-attribution-a2fb16d-01'
entries = {}

def add(name, data):
    assert name not in entries and not name.startswith('/') and '..' not in Path(name).parts
    assert len(data) <= 16 * 1024 * 1024, name
    entries[name] = data

def retain(name, source):
    path = scratch/source
    assert path.is_file() and not path.is_symlink(), path
    add(name, path.read_bytes())

files = {
    'source/v1-observer.patch': 't3-persistence-profile-a2fb16d-observer.patch',
    'source/v1-source-review.json': 't3-persistence-profile-a2fb16d-source.json',
    'source/v1-driver-delta.patch': 't3-profile-driver-delta.patch',
    'source/v1-worker-delta.patch': 't3-profile-worker-delta.patch',
    'source/v2-observer.patch': 't3-persistence-profile-a2fb16d-observer-v2.patch',
    'source/v2-source-review.json': 't3-persistence-profile-a2fb16d-source-v2.json',
    'source/v2-driver-delta.patch': 't3-profile-driver-delta-v2.patch',
    'source/v2-worker-delta.patch': 't3-profile-worker-delta-v2.patch',
    'source/allowed-static-operations.json': 't3-profile-static-operations.json',
    'build/supervisor.py': 't3-profile-build-a2fb16d.py',
    'build/build-receipt.json': 't3-profile-helper-a2fb16d-build-01/build-receipt.json',
    'build/build.log': 't3-profile-helper-a2fb16d-build-01/build.log',
    'runtime/prepare.py': 't3-profile-runtime-prepare-a2fb16d.py',
    'runtime/preparation-and-source-aliases.json': 't3-profile-runtime-a2fb16d.json',
    'runtime/static-preflight.mjs': 't3-profile-runtime-static-a2fb16d.mjs',
    'runtime/preflight-01-failed.json': 't3-profile-runtime-static-a2fb16d/failure.json',
    'runtime/private-root-alias-normalization.json': 't3-profile-runtime-root-normalization-a2fb16d.json',
    'runtime/preflight-02-verified.json': 't3-profile-runtime-static-a2fb16d-02/runtime.json',
    'run/supervisor.json': 't3-persistence-profile-01.supervisor.json',
    'run/supervisor.stdout.log': 't3-persistence-profile-01.stdout.log',
    'run/supervisor.stderr.log': 't3-persistence-profile-01.stderr.log',
    'analysis/aggregate.py': 't3-profile-analyze-01.py',
    'analysis/attribution.json': 't3-profile-attribution-01.json',
    'archive-builder.py': 't3-profile-package-01.py',
}
for name, source in files.items():
    retain(name, source)
for path in sorted((scratch/'t3-persistence-profile-01').rglob('*')):
    if path.is_file():
        retain('run/'+str(path.relative_to(scratch/'t3-persistence-profile-01')), str(path.relative_to(scratch)))
report = json.loads(entries['run/profile.json'])
for path in ['tools/performance-persistence.mjs', 'tools/performance-worker.mjs']:
    contents = subprocess.check_output(['git', '-C', str(documentation), 'show', base+':'+path])
    add('source/original/'+path, contents)
add('source/unchanged-source-section-proof.json', (json.dumps({
    'base_commit': base,
    'base_tree': report['source_tree'],
    'observer_patch_sha256': report['observer_patch_sha256'],
    'proof': report['extraction'],
    'scope': 'The private driver asserts these copied sections equal the original runner and worker before executing any application worker. Originals and complete private-file deltas are retained in source/.',
}, indent=2)+'\n').encode())
add('README.md', b'''# Persistence attribution evidence

This is one non-qualifying diagnostic, completed on 2026-11-14. The original
report remains byte-for-byte in run/profile.json. All four workers, their full
outputs, and both probes-off/on client/helper metadata sets are retained.
The validation workers intentionally have no observer profiles: their unchanged
deliberate rollback/discard and reopen lifecycle was tested with probes
unconfigured. No timing sample or failure was removed.

source/ retains the unbuilt v1 source-review draft and the corrected, built v2
patch, both private-driver/worker deltas, exact file hashes, original base
runner/worker bytes, and unchanged-section witnesses. The v1-to-v2 correction
removed observer requirements from validation only; measurement was unchanged.

build/ contains the actual Lustr coordinator command, source/tool identities,
preserved helper hash, full build log and supervisor source. The executable is
not embedded. Its route evidence is local diagnostic evidence, not a CI receipt.

runtime/ retains the first rejected static preflight, private root-link
normalization, and second verified preflight with 440 per-importer frozen
dependency descriptors. All source workspace aliases resolve into the isolated
profile checkout. Neither preflight ran an application workload. Only generated
private aliases changed; main source, package bytes and per-workspace importer
links did not change.

run/ also contains the exact supervisor command, timing/cleanup outcome, host
and filesystem observations, all raw sample distributions, correctness witnesses,
synthetic validation results, source hashes, and separately scoped build metadata.
Probes log only static labels, ordinals, counts, lengths and timings. Full
correctness outputs contain only the benchmark's controlled synthetic fixture.

analysis/ is derived after the completed run. It retains all 574 joined requests,
81 API markers, 17 phase groups, startup rows and per-API off/on summaries.
The script validates worker/report identity, file hashes, request ordinals,
operation kinds, frame sizes, success and complete closure before aggregation.
Its paths identify the original owned environment; reproducing elsewhere needs
path remapping, without changing the analysis or underlying evidence.

Times are inclusive wall observations. Nested totals must not be summed as
independent costs or subtracted to label a residual JSON, CPU or pure IPC.
Counts are application-wrapper calls, not physical storage-operation counts.
Probes-off and probes-on use the same instrumented build, in fixed order, one
process each. They do not establish causal overhead or stock performance parity.

The archive contains regular files only, no database, executable, target,
node_modules, user state, credential or network-provider output. SHA256SUMS.json
records every other archive entry. Archive metadata is normalized for inspection.
''')
manifest = {
    'schema': 1,
    'qualifies': False,
    'base_commit': base,
    'base_tree': report['source_tree'],
    'observer_patch_sha256': report['observer_patch_sha256'],
    'helper_sha256': report['executable_sha256'],
    'original_report_sha256': hashlib.sha256(entries['run/profile.json']).hexdigest(),
    'files': [{
        'path': name,
        'bytes': len(contents),
        'sha256': hashlib.sha256(contents).hexdigest(),
    } for name, contents in sorted(entries.items())],
}
add('SHA256SUMS.json', (json.dumps(manifest, indent=2)+'\n').encode())
assert sum(map(len, entries.values())) < 16 * 1024 * 1024
with destination.open('xb') as output:
    with gzip.GzipFile(filename='', mode='wb', compresslevel=9, fileobj=output, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as archive:
            for name, contents in sorted(entries.items()):
                info = tarfile.TarInfo(prefix+'/'+name)
                info.size = len(contents)
                info.mode = 0o644
                info.uid = info.gid = 0
                info.mtime = 0
                archive.addfile(info, io.BytesIO(contents))
print(json.dumps({
    'archive': str(destination),
    'sha256': hashlib.sha256(destination.read_bytes()).hexdigest(),
    'compressed_bytes': destination.stat().st_size,
    'entries': len(entries),
    'uncompressed_bytes': sum(map(len, entries.values())),
    'original_report_sha256': manifest['original_report_sha256'],
}, indent=2))
